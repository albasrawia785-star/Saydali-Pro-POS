import React from 'react';

export interface ToastMessage {
  id: string;
  message: string;
  type?: 'success' | 'error' | 'info';
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 w-full max-w-xs z-50 flex flex-col gap-2 pointer-events-none px-4">
      {toasts.map((t) => {
        const isError = t.type === 'error';
        const isSuccess = t.type === 'success' || !t.type;

        return (
          <div
            key={t.id}
            onClick={() => onDismiss(t.id)}
            className={`pointer-events-auto p-3 rounded-2xl shadow-xl text-xs font-semibold flex items-center justify-between gap-2 border transition-all animate-in slide-in-from-top-2 duration-200 ${
              isError
                ? 'bg-red-600 text-white border-red-700'
                : isSuccess
                ? 'bg-slate-900/95 text-white border-slate-800 backdrop-blur-sm'
                : 'bg-blue-600 text-white border-blue-700'
            }`}
          >
            <div className="flex items-center gap-2">
              <i
                className={`text-sm ${
                  isError
                    ? 'fa-solid fa-circle-xmark text-red-200'
                    : 'fa-solid fa-circle-check text-emerald-400'
                }`}
              ></i>
              <span>{t.message}</span>
            </div>
            <button
              type="button"
              className="text-white/60 hover:text-white text-xs cursor-pointer"
            >
              <i className="fa-solid fa-xmark"></i>
            </button>
          </div>
        );
      })}
    </div>
  );
};
