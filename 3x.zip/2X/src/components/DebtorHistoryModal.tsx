import React, { useState } from 'react';
import { Debtor, DebtorTransaction } from '../types';
import { formatNumber, formatDateTimeArabic, buildWhatsAppReminderUrl } from '../utils/formatters';

interface DebtorHistoryModalProps {
  isOpen: boolean;
  debtor: Debtor | null;
  onClose: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const DebtorHistoryModal: React.FC<DebtorHistoryModalProps> = ({
  isOpen,
  debtor,
  onClose,
  onShowToast,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'add' | 'pay'>('all');

  if (!isOpen || !debtor) return null;

  // Build history list, fallback to initial creation entry if empty
  const rawHistory: DebtorTransaction[] = debtor.history && debtor.history.length > 0
    ? debtor.history
    : [
        {
          id: `initial-${debtor.id}`,
          debtorId: debtor.id,
          type: 'initial',
          amount: debtor.amount,
          balanceAfter: debtor.amount,
          date: debtor.createdAt || new Date().toISOString(),
          description: 'فتح حساب وتسجيل الرصيد الأولي',
        },
      ];

  // Sort descending by date (newest first)
  const sortedHistory = [...rawHistory].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const filteredHistory = sortedHistory.filter((item) => {
    if (filterType === 'all') return true;
    if (filterType === 'add') return item.type === 'add' || item.type === 'initial';
    if (filterType === 'pay') return item.type === 'pay';
    return true;
  });

  // Calculate totals
  const totalAdded = rawHistory
    .filter((h) => h.type === 'add' || h.type === 'initial')
    .reduce((sum, h) => sum + h.amount, 0);

  const totalPaid = rawHistory
    .filter((h) => h.type === 'pay')
    .reduce((sum, h) => sum + h.amount, 0);

  const currentBalance = debtor.amount;

  const handleCopyStatement = () => {
    try {
      let text = `📜 *كشف حساب وسجل عمليات: ${debtor.name}*\n`;
      text += `📞 الهاتف: ${debtor.phone || 'غير مسجل'}\n`;
      if (debtor.notes) {
        text += `📝 ملاحظات: ${debtor.notes}\n`;
      }
      text += `💰 الرصيد الحالي المتبقي: ${formatNumber(currentBalance)} د.ع\n`;
      text += `➕ إجمالي الديون: ${formatNumber(totalAdded)} د.ع\n`;
      text += `➖ إجمالي المسدد: ${formatNumber(totalPaid)} د.ع\n`;
      text += `━━━━━━━━━━━━━━━━━━\n`;
      text += `*تفاصيل العمليات السابقة:*\n`;

      sortedHistory.forEach((tx, idx) => {
        const typeStr =
          tx.type === 'pay'
            ? '✅ تسديد دفعة'
            : tx.type === 'initial'
            ? '📂 رصيد أولي'
            : '➕ إضافة دين';
        const sign = tx.type === 'pay' ? '-' : '+';
        text += `${idx + 1}) ${typeStr}: ${sign}${formatNumber(tx.amount)} د.ع\n`;
        text += `   📅 التاريخ: ${formatDateTimeArabic(tx.date)}\n`;
        if (tx.notes || (tx.description && tx.description !== 'إضافة دين جديد' && tx.description !== 'تسديد دفعة نقدية')) {
          text += `   📝 ملاحظة: ${tx.notes || tx.description}\n`;
        }
        text += `   ⚖️ الرصيد بعد العملية: ${formatNumber(tx.balanceAfter)} د.ع\n`;
      });

      navigator.clipboard.writeText(text);
      onShowToast('تم نسخ كشف العمليات إلى الحافظة بنجاح', 'success');
    } catch {
      onShowToast('تعذر نسخ كشف الحساب', 'error');
    }
  };

  const handleShareWhatsApp = () => {
    if (!debtor.phone) {
      onShowToast('لا يوجد رقم هاتف مسجل لهذا المدين', 'error');
      return;
    }

    let text = `السلام عليكم أخي الكريم ${debtor.name}،\nإليك كشف الحساب وسجل العمليات الخاص بك:\n`;
    text += `💰 الرصيد المتبقي بذمتكم: ${formatNumber(currentBalance)} د.ع\n`;
    text += `➕ إجمالي الديون: ${formatNumber(totalAdded)} د.ع\n`;
    text += `➖ إجمالي المسدد: ${formatNumber(totalPaid)} د.ع\n`;
    text += `━━━━━━━━━━━━━━━\nآخر العمليات:\n`;

    sortedHistory.slice(0, 5).forEach((tx) => {
      const typeStr = tx.type === 'pay' ? 'تسديد' : 'دين';
      const sign = tx.type === 'pay' ? '-' : '+';
      text += `• ${typeStr}: ${sign}${formatNumber(tx.amount)} د.ع (${formatDateTimeArabic(tx.date)})\n`;
    });

    const url = buildWhatsAppReminderUrl(debtor.phone, debtor.name, undefined);
    const baseWithoutText = url.split('?')[0];
    window.open(`${baseWithoutText}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div
      className="fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs animate-in fade-in duration-150 select-none"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh] border border-slate-100 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
        id="debtorHistoryModal"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold text-base shadow-md shadow-blue-500/20">
              <i className="fa-solid fa-clock-rotate-left"></i>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-slate-800">
                  سجل العمليات (History)
                </h2>
                <span className="text-[10px] bg-blue-100 text-blue-800 font-bold px-2 py-0.5 rounded-full">
                  {rawHistory.length} عملية
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                <span className="font-bold text-slate-700">{debtor.name}</span>
                {debtor.phone && (
                  <>
                    <span className="text-slate-300">•</span>
                    <span className="font-mono text-slate-500 dir-ltr">{debtor.phone}</span>
                  </>
                )}
              </div>
              {debtor.notes && (
                <div className="mt-1 text-[11px] text-amber-800 bg-amber-50 border border-amber-200/80 px-2 py-0.5 rounded-lg inline-flex items-center gap-1.5 max-w-full">
                  <i className="fa-regular fa-note-sticky text-[10px] text-amber-600 shrink-0"></i>
                  <span className="truncate">{debtor.notes}</span>
                </div>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center cursor-pointer transition-colors"
            title="إغلاق"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Financial Summary Cards */}
        <div className="p-3 sm:p-4 bg-slate-50 border-b border-slate-100">
          <div className="grid grid-cols-3 gap-2">
            {/* Total Added */}
            <div className="bg-white p-2.5 rounded-2xl border border-slate-100 text-center shadow-2xs">
              <div className="text-[10px] font-bold text-slate-400 mb-0.5">إجمالي الديون</div>
              <div className="text-xs sm:text-sm font-black text-rose-600 font-mono">
                {formatNumber(totalAdded)}
                <span className="text-[9px] font-normal text-slate-400 mr-0.5">د.ع</span>
              </div>
            </div>

            {/* Total Paid */}
            <div className="bg-white p-2.5 rounded-2xl border border-slate-100 text-center shadow-2xs">
              <div className="text-[10px] font-bold text-slate-400 mb-0.5">إجمالي المسدد</div>
              <div className="text-xs sm:text-sm font-black text-emerald-600 font-mono">
                {formatNumber(totalPaid)}
                <span className="text-[9px] font-normal text-slate-400 mr-0.5">د.ع</span>
              </div>
            </div>

            {/* Current Balance */}
            <div className="bg-white p-2.5 rounded-2xl border border-slate-100 text-center shadow-2xs">
              <div className="text-[10px] font-bold text-slate-400 mb-0.5">الرصيد المتبقي</div>
              <div
                className={`text-xs sm:text-sm font-black font-mono ${
                  currentBalance <= 0 ? 'text-emerald-600' : 'text-blue-700'
                }`}
              >
                {formatNumber(currentBalance)}
                <span className="text-[9px] font-normal text-slate-400 mr-0.5">د.ع</span>
              </div>
            </div>
          </div>

          {/* Quick Filters */}
          <div className="flex items-center justify-between mt-3 pt-2 border-t border-slate-200/60">
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setFilterType('all')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  filterType === 'all'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100'
                }`}
              >
                الكل ({rawHistory.length})
              </button>

              <button
                type="button"
                onClick={() => setFilterType('add')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  filterType === 'add'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100'
                }`}
              >
                ديون ({rawHistory.filter((h) => h.type === 'add' || h.type === 'initial').length})
              </button>

              <button
                type="button"
                onClick={() => setFilterType('pay')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  filterType === 'pay'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100'
                }`}
              >
                تسديدات ({rawHistory.filter((h) => h.type === 'pay').length})
              </button>
            </div>

            {/* Statement Actions */}
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleCopyStatement}
                className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-bold border border-slate-200 flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                title="نسخ كشف الحساب"
              >
                <i className="fa-regular fa-copy text-[11px]"></i>
                <span className="hidden sm:inline">نسخ</span>
              </button>

              {debtor.phone && (
                <button
                  type="button"
                  onClick={handleShareWhatsApp}
                  className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold border border-emerald-200 flex items-center gap-1 cursor-pointer transition-colors"
                  title="مشاركة الكشف عبر واتساب"
                >
                  <i className="fa-brands fa-whatsapp text-xs"></i>
                  <span className="hidden sm:inline">واتساب</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Transactions List */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2.5">
          {filteredHistory.length === 0 ? (
            <div className="text-center py-8 text-slate-400">
              <i className="fa-solid fa-receipt text-3xl text-slate-300 mb-2"></i>
              <p className="text-xs">لا توجد عمليات تطابق هذا الفلتر</p>
            </div>
          ) : (
            filteredHistory.map((tx) => {
              const isPay = tx.type === 'pay';
              const isInitial = tx.type === 'initial';

              return (
                <div
                  key={tx.id}
                  className={`p-3 rounded-2xl border transition-all flex items-start justify-between gap-3 ${
                    isPay
                      ? 'bg-emerald-50/40 border-emerald-100/80 hover:bg-emerald-50/70'
                      : isInitial
                      ? 'bg-amber-50/40 border-amber-100/80 hover:bg-amber-50/70'
                      : 'bg-rose-50/40 border-rose-100/80 hover:bg-rose-50/70'
                  }`}
                >
                  {/* Right side: Icon, Type, Date */}
                  <div className="flex items-start gap-2.5">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-sm font-bold shadow-2xs ${
                        isPay
                          ? 'bg-emerald-100 text-emerald-700'
                          : isInitial
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-rose-100 text-rose-700'
                      }`}
                    >
                      {isPay ? (
                        <i className="fa-solid fa-arrow-down"></i>
                      ) : isInitial ? (
                        <i className="fa-solid fa-wallet"></i>
                      ) : (
                        <i className="fa-solid fa-plus"></i>
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span
                          className={`text-xs font-black px-1.5 py-0.5 rounded-md ${
                            isPay
                              ? 'bg-emerald-100/80 text-emerald-800'
                              : isInitial
                              ? 'bg-amber-100/80 text-amber-800'
                              : 'bg-rose-100/80 text-rose-800'
                          }`}
                        >
                          {isPay ? 'تسديد دفعة' : isInitial ? 'رصيد أولي' : 'إضافة دين'}
                        </span>
                        <span className="text-[11px] font-semibold text-slate-700">
                          {tx.description || (isPay ? 'تسديد نقدي' : 'شراء بالدين')}
                        </span>
                      </div>

                      {/* Date and Time */}
                      <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
                        <i className="fa-regular fa-calendar-days text-[10px]"></i>
                        <span>{formatDateTimeArabic(tx.date)}</span>
                      </div>

                      {/* Transaction Note if present and distinct */}
                      {tx.notes && tx.notes !== tx.description && (
                        <div className="text-[10.5px] text-slate-600 mt-1.5 flex items-center gap-1.5 bg-slate-50 px-2 py-0.5 rounded-lg border border-slate-200/60 w-fit">
                          <i className="fa-solid fa-note-sticky text-amber-500 text-[10px]"></i>
                          <span>{tx.notes}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Left side: Amount and Balance after */}
                  <div className="text-left shrink-0">
                    <div
                      className={`text-sm sm:text-base font-black font-mono ${
                        isPay ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {isPay ? '-' : '+'}
                      {formatNumber(tx.amount)}
                      <span className="text-[10px] font-normal text-slate-400 mr-1 font-sans">
                        د.ع
                      </span>
                    </div>

                    <div className="text-[10.5px] text-slate-500 font-mono mt-0.5">
                      <span className="text-[9.5px] text-slate-400 font-sans ml-1">الرصيد:</span>
                      {formatNumber(tx.balanceAfter)} د.ع
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold cursor-pointer transition-colors"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
