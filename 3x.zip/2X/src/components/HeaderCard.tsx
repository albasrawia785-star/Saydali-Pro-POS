import React, { useState, useEffect, useRef } from 'react';
import { User } from '../types';
import { formatNumber, formatDateArabic, getSubscriptionDaysRemaining, isSubscriptionExpired } from '../utils/formatters';

interface HeaderCardProps {
  currentUser: User;
  debtorsCount: number;
  totalAmount: number;
  onLogout: () => void;
  isSaving?: boolean;
  searchTerm?: string;
  onSearchChange?: (val: string) => void;
}

export const HeaderCard: React.FC<HeaderCardProps> = ({
  currentUser,
  debtorsCount,
  totalAmount,
  onLogout,
  isSaving = false,
  searchTerm = '',
  onSearchChange,
}) => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // When search is opened, focus the input
  useEffect(() => {
    if (isSearchOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isSearchOpen]);

  // Keep search bar open if there is an active search query
  useEffect(() => {
    if (searchTerm) {
      setIsSearchOpen(true);
    }
  }, [searchTerm]);

  const handleToggleSearch = () => {
    if (isSearchOpen && searchTerm && onSearchChange) {
      onSearchChange('');
    }
    setIsSearchOpen(!isSearchOpen);
  };

  return (
    <div
      id="mainHeaderCard"
      className="bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 text-white px-4 pt-3.5 pb-4 rounded-b-3xl shadow-[0_10px_30px_-5px_rgba(2,6,23,0.3)] border-b border-slate-800/80 relative overflow-hidden text-right select-none transition-all"
    >
      {/* Ambient luxury lighting accents */}
      <div className="absolute -top-16 -left-12 w-48 h-48 bg-blue-500/15 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute top-1/2 -right-16 w-40 h-40 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>

      {/* Sub-Manager Subscription Indicator (أعلى البطاقة للمدير الفرعي أو الحساب التجريبي) */}
      {currentUser.role !== 'admin' && (
        <div
          id="subManagerSubscriptionBanner"
          className="relative z-10 mb-2.5 px-3 py-1.5 rounded-xl bg-white/[0.08] backdrop-blur-md border border-white/10 flex items-center justify-between gap-2 text-xs select-text"
        >
          {currentUser.subscriptionType === 'trial' || currentUser.role === 'trial' ? (
            <>
              <div className="flex items-center gap-1.5 text-amber-200 min-w-0">
                <i className="fa-solid fa-flask-vial text-amber-400 text-xs shrink-0"></i>
                <span className="text-amber-200/90 text-[11px] font-medium shrink-0">حالة الحساب:</span>
                <span className="font-bold text-amber-300 text-xs flex items-center gap-1">
                  <span>وضع تجريبي (حد 2 مدينين)</span>
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  const msg = encodeURIComponent("السلام عليكم، أود تفعيل النسخة الكاملة من تطبيق دفتر الديون لفتح عدد غير محدود من المدينين والمزامنة السحابية.");
                  window.open(`https://wa.me/9647810936407?text=${msg}`, '_blank');
                }}
                className="shrink-0 text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-500/25 hover:bg-amber-500/40 text-amber-200 border border-amber-400/40 flex items-center gap-1 cursor-pointer transition-colors"
                title="مراسلة الإدارة لتفعيل النسخة الكاملة"
              >
                <i className="fa-brands fa-whatsapp text-[10px] text-emerald-400"></i>
                <span>ترقية للنسخة الكاملة</span>
              </button>
            </>
          ) : currentUser.subscriptionType === 'monthly' ? (
            <>
              <div className="flex items-center gap-1.5 min-w-0">
                <i className="fa-solid fa-calendar-check text-purple-400 text-xs shrink-0"></i>
                <span className="text-slate-300 text-[11px] font-medium shrink-0">تاريخ انتهاء الاشتراك:</span>
                <span className="font-bold text-white text-xs font-mono truncate" dir="ltr">
                  {formatDateArabic(currentUser.subscriptionExpiresAt) || 'غير محدد'}
                </span>
              </div>
              <div className="shrink-0">
                {isSubscriptionExpired('monthly', currentUser.subscriptionExpiresAt) ? (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/25 text-rose-300 border border-rose-500/40 flex items-center gap-1">
                    <i className="fa-solid fa-triangle-exclamation text-[9px]"></i>
                    <span>اشتراك منتهي</span>
                  </span>
                ) : (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 ${
                      getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt) <= 3
                        ? 'bg-amber-500/25 text-amber-300 border-amber-500/40 animate-pulse'
                        : 'bg-purple-500/25 text-purple-200 border-purple-400/30'
                    }`}
                  >
                    <i className="fa-solid fa-hourglass-half text-[9px]"></i>
                    <span>
                      متبقي {getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt)}{' '}
                      {getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt) === 1
                        ? 'يوم'
                        : getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt) === 2
                        ? 'يومان'
                        : getSubscriptionDaysRemaining(currentUser.subscriptionExpiresAt) <= 10
                        ? 'أيام'
                        : 'يوماً'}
                    </span>
                  </span>
                )}
              </div>
            </>
          ) : (
            <>
              <div className="flex items-center gap-1.5 text-slate-200 min-w-0">
                <i className="fa-solid fa-shield-check text-emerald-400 text-xs shrink-0"></i>
                <span className="text-slate-300 text-[11px] font-medium shrink-0">نوع الحساب:</span>
                <span className="font-bold text-emerald-300 text-xs flex items-center gap-1">
                  <i className="fa-solid fa-infinity text-[10px] text-emerald-400"></i>
                  <span>حساب دائم</span>
                </span>
              </div>
              <span className="shrink-0 text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <i className="fa-solid fa-circle-check text-[9px] text-emerald-400"></i>
                <span>اشتراك غير محدود</span>
              </span>
            </>
          )}
        </div>
      )}

      {/* Row 1: Brand, Branch & Quick Controls */}
      <div className="flex justify-between items-center relative z-10 mb-3">
        <div className="flex items-center gap-1.5">
          <span className="font-extrabold text-sm tracking-tight text-white">دفتر الديون</span>
          <span
            className="text-[10.5px] font-medium bg-white/10 border border-white/10 px-2 py-0.5 rounded-full flex items-center gap-1 text-slate-200 max-w-[120px] truncate"
            title={currentUser.branch_name}
          >
            <i className="fa-solid fa-store text-[8.5px] text-blue-300"></i>
            <span id="displayBranchName" className="truncate">
              {currentUser.branch_name || 'الرئيسي'}
            </span>
          </span>
        </div>

        {/* Controls: Search Button, Count Badge, Logout */}
        <div className="flex items-center gap-1.5">
          {/* Magnifying Glass Search Button */}
          {onSearchChange && (
            <button
              id="headerSearchBtn"
              type="button"
              onClick={handleToggleSearch}
              title={isSearchOpen ? 'إغلاق البحث' : 'بحث بالاسم أو الهاتف'}
              className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs transition-all cursor-pointer relative border ${
                isSearchOpen || searchTerm
                  ? 'bg-blue-600 border-blue-400 text-white shadow-md shadow-blue-600/30 font-bold scale-105'
                  : 'bg-white/8 hover:bg-white/15 border-white/10 text-slate-300 active:scale-95'
              }`}
            >
              <i className="fa-solid fa-magnifying-glass text-[11.5px]"></i>
              {searchTerm && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 ring-2 ring-slate-900 animate-pulse"></span>
              )}
            </button>
          )}

          {/* Debtors Count Badge */}
          <div className="bg-white/8 border border-white/10 px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1 text-slate-200">
            <i className="fa-solid fa-users text-[10px] text-blue-300"></i>
            <span id="debtorsCountBadge" className="font-mono">{debtorsCount}</span>
            <span className="text-[10px] font-normal text-slate-400">مدين</span>
          </div>

          {/* Logout Button */}
          <button
            id="logoutBtn"
            type="button"
            onClick={onLogout}
            title="تسجيل الخروج"
            className="w-8 h-8 rounded-xl bg-white/8 hover:bg-rose-500/80 active:scale-95 border border-white/10 flex items-center justify-center text-xs transition-all cursor-pointer text-slate-300 hover:text-white"
          >
            <i className="fa-solid fa-arrow-right-from-bracket text-[11px]"></i>
          </button>
        </div>
      </div>

      {/* Expandable Live Search Input (Inside Header Card) */}
      {isSearchOpen && onSearchChange && (
        <div className="relative z-10 mb-3 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="relative flex items-center">
            <input
              ref={searchInputRef}
              type="text"
              id="headerSearchInput"
              className="w-full pl-8 pr-9 py-2 bg-slate-900/90 text-white placeholder:text-slate-400 rounded-xl text-xs font-medium outline-none shadow-inner border border-slate-700/80 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30 transition-all"
              placeholder="ابحث بالاسم أو رقم الهاتف..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
            />
            <i className="fa-solid fa-magnifying-glass absolute right-3 text-slate-400 text-xs pointer-events-none"></i>
            {searchTerm ? (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="absolute left-2.5 text-slate-400 hover:text-white p-1 cursor-pointer transition-colors"
                title="مسح البحث"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setIsSearchOpen(false)}
                className="absolute left-2.5 text-slate-400 hover:text-white p-1 cursor-pointer transition-colors"
                title="إغلاق البحث"
              >
                <i className="fa-solid fa-chevron-up text-[10px]"></i>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Row 2: Outstanding Balance */}
      <div className="flex items-center justify-between relative z-10 pt-2 border-t border-white/10">
        {/* Total Outstanding Balance */}
        <div>
          <div className="text-[11px] text-slate-400 font-medium flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
            <span>إجمالي الديون القائمة</span>
          </div>
          <div
            className="text-base sm:text-[17px] font-bold tracking-tight font-mono text-white leading-tight mt-1 flex items-baseline gap-1"
            id="totalAmount"
          >
            <span>{formatNumber(totalAmount)}</span>
            <span className="text-[11px] font-medium font-sans text-blue-300/80">د.ع</span>
          </div>
        </div>

        {/* Subtle Saving Indicator when writing to cloud */}
        {isSaving && (
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300 text-[11px]">
            <i className="fa-solid fa-spinner animate-spin text-[10px] text-blue-400"></i>
            <span>جارِ الحفظ...</span>
          </div>
        )}
      </div>
    </div>
  );
};
