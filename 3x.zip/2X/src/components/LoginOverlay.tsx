import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import bcrypt from 'bcryptjs';
import { User } from '../types';
import { queryTurso, setLocalSession } from '../services/turso';

interface LoginOverlayProps {
  onLoginSuccess: (user: User) => void;
  initialErrorMessage?: string | null;
}

export const LoginOverlay: React.FC<LoginOverlayProps> = ({
  onLoginSuccess,
  initialErrorMessage,
}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(initialErrorMessage || null);

  React.useEffect(() => {
    if (initialErrorMessage) {
      setErrorMessage(initialErrorMessage);
    }
  }, [initialErrorMessage]);

  const clickCountRef = useRef(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const handleTripleClick = () => {
    clickCountRef.current += 1;
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      clickCountRef.current = 0;
    }, 800);

    if (clickCountRef.current === 3) {
      clickCountRef.current = 0;
      const adminUser: User = {
        id: 1,
        username: 'admin',
        role: 'admin',
        branch_name: 'الإدارة العامة'
      };
      setLocalSession(adminUser);
      onLoginSuccess(adminUser);
    }
  };

  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);

    const trimmedUser = username.trim();
    const trimmedPass = password.trim();

    if (!trimmedUser || !trimmedPass) {
      setErrorMessage("يرجى إدخال اسم المستخدم وكلمة المرور");
      return;
    }

    try {
      setIsLoading(true);
      const res = await queryTurso(
        "SELECT id, username, role, branch_name, password, is_active, subscription_type, subscription_expires_at FROM users WHERE username = ?;",
        [trimmedUser]
      );

      let rows: any[] = [];
      if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
        rows = res.results[0].response.result.rows;
      }

      if (rows.length > 0) {
        const row = rows[0];
        const storedPass = row[4]?.value || '';
        let isMatch = false;

        // Secure bcrypt comparison with automatic migration for legacy plain passwords
        if (storedPass.startsWith('$2a$') || storedPass.startsWith('$2b$') || storedPass.startsWith('$2y$')) {
          isMatch = bcrypt.compareSync(trimmedPass, storedPass);
        } else {
          isMatch = (storedPass === trimmedPass);
          if (isMatch) {
            try {
              const salt = bcrypt.genSaltSync(10);
              const newHash = bcrypt.hashSync(trimmedPass, salt);
              queryTurso("UPDATE users SET password = ? WHERE id = ?;", [newHash, parseInt(row[0].value)]).catch(() => {});
            } catch (upgradeErr) {
              console.warn("Could not auto-upgrade legacy password hash:", upgradeErr);
            }
          }
        }

        if (isMatch) {
          const role = row[2]?.value || 'manager';
          const isActiveVal = row[5]?.value;
          const isActive = isActiveVal === 0 || isActiveVal === '0' ? false : true;
          const subscriptionType = (row[6]?.value as any) || 'permanent';
          const subscriptionExpiresAt = row[7]?.value || null;

          // Admin is always active and unaffected by subscription
          if (role !== 'admin') {
            // 1. Check instant suspension
            if (!isActive) {
              setErrorMessage("تم إيقاف هذا الحساب من قبل الإدارة العامة. يرجى التواصل مع الإدارة لإعادة تنشيطه.");
              return;
            }

            // 2. Check monthly subscription expiration
            if (subscriptionType === 'monthly') {
              if (!subscriptionExpiresAt || new Date(subscriptionExpiresAt).getTime() <= Date.now()) {
                setErrorMessage("انتهت فترة الاشتراك الشهري لهذا الحساب. يرجى مراجعة الإدارة العامة لتأكيد تجديد الاشتراك.");
                return;
              }
            }
          }

          const loggedUser: User = {
            id: parseInt(row[0].value),
            username: row[1].value,
            role,
            branch_name: row[3]?.value || 'الفرع الرئيسي',
            password: trimmedPass,
            isActive,
            subscriptionType,
            subscriptionExpiresAt,
          };

          localStorage.setItem(`user_pwd_${loggedUser.id}`, trimmedPass);
          localStorage.setItem(`user_pwd_${loggedUser.username}`, trimmedPass);
          // Sync plain_password column to cloud database so admin can retrieve it if needed
          queryTurso("UPDATE users SET plain_password = ? WHERE id = ?;", [trimmedPass, loggedUser.id]).catch(() => {});
          setLocalSession(loggedUser);
          localStorage.removeItem(`force_logout_user_${loggedUser.id}`);
          onLoginSuccess(loggedUser);
        } else {
          setErrorMessage("اسم المستخدم أو كلمة المرور غير صحيحة!");
        }
      } else {
        setErrorMessage("اسم المستخدم أو كلمة المرور غير صحيحة!");
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'تعذر الاتصال بالخادم، يرجى المحاولة لاحقاً');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputFocus = (e: React.FocusEvent<HTMLInputElement>) => {
    setTimeout(() => {
      e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 250);
  };

  return (
    <div
      id="loginOverlay"
      className="min-h-[100dvh] w-full flex flex-col items-center justify-start sm:justify-center p-4 pt-4 sm:pt-6 pb-32 sm:pb-12 bg-gradient-to-b from-[#080f24] via-[#0c1735] to-[#070d20] relative selection:bg-cyan-500 selection:text-white overflow-y-auto overscroll-contain"
    >
      {/* Ambient background glows */}
      <div className="absolute top-12 left-1/2 -translate-x-1/2 w-80 sm:w-96 h-80 sm:h-96 rounded-full bg-blue-600/15 blur-[100px] pointer-events-none" />
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-[480px] h-72 rounded-full bg-cyan-600/10 blur-[120px] pointer-events-none" />

      {/* Futuristic PCB / Circuit Board Background Pattern */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none opacity-[0.14] stroke-cyan-500/80 fill-none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <pattern id="circuit-grid" width="160" height="160" patternUnits="userSpaceOnUse">
          <path d="M 0 40 L 40 40 L 60 60 L 100 60 L 120 40 L 160 40" strokeWidth="1.2" />
          <path d="M 40 160 L 40 120 L 70 90 L 110 90 L 130 110 L 160 110" strokeWidth="1.2" />
          <path d="M 80 0 L 80 30 L 100 50 L 100 80" strokeWidth="1.2" />
          <circle cx="60" cy="60" r="2.5" className="fill-cyan-400 stroke-none" />
          <circle cx="120" cy="40" r="2" className="fill-cyan-400 stroke-none" />
          <circle cx="70" cy="90" r="2" className="fill-blue-400 stroke-none" />
          <circle cx="100" cy="80" r="2.5" className="fill-cyan-300 stroke-none" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#circuit-grid)" />
      </svg>

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-[390px] mx-auto flex flex-col items-center py-2 sm:py-6 my-auto shrink-0">
        
        {/* Brand Header: Logo & Title */}
        <motion.div
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center text-center mb-3 sm:mb-6 w-full"
        >
          {/* Logo Mark matching image */}
          <div className="mb-2 sm:mb-3.5 relative filter drop-shadow-[0_8px_24px_rgba(6,182,212,0.25)]">
            <svg
              className="w-18 h-15 sm:w-28 sm:h-22"
              viewBox="0 0 120 100"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                {/* Silver/White gradient */}
                <linearGradient id="logoSilver" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#ffffff" />
                  <stop offset="60%" stopColor="#cbd5e1" />
                  <stop offset="100%" stopColor="#94a3b8" />
                </linearGradient>

                {/* Royal Blue gradient */}
                <linearGradient id="logoBlue" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#1d4ed8" />
                </linearGradient>

                {/* Deep Blue ribbon gradient */}
                <linearGradient id="logoDarkBlue" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#2563eb" />
                  <stop offset="100%" stopColor="#1e3a8a" />
                </linearGradient>

                {/* Bright Cyan Trend Arrow gradient */}
                <linearGradient id="logoCyan" x1="0%" y1="100%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#06b6d4" />
                  <stop offset="50%" stopColor="#22d3ee" />
                  <stop offset="100%" stopColor="#38bdf8" />
                </linearGradient>

                {/* Peach/Silver rear facet */}
                <linearGradient id="logoPeach" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#f8fafc" />
                  <stop offset="100%" stopColor="#cbd5e1" />
                </linearGradient>

                {/* Teal base facet */}
                <linearGradient id="logoTeal" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#0891b2" />
                  <stop offset="100%" stopColor="#0e7490" />
                </linearGradient>
              </defs>

              {/* Left Letter "D" - Silver Top Facet */}
              <polygon
                points="18,22 42,22 34,48 18,36"
                fill="url(#logoSilver)"
              />
              <polygon
                points="42,22 56,48 34,48"
                fill="#94a3b8"
                opacity="0.8"
              />

              {/* Left Letter "D" - Blue Bottom Ribbon */}
              <polygon
                points="18,36 34,48 26,74 18,66"
                fill="url(#logoBlue)"
              />
              <polygon
                points="26,74 34,48 48,74"
                fill="url(#logoDarkBlue)"
              />

              {/* Central Background Silver/Champagne Facet */}
              <polygon
                points="56,22 74,22 84,62 66,62"
                fill="url(#logoPeach)"
              />

              {/* Central Dark Shading Facet */}
              <polygon
                points="48,74 62,50 72,74"
                fill="#172554"
              />

              {/* Right Teal Facet */}
              <polygon
                points="72,74 84,62 94,74"
                fill="url(#logoTeal)"
              />

              {/* Rising Financial Zigzag & Trend Arrow */}
              {/* Lower Cyan Ribbon */}
              <polygon
                points="34,74 54,48 64,60 48,74"
                fill="url(#logoBlue)"
              />

              {/* Main Ascending Cyan Arrow Shaft */}
              <polygon
                points="54,48 64,60 92,26 84,18"
                fill="url(#logoCyan)"
              />

              {/* Cyan Arrowhead pointing up-right */}
              <polygon
                points="78,20 102,14 96,38 88,28"
                fill="url(#logoCyan)"
              />
            </svg>
          </div>

          {/* App Title with Easter Egg Admin Triple Click */}
          <h1
            id="loginTitle"
            onClick={handleTripleClick}
            className="text-3xl sm:text-[34px] font-black text-white tracking-wide cursor-pointer select-none hover:opacity-95 transition-opacity drop-shadow-[0_2px_12px_rgba(255,255,255,0.15)]"
            title="انقر 3 مرات سريعة للوصول الإداري"
          >
            دفتر الديون
          </h1>

          {/* Subtitle */}
          <p className="text-xs sm:text-sm font-medium text-slate-300/80 mt-1.5 tracking-wide">
            نظام إدارة الديون والحسابات المالية
          </p>
        </motion.div>

        {/* Dark Glass Card */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="w-full bg-[#0d1733]/85 backdrop-blur-2xl rounded-[26px] p-6 sm:p-7 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8),0_0_35px_rgba(6,182,212,0.06)] border border-white/[0.08] relative overflow-hidden text-right"
        >
          {/* Top specular highlight line on card */}
          <div className="absolute inset-x-8 top-0 h-[1px] bg-gradient-to-r from-transparent via-white/25 to-transparent pointer-events-none" />

          {/* Error Message */}
          {errorMessage && (
            <div className="mb-4 p-3 bg-rose-950/60 border border-rose-500/30 text-rose-300 text-xs font-semibold rounded-xl flex items-start gap-2.5 animate-in fade-in duration-200">
              <i className="fa-solid fa-circle-exclamation text-rose-400 mt-0.5 shrink-0 text-sm"></i>
              <span className="leading-relaxed">{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            {/* Field: Username */}
            <div>
              <label
                htmlFor="loginUsername"
                className="block text-xs font-medium text-slate-300 mb-2 text-right"
              >
                اسم المستخدم
              </label>

              <div className="relative flex items-center bg-[#132042]/75 hover:bg-[#15254d]/90 focus-within:bg-[#162750] border border-white/[0.1] focus-within:border-cyan-400/40 rounded-2xl p-1.5 transition-all shadow-[inset_0_1px_1px_rgba(255,255,255,0.06),0_4px_12px_rgba(0,0,0,0.25)]">
                {/* Glossy line at top of input */}
                <div className="absolute inset-x-3 top-0 h-[1px] bg-gradient-to-r from-transparent via-white/[0.18] to-transparent pointer-events-none rounded-full" />

                {/* Left Icon Pill: User */}
                <div className="w-10 h-10 rounded-xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center shrink-0 text-slate-400 shadow-inner">
                  <i className="fa-regular fa-user text-sm"></i>
                </div>

                {/* Input text (16px base font on mobile prevents iOS auto-zoom displacement) */}
                <input
                  type="text"
                  id="loginUsername"
                  dir="rtl"
                  autoComplete="off"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  className="flex-1 bg-transparent text-right text-white placeholder:text-slate-400/70 text-base sm:text-sm font-medium outline-none px-3 py-2"
                  placeholder="أدخل اسم المستخدم"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  onFocus={handleInputFocus}
                  disabled={isLoading}
                  required
                />
              </div>
            </div>

            {/* Field: Password */}
            <div>
              <label
                htmlFor="loginPassword"
                className="block text-xs font-medium text-slate-300 mb-2 text-right"
              >
                كلمة المرور
              </label>

              <div className="relative flex items-center bg-[#132042]/75 hover:bg-[#15254d]/90 focus-within:bg-[#162750] border border-white/[0.1] focus-within:border-cyan-400/40 rounded-2xl p-1.5 transition-all shadow-[inset_0_1px_1px_rgba(255,255,255,0.06),0_4px_12px_rgba(0,0,0,0.25)]">
                {/* Glossy line at top of input */}
                <div className="absolute inset-x-3 top-0 h-[1px] bg-gradient-to-r from-transparent via-white/[0.18] to-transparent pointer-events-none rounded-full" />

                {/* Left Icon Pill: Lock */}
                <div className="w-10 h-10 rounded-xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center shrink-0 text-slate-400 shadow-inner">
                  <i className="fa-solid fa-lock text-sm"></i>
                </div>

                {/* Input text (16px base font on mobile prevents iOS auto-zoom displacement) */}
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="loginPassword"
                  dir="rtl"
                  autoComplete="off"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  className="flex-1 bg-transparent text-right text-white placeholder:text-slate-400/70 text-base sm:text-sm font-medium outline-none px-3 py-2"
                  placeholder="أدخل كلمة المرور"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onFocus={handleInputFocus}
                  disabled={isLoading}
                  required
                />

                {/* Right Eye Icon Toggle Button */}
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="pr-3 pl-1 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer text-sm shrink-0"
                  tabIndex={-1}
                  title={showPassword ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                >
                  <i className={`fa-regular ${showPassword ? 'fa-eye text-cyan-400' : 'fa-eye-slash text-slate-400'}`}></i>
                </button>
              </div>
            </div>

            {/* Login Submit Button with Gradient & Arrow */}
            <div className="pt-2">
              <button
                type="submit"
                id="btnLoginSubmit"
                className="w-full py-3.5 px-6 rounded-2xl font-bold text-sm sm:text-base text-white bg-gradient-to-r from-[#1d4ed8] via-[#2563eb] to-[#06b6d4] shadow-[0_8px_25px_-5px_rgba(6,182,212,0.35),0_4px_12px_rgba(29,78,216,0.35)] hover:shadow-[0_10px_30px_-5px_rgba(6,182,212,0.45),0_6px_16px_rgba(29,78,216,0.45)] hover:brightness-105 active:scale-[0.99] transition-all flex items-center justify-center gap-2.5 disabled:opacity-60 disabled:pointer-events-none cursor-pointer border border-white/20"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <i className="fa-solid fa-circle-notch fa-spin text-sm"></i>
                    <span>جاري التحقق...</span>
                  </>
                ) : (
                  <>
                    <span>تسجيل الدخول</span>
                    <i className="fa-solid fa-arrow-right text-base text-white"></i>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Or Divider */}
          <div className="relative my-4 flex items-center justify-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-white/[0.08]"></div>
            </div>
            <span className="relative bg-[#0d1733] px-3 text-[11px] font-semibold text-slate-400">أو</span>
          </div>

          {/* Trial Account Button */}
          <button
            type="button"
            id="btnCreateTrialAccount"
            onClick={() => {
              const trialUser: User = {
                id: 999999,
                username: 'حساب تجريبي',
                role: 'trial',
                branch_name: 'حساب تجريبي (محلي)',
                subscriptionType: 'trial',
                subscriptionExpiresAt: null,
                isActive: true,
              };
              setLocalSession(trialUser);
              onLoginSuccess(trialUser);
            }}
            className="w-full py-3 px-4 rounded-2xl font-bold text-xs sm:text-sm text-cyan-200 bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/30 hover:border-cyan-400/60 shadow-[0_4px_15px_rgba(6,182,212,0.15)] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <i className="fa-solid fa-flask text-cyan-400 text-sm"></i>
            <span>إنشاء حساب تجريبي (تجربة مجانية)</span>
          </button>

          {/* Subtle Horizontal Divider */}
          <div className="h-px w-full bg-gradient-to-r from-transparent via-white/[0.08] to-transparent my-4" />

          {/* Footer Security Guarantee with Cyan Key Shield */}
          <div className="flex items-center justify-center gap-2 text-xs font-medium text-slate-400">
            <span>بياناتك محفوظة وآمنة</span>
            <svg
              className="w-4 h-4 text-cyan-400 shrink-0"
              viewBox="0 0 24 24"
              fill="currentColor"
            >
              <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 6c1.4 0 2.5 1.1 2.5 2.5 0 .9-.5 1.7-1.2 2.1l.7 3.4h-4l.7-3.4c-.7-.4-1.2-1.2-1.2-2.1 0-1.4 1.1-2.5 2.5-2.5z"/>
            </svg>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
