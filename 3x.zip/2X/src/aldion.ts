// ملف إعدادات قاعدة البيانات السحابية (Turso)
// يمكنك تغيير الرابط والرمز السري (Token) هنا في أي وقت بكل سهولة وبشكل يدوي:
export const ALDION_DATABASE_CONFIG = {
  // 1. رابط قاعدة البيانات (Database URL)
  url: "https://aldion-dftr-admin5500.aws-ap-south-1.turso.io/v2/pipeline",

  // 2. الرمز السري للاتصال (Auth Token)
  token: "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhIjoicnciLCJpYXQiOjE3ODg4NjgxMTEsImlkIjoiMDFhMDgwYTYtYzMwMS03YmZiLWE4NTctMGI0NmY3ZTE1MGU4Iiwia2lkIjoicVgwQWp4cHB2X3pqT0RrSmduQW0zS2t2eXlQRTBDdXBjR05XaVgtSGFaRSIsInJpZCI6IjNmMjU4NmU0LTVlYWMtNDdhYS1iYjNlLTEyMTlmNDZlMzZlNiJ9.CYjUk5ao4E-oHVEC3vTbn2WP9KJZ-60suoA2DdcDE_2sfXtBIhNhqXAn5JzTK5RDpsECOnBGoHCApHSVzOK6DQ",
};
