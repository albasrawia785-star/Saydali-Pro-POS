import { AppSettings, Debtor, DebtorTransaction, Manager, User } from '../types';
import { ALDION_DATABASE_CONFIG } from '../aldion';

let isProxySupported: boolean | null = null;

export async function queryTurso(sql: string, args: (string | number | null | undefined)[] = []) {
  const trimmedSql = sql.trim();

  // 1. If proxy is known to work (or not yet determined), try /api/turso
  if (isProxySupported !== false) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      const proxyRes = await fetch('/api/turso', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ sql: trimmedSql, args }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      // Check if proxy response is JSON and ok
      const contentType = proxyRes.headers.get('content-type') || '';
      if (proxyRes.ok && contentType.includes('application/json')) {
        isProxySupported = true;
        const data = await proxyRes.json();
        if (data.results && data.results[0] && data.results[0].type === 'error') {
          throw new Error(data.results[0].error?.message || 'حدث خطأ غير معروف في القاعدة');
        }
        return data;
      }

      // If 404 or HTML fallback (static hosts), mark proxy as unavailable
      if (proxyRes.status === 404 || contentType.includes('text/html')) {
        isProxySupported = false;
      }
    } catch {
      // If network error or timeout contacting local proxy, mark as false and fallback to Direct
      if (isProxySupported === null) {
        isProxySupported = false;
      }
    }
  }

  // 2. Direct Query to Turso HTTP pipeline (Native CORS support - Works on any static host or environment)
  const targetUrl =
    (typeof import.meta !== 'undefined' && ((import.meta as any).env?.VITE_TURSO_DATABASE_URL || (import.meta as any).env?.VITE_TURSO_URL)) ||
    ALDION_DATABASE_CONFIG.url;

  const targetToken =
    (typeof import.meta !== 'undefined' && ((import.meta as any).env?.VITE_TURSO_AUTH_TOKEN || (import.meta as any).env?.VITE_TURSO_TOKEN)) ||
    ALDION_DATABASE_CONFIG.token;

  if (!targetUrl || !targetToken) {
    throw new Error('إعدادات قاعدة البيانات السحابية غير متوفرة');
  }

  const formattedArgs = args.map((a: any) => {
    if (typeof a === 'number') {
      return Number.isInteger(a)
        ? { type: 'integer', value: String(a) }
        : { type: 'float', value: String(a) };
    }
    return { type: 'text', value: String(a ?? '') };
  });

  const response = await fetch(targetUrl, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${targetToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      requests: [
        { type: 'execute', stmt: { sql: trimmedSql, args: formattedArgs } },
        { type: 'close' },
      ],
    }),
  });

  if (!response.ok) {
    const errText = await response.text().catch(() => '');
    throw new Error(`خطأ في الاتصال بالسحابة (${response.status}): ${errText}`);
  }

  const data = await response.json();
  if (data.results && data.results[0] && data.results[0].type === 'error') {
    throw new Error(data.results[0].error?.message || 'حدث خطأ في قاعدة البيانات');
  }

  return data;
}

// Local Storage helpers
export function getLocalDebtors(userId: number): Debtor[] | null {
  const data = localStorage.getItem(`debtors_user_${userId}`);
  return data ? JSON.parse(data) : null;
}

export function setLocalDebtors(userId: number, debtors: Debtor[]) {
  localStorage.setItem(`debtors_user_${userId}`, JSON.stringify(debtors));
}

export function getLocalUsers(): User[] | null {
  const data = localStorage.getItem("local_users");
  return data ? JSON.parse(data) : null;
}

export function setLocalUsers(users: User[]) {
  // Strip sensitive passwords before saving in localStorage
  const safeUsers = users.map(({ password: _, ...u }) => u as User);
  localStorage.setItem("local_users", JSON.stringify(safeUsers));
}

export function getLocalSession(): User | null {
  try {
    const data = localStorage.getItem("session_user");
    if (!data) return null;
    const user: User = JSON.parse(data);
    if (!user) return null;

    // If sub-manager, verify if flagged for forced suspension
    if (user.role !== 'admin' && user.id) {
      const forceLogout = localStorage.getItem(`force_logout_user_${user.id}`);
      if (forceLogout) {
        localStorage.removeItem("session_user");
        return null;
      }
      const managersData = localStorage.getItem("local_managers_list");
      if (managersData) {
        const managers: Manager[] = JSON.parse(managersData);
        const found = managers.find((m) => m.id === user.id);
        if (found && found.isActive === false) {
          localStorage.removeItem("session_user");
          return null;
        }
      }
    }
    // Ensure password is reconstructed from cached storage if available
    if (!user.password) {
      const cachedPass = localStorage.getItem(`user_pwd_${user.id}`) || localStorage.getItem(`user_pwd_${user.username}`);
      if (cachedPass) {
        user.password = cachedPass;
      }
    }

    return user;
  } catch {
    return null;
  }
}

export function setLocalSession(user: User | null) {
  if (user) {
    localStorage.setItem("session_user", JSON.stringify(user));
    if (user.password) {
      localStorage.setItem(`user_pwd_${user.id}`, user.password);
      localStorage.setItem(`user_pwd_${user.username}`, user.password);
    }
  } else {
    localStorage.removeItem("session_user");
  }
}

// Multi-tab synchronization for instant logout
export const sessionBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('submanager_auth_sync')
    : null;

// Multi-tab synchronization for real-time debtors sync
export const debtorsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('debtors_realtime_sync')
    : null;

export function broadcastDebtorsChange(userId: number, actionType?: string) {
  try {
    if (debtorsBroadcastChannel) {
      debtorsBroadcastChannel.postMessage({
        type: 'DEBTORS_UPDATED',
        userId,
        actionType,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastManagerStatusChange(targetUserId: number, isActive: boolean, reason?: string) {
  try {
    if (!isActive) {
      localStorage.setItem(
        `force_logout_user_${targetUserId}`,
        JSON.stringify({
          timestamp: Date.now(),
          reason: reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً',
        })
      );
      // If current saved session belongs to target, drop it immediately
      const current = getLocalSession();
      if (current && current.id === targetUserId) {
        localStorage.removeItem("session_user");
      }
    } else {
      localStorage.removeItem(`force_logout_user_${targetUserId}`);
    }

    if (sessionBroadcastChannel) {
      sessionBroadcastChannel.postMessage({
        type: isActive ? 'MANAGER_ACTIVATED' : 'FORCE_LOGOUT',
        targetUserId,
        reason: reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً',
      });
    }
  } catch (e) {
    console.warn('Broadcast error:', e);
  }
}

export function getLocalManagers(): Manager[] | null {
  const data = localStorage.getItem("local_managers_list");
  return data ? JSON.parse(data) : null;
}

export function setLocalManagers(managers: Manager[]) {
  localStorage.setItem("local_managers_list", JSON.stringify(managers));
}

export const DEFAULT_SETTINGS: AppSettings = {
  enableDebtAlerts: true,
  alertDaysThreshold: 1, // Alerts trigger if debt age >= 1 day
  highDebtThreshold: 25000, // Default 25,000 IQD
};

export function getLocalSettings(userId: number): AppSettings {
  try {
    const raw = localStorage.getItem(`app_settings_user_${userId}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        enableDebtAlerts: parsed.enableDebtAlerts ?? true,
        alertDaysThreshold: parsed.alertDaysThreshold ?? 1,
        highDebtThreshold: parsed.highDebtThreshold ?? 25000,
      };
    }
  } catch (e) {
    console.error("Error reading local settings:", e);
  }
  return { ...DEFAULT_SETTINGS };
}

export function setLocalSettings(userId: number, settings: AppSettings) {
  try {
    localStorage.setItem(`app_settings_user_${userId}`, JSON.stringify(settings));
  } catch (e) {
    console.error("Error saving local settings:", e);
  }
}

export function getLocalDebtorDates(userId: number): Record<number, string> {
  try {
    const raw = localStorage.getItem(`debtor_dates_user_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setLocalDebtorDates(userId: number, dates: Record<number, string>) {
  try {
    localStorage.setItem(`debtor_dates_user_${userId}`, JSON.stringify(dates));
  } catch (e) {
    console.error("Error saving debtor dates:", e);
  }
}

export function getLocalDebtorHistory(userId: number): Record<number, DebtorTransaction[]> {
  try {
    const raw = localStorage.getItem(`debtor_history_user_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setLocalDebtorHistory(userId: number, historyMap: Record<number, DebtorTransaction[]>) {
  try {
    localStorage.setItem(`debtor_history_user_${userId}`, JSON.stringify(historyMap));
  } catch (e) {
    console.error("Error saving debtor history:", e);
  }
}

