import { Debtor, DebtStats, AppSettings, Manager } from '../types';
import { DEFAULT_SETTINGS } from './turso';

const DB_NAME = 'DaftarAldionDB';
const DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase> | null = null;

function getDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return reject(new Error('IndexedDB غير مدعوم في هذا المتصفح'));
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Object store for debtors
      if (!db.objectStoreNames.contains('debtors')) {
        const debtorStore = db.createObjectStore('debtors', { keyPath: 'id' });
        debtorStore.createIndex('userId', 'userId', { unique: false });
      }

      // Key-Value store for user settings, stats, managers, metadata
      if (!db.objectStoreNames.contains('keyval')) {
        db.createObjectStore('keyval', { keyPath: 'key' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });

  return dbPromise;
}

// ---------------------- DEBTORS CRUD ----------------------

export async function getIdbDebtors(userId: number): Promise<Debtor[] | null> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('debtors', 'readonly');
      const store = tx.objectStore('debtors');
      const index = store.index('userId');
      const request = index.getAll(userId);

      request.onsuccess = () => {
        const result = request.result;
        // Return null if none found in IDB (so caller can check migration from localStorage)
        resolve(result && result.length > 0 ? result : null);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('IDB read error (falling back):', err);
    return null;
  }
}

export async function saveIdbDebtors(userId: number, debtors: Debtor[]): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('debtors', 'readwrite');
    const store = tx.objectStore('debtors');

    // First delete existing debtors for this user, then put new ones
    const index = store.index('userId');
    const getKeysReq = index.getAllKeys(userId);

    getKeysReq.onsuccess = () => {
      const keys = getKeysReq.result;
      keys.forEach((k) => store.delete(k));
      debtors.forEach((d) => {
        store.put({ ...d, userId });
      });
    };

    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB save debtors error:', err);
  }
}

export async function putIdbDebtor(debtor: Debtor): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('debtors', 'readwrite');
    const store = tx.objectStore('debtors');
    store.put(debtor);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB put debtor error:', err);
  }
}

export async function deleteIdbDebtor(debtorId: number): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('debtors', 'readwrite');
    const store = tx.objectStore('debtors');
    store.delete(debtorId);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB delete debtor error:', err);
  }
}

// ---------------------- KEY-VALUE (STATS, SETTINGS, MANAGERS) ----------------------

async function getIdbKeyVal<T>(key: string): Promise<T | null> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('keyval', 'readonly');
      const store = tx.objectStore('keyval');
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result ? req.result.value : null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

async function setIdbKeyVal<T>(key: string, value: T): Promise<void> {
  try {
    const db = await getDB();
    const tx = db.transaction('keyval', 'readwrite');
    const store = tx.objectStore('keyval');
    store.put({ key, value });
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IDB set keyval error:', err);
  }
}

export async function getIdbStats(userId: number): Promise<DebtStats | null> {
  return getIdbKeyVal<DebtStats>(`stats_user_${userId}`);
}

export async function saveIdbStats(userId: number, stats: DebtStats): Promise<void> {
  return setIdbKeyVal(`stats_user_${userId}`, stats);
}

export async function getIdbSettings(userId: number): Promise<AppSettings | null> {
  return getIdbKeyVal<AppSettings>(`settings_user_${userId}`);
}

export async function saveIdbSettings(userId: number, settings: AppSettings): Promise<void> {
  return setIdbKeyVal(`settings_user_${userId}`, settings);
}

export async function getIdbManagers(): Promise<Manager[] | null> {
  return getIdbKeyVal<Manager[]>('managers_list');
}

export async function saveIdbManagers(managers: Manager[]): Promise<void> {
  return setIdbKeyVal('managers_list', managers);
}
