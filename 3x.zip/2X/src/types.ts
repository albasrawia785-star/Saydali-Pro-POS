export type SubscriptionType = 'permanent' | 'monthly' | 'trial';

export interface User {
  id: number;
  username: string;
  role: 'admin' | 'manager' | string;
  branch_name: string;
  password?: string;
  isActive?: boolean;
  subscriptionType?: SubscriptionType;
  subscriptionExpiresAt?: string | null;
}

export interface DebtorTransaction {
  id: string;
  debtorId: number;
  type: 'initial' | 'add' | 'pay';
  amount: number;
  balanceAfter: number;
  date: string;
  description?: string;
  notes?: string;
}

export interface Debtor {
  id: number;
  name: string;
  phone: string;
  amount: number;
  status: string;
  userId: number;
  createdAt?: string;
  lastDebtDate?: string;
  notes?: string;
  history?: DebtorTransaction[];
  isDemo?: boolean;
}

export interface Manager {
  id: number;
  username: string;
  branch: string;
  isActive: boolean;
  subscriptionType: SubscriptionType;
  subscriptionExpiresAt?: string | null;
  createdAt?: string;
  plainPassword?: string;
}

export type TabType = 'home' | 'reports' | 'overdue' | 'settings' | 'managers';

export type FilterType = 'all' | 'debtors_only' | 'paid_only' | 'high_debt';

export type ViewMode = 'cards' | 'list';

export interface DebtStats {
  totalAdded: number;
  totalPaid: number;
}

export interface AppSettings {
  enableDebtAlerts: boolean;
  alertDaysThreshold: number; // e.g. 1, 2, 7 days
  highDebtThreshold: number; // e.g. 25000 IQD
}
