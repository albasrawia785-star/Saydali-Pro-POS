import React from 'react';
import { AppSettings, Debtor, DebtStats, User } from '../types';
import { formatNumber, calculateDaysElapsed } from '../utils/formatters';

interface ReportsTabProps {
  currentUser: User;
  debtors: Debtor[];
  stats: DebtStats;
  settings?: AppSettings;
  onUpdateStats?: (newStats: DebtStats) => void;
  onResetStats?: () => void;
}

export const ReportsTab: React.FC<ReportsTabProps> = ({
  currentUser,
  debtors,
  stats,
  settings,
  onResetStats,
}) => {
  // Check if there are no debtors
  const hasNoDebtors = debtors.length === 0;

  // Current active debts sum
  const currentDebts = hasNoDebtors ? 0 : debtors.reduce((sum, d) => sum + (d.amount || 0), 0);

  // If there are no debtors at all, stats are completely zeroed out
  const totalPaid = hasNoDebtors ? 0 : Math.max(0, stats.totalPaid || 0);
  const totalAdded = hasNoDebtors ? 0 : Math.max(stats.totalAdded || 0, currentDebts + totalPaid);
  const netDebt = hasNoDebtors ? 0 : Math.max(0, totalAdded - totalPaid);

  // Collection percentage: (totalPaid / totalAdded) * 100
  const collectionRate = (!hasNoDebtors && totalAdded > 0) ? (totalPaid / totalAdded) * 100 : 0;
  // Format percentage with comma as in screenshot: "%35,7"
  const collectionRateFormatted = collectionRate.toFixed(1).replace('.', ',');

  const alertThreshold = settings?.alertDaysThreshold ?? 1;
  const isAlertEnabled = settings?.enableDebtAlerts ?? true;

  // Count debtors and overdue (matches OverdueTab calculation)
  const debtorsCount = hasNoDebtors ? 0 : debtors.length;
  const overdueCount = hasNoDebtors
    ? 0
    : debtors.filter((d) => {
        if (d.amount <= 0 || d.status === 'خالي من الدين') return false;
        if (d.status === 'متأخر') return true;
        if (isAlertEnabled) {
          const days = calculateDaysElapsed(d.createdAt);
          return days >= alertThreshold;
        }
        return false;
      }).length;

  // Top debtors sorted by debt descending
  const topDebtors = [...debtors]
    .filter((d) => (d.amount || 0) > 0)
    .sort((a, b) => b.amount - a.amount)
    .slice(0, 5);

  return (
    <div id="tab-reports" className="pb-20 space-y-3.5 animate-in fade-in duration-150">
      {/* Top Header - Sticky */}
      <div className="sticky top-0 z-30 bg-slate-50/95 backdrop-blur-md px-4 pt-3.5 pb-2.5 border-b border-slate-200/60 shadow-[0_4px_12px_-4px_rgba(0,0,0,0.05)] text-right">
        <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
          التقارير والإحصائيات
        </h1>
        <p className="text-xs font-medium text-slate-500 mt-0.5">
          {currentUser.branch_name || 'محل الديون والخدمات'} - إدارة الديون والمدينين
        </p>
      </div>

      <div className="px-4 space-y-3.5">
        {/* 1. إجمالي الديون القائمة */}
        <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs flex items-center justify-between transition-all">
        <div className="text-right">
          <div className="text-xs font-semibold text-slate-500">إجمالي الديون القائمة</div>
          <div className="text-base sm:text-lg font-bold text-slate-900 font-mono my-1 tracking-tight">
            {formatNumber(currentDebts)} <span className="text-xs font-semibold text-slate-500">د.ع</span>
          </div>
          <div className="text-[11px] text-slate-400">
            مجموع الديون الحالية المترتبة على جميع المدينين
          </div>
        </div>

        <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center text-xl shrink-0">
          <i className="fa-solid fa-building-columns"></i>
        </div>
      </div>

      {/* 2. عدد المدينين & عدد المتأخرين */}
      <div className="grid grid-cols-2 gap-3">
        {/* Right card: عدد المدينين */}
        <div className="bg-white rounded-3xl p-4 border border-slate-100 shadow-xs flex flex-col items-center text-center">
          <div className="w-11 h-11 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center text-base mb-2">
            <i className="fa-solid fa-user-group"></i>
          </div>
          <div className="text-xs font-medium text-slate-500 mb-1">عدد المدينين</div>
          <div className="text-base font-black text-slate-900 font-mono">
            {debtorsCount} مدين
          </div>
        </div>

        {/* Left card: عدد المتأخرين */}
        <div className="bg-white rounded-3xl p-4 border border-slate-100 shadow-xs flex flex-col items-center text-center">
          <div className="w-11 h-11 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center text-base mb-2">
            <i className="fa-solid fa-hourglass-half"></i>
          </div>
          <div className="text-xs font-medium text-slate-500 mb-1">عدد المتأخرين</div>
          <div className="text-base font-black text-slate-900 font-mono">
            {overdueCount} متأخر
          </div>
        </div>
      </div>

      {/* 3. نسبة تحصيل الديون */}
      <div className="bg-white rounded-3xl p-4 border border-slate-100 shadow-xs">
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-sm font-bold text-slate-900">نسبة تحصيل الديون</span>
          <span className="text-sm font-black text-emerald-500 font-mono dir-ltr">
            %{collectionRateFormatted}
          </span>
        </div>

        {/* Progress Bar (in RTL, starts from the right) */}
        <div className="w-full h-2.5 bg-emerald-100/60 rounded-full overflow-hidden flex flex-row">
          <div
            style={{ width: `${Math.min(100, Math.max(0, collectionRate))}%` }}
            className="h-full bg-emerald-500 rounded-full transition-all duration-500"
          />
        </div>
      </div>

      {/* 4. إجمالي الديون المضافة */}
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs flex items-center justify-between transition-all">
        <div className="text-right">
          <div className="text-xs font-semibold text-slate-500">إجمالي الديون المضافة</div>
          <div className="text-2xl font-black text-slate-900 font-mono my-1 tracking-tight">
            {formatNumber(totalAdded)} <span className="text-base font-bold">د.ع</span>
          </div>
          <div className="text-[11px] text-slate-400">
            مجموع كافة الديون المسجلة لجميع المدينين
          </div>
        </div>

        <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center text-xl shrink-0">
          <i className="fa-solid fa-arrow-trend-up"></i>
        </div>
      </div>

      {/* 5. إجمالي المبالغ المسددة */}
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs flex items-center justify-between transition-all">
        <div className="text-right">
          <div className="text-xs font-semibold text-slate-500">إجمالي المبالغ المسددة</div>
          <div className="text-2xl font-black text-slate-900 font-mono my-1 tracking-tight">
            {formatNumber(totalPaid)} <span className="text-base font-bold">د.ع</span>
          </div>
          <div className="text-[11px] text-slate-400">
            مجموع التحصيلات والتسديدات المستلمة من جميع المدينين
          </div>
        </div>

        <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center text-xl shrink-0">
          <i className="fa-solid fa-money-bill-wave"></i>
        </div>
      </div>

      {/* 6. صافي الديون الحالي */}
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs flex items-center justify-between transition-all">
        <div className="text-right">
          <div className="text-xs font-semibold text-slate-500">صافي الديون الحالي</div>
          <div className="text-2xl font-black text-slate-900 font-mono my-1 tracking-tight">
            {formatNumber(netDebt)} <span className="text-base font-bold">د.ع</span>
          </div>
          <div className="text-[11px] text-slate-400">
            الفارق المتبقي بين المبالغ المضافة والمبالغ المسددة
          </div>
        </div>

        <div className="w-12 h-12 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center text-xl shrink-0">
          <i className="fa-solid fa-chart-simple"></i>
        </div>
      </div>

      {/* 7. أعلى المدينين ديناً */}
      <div className="bg-white rounded-3xl p-5 border border-slate-100 shadow-xs">
        <h4 className="text-base font-bold text-slate-900 mb-3 text-right">
          أعلى المدينين ديناً
        </h4>

        {topDebtors.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-400">
            لا توجد ديون قائمة حالياً
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {topDebtors.map((debtor, index) => (
              <div
                key={debtor.id}
                className="flex items-center justify-between py-3 first:pt-1 last:pb-1"
              >
                <div className="flex items-center gap-3">
                  <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-600 font-bold text-xs flex items-center justify-center font-mono shrink-0">
                    {index + 1}
                  </div>
                  <span className="text-sm font-bold text-slate-800">
                    {debtor.name}
                  </span>
                </div>

                <div className="text-sm font-black text-red-500 font-mono">
                  {formatNumber(debtor.amount)} د.ع
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Zero Debtors Banner */}
      {hasNoDebtors && (
        <div className="bg-slate-50 border border-slate-200/80 rounded-3xl p-4 text-center text-xs text-slate-600 font-medium flex items-center justify-center gap-2">
          <i className="fa-solid fa-circle-check text-blue-600 text-sm"></i>
          <span>سجل المدينين فارغ حالياً — كافة إحصائيات وأرقام التقارير مصفّرة.</span>
        </div>
      )}

      {/* Reset Stats Button (if user has stats and wants to restart accounting cycle) */}
      {onResetStats && (
        <div className="pt-2">
          <button
            type="button"
            onClick={onResetStats}
            className="w-full bg-slate-100 hover:bg-slate-200 active:scale-[0.99] text-slate-600 py-3 rounded-2xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer border border-slate-200/80"
          >
            <i className="fa-solid fa-arrows-rotate text-xs text-slate-500"></i>
            <span>تصفير سجل التقارير والإحصائيات التراكمية</span>
          </button>
        </div>
      )}
      </div>
    </div>
  );
};
