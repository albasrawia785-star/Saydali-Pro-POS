import React, { useState } from 'react';
import { Manager, SubscriptionType } from '../types';
import { formatDateArabic, getSubscriptionDaysRemaining, isSubscriptionExpired } from '../utils/formatters';

interface ManagersTabProps {
  managers: Manager[];
  onCreateManager: (
    branch: string,
    user: string,
    pass: string,
    subscriptionType: SubscriptionType,
    subscriptionMonths?: number
  ) => Promise<void>;
  onToggleManagerStatus: (id: number, currentActive: boolean) => Promise<void>;
  onRenewSubscription: (id: number, months?: number) => Promise<void>;
  onDeleteManager: (id: number) => void;
  onUpdateManagerPassword?: (id: number, newPass: string) => Promise<void>;
  onRefreshManagers?: () => Promise<void> | void;
  isLoading?: boolean;
}

export const ManagersTab: React.FC<ManagersTabProps> = ({
  managers,
  onCreateManager,
  onToggleManagerStatus,
  onRenewSubscription,
  onDeleteManager,
  onUpdateManagerPassword,
  onRefreshManagers,
  isLoading = false,
}) => {
  const [branchName, setBranchName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [subscriptionType, setSubscriptionType] = useState<SubscriptionType>('permanent');
  const [subscriptionMonths, setSubscriptionMonths] = useState<number>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [actionInProgressId, setActionInProgressId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [revealedPasswords, setRevealedPasswords] = useState<Record<number, boolean>>({});
  const [copiedManagerId, setCopiedManagerId] = useState<number | null>(null);
  const [shareSuccessManagerId, setShareSuccessManagerId] = useState<number | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Password editing state for Admin
  const [editingPasswordManagerId, setEditingPasswordManagerId] = useState<number | null>(null);
  const [editingPasswordInput, setEditingPasswordInput] = useState('');
  const [isSavingPasswordId, setIsSavingPasswordId] = useState<number | null>(null);

  const togglePasswordVisibility = (id: number) => {
    setRevealedPasswords((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopyManagerPassword = (id: number, pwd: string) => {
    try {
      navigator.clipboard.writeText(pwd);
      setCopiedManagerId(id);
      setTimeout(() => setCopiedManagerId(null), 2000);
    } catch {
      // Fallback
    }
  };

  // Share login credentials via WhatsApp & Clipboard
  const handleShareCredentials = (mgr: Manager, pwd: string) => {
    const branchName = mgr.branch || 'الفرع';
    const message = `مرحباً بك مدير فرع (${branchName})،\nإليك بيانات تسجيل الدخول لحسابك:\n• اسم المستخدم: ${mgr.username}\n• الرمز السري: ${pwd}\n\nيرجى تسجيل الدخول للنظام والاحتفاظ ببياناتك.`;

    try {
      navigator.clipboard.writeText(message);
    } catch {}

    const url = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');

    setShareSuccessManagerId(mgr.id);
    setTimeout(() => setShareSuccessManagerId(null), 3000);
  };

  // Save new password set by Admin
  const handleSavePasswordByAdmin = async (mgrId: number) => {
    const trimmed = editingPasswordInput.trim();
    if (!trimmed) {
      alert('يرجى كتابة الرمز السري الجديد');
      return;
    }
    if (trimmed.length < 3) {
      alert('الرمز السري يجب ألا يقل عن 3 خانات');
      return;
    }
    if (!onUpdateManagerPassword) return;

    try {
      setIsSavingPasswordId(mgrId);
      await onUpdateManagerPassword(mgrId, trimmed);
      setEditingPasswordManagerId(null);
      setEditingPasswordInput('');
    } catch (err: any) {
      alert(err.message || 'فشل حفظ الرمز السري');
    } finally {
      setIsSavingPasswordId(null);
    }
  };

  // Calculate preview expiration date for monthly subscriptions
  const getPreviewExpiryDate = (months: number): string => {
    const d = new Date();
    d.setMonth(d.getMonth() + months);
    return formatDateArabic(d.toISOString());
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const b = branchName.trim();
    const u = username.trim();
    const p = password.trim();

    if (!b || !u || !p) {
      setError("يرجى ملء جميع الحقول الخاصة بالمدير الفرعي");
      return;
    }

    try {
      setIsSubmitting(true);
      await onCreateManager(b, u, p, subscriptionType, subscriptionMonths);
      setBranchName('');
      setUsername('');
      setPassword('');
      setSubscriptionType('permanent');
      setSubscriptionMonths(1);
    } catch (err: any) {
      setError(err.message || "حدث خطأ أثناء الإنشاء");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggle = async (id: number, currentActive: boolean) => {
    try {
      setActionInProgressId(id);
      await onToggleManagerStatus(id, currentActive);
    } finally {
      setActionInProgressId(null);
    }
  };

  const handleRenew = async (id: number, months: number = 1) => {
    try {
      setActionInProgressId(id);
      await onRenewSubscription(id, months);
    } finally {
      setActionInProgressId(null);
    }
  };

  const activeCount = managers.filter((m) => m.isActive !== false).length;
  const suspendedCount = managers.filter((m) => m.isActive === false).length;
  const monthlyCount = managers.filter((m) => m.subscriptionType === 'monthly').length;

  return (
    <div id="tab-managers" className="space-y-4 text-right">
      <div className="bg-white rounded-2xl p-1">
        {/* Add Manager Form */}
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 mb-5">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <i className="fa-solid fa-user-plus text-[12px] text-blue-600"></i>
              <span>إضافة مدير فرعي جديد</span>
            </h4>
            <span className="text-[10px] text-slate-400 font-medium">صلاحيات فروع مستقلة</span>
          </div>

          {error && (
            <div className="mb-3 p-2.5 bg-red-50 border border-red-200 text-red-600 text-xs rounded-xl flex items-center gap-2">
              <i className="fa-solid fa-circle-exclamation text-xs shrink-0"></i>
              <span className="font-medium">{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">اسم الفرع / المتجر</label>
                <input
                  type="text"
                  id="newBranchName"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-blue-600 text-slate-800 transition-all font-medium"
                  placeholder="مثال: أسواق أبو علي"
                  value={branchName}
                  onChange={(e) => setBranchName(e.target.value)}
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">اسم المستخدم للدخول</label>
                <input
                  type="text"
                  id="newUsername"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-blue-600 text-slate-800 transition-all font-mono"
                  placeholder="مثال: abu_ali"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  disabled={isSubmitting}
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">كلمة المرور</label>
              <input
                type="password"
                id="newPassword"
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs outline-none focus:border-blue-600 text-slate-800 transition-all"
                placeholder="كلمة مرور قوية"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isSubmitting}
              />
            </div>

            {/* Subscription Type Selector (نوع الاشتراك) */}
            <div className="pt-1">
              <label className="block text-[11px] font-bold text-slate-700 mb-1.5 flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <i className="fa-solid fa-crown text-amber-500 text-[11px]"></i>
                  <span>نوع الاشتراك:</span>
                </span>
                <span className="text-[10px] text-slate-400 font-normal">اختر نمط ترخيص المدير</span>
              </label>

              <div className="grid grid-cols-2 gap-2.5">
                {/* Permanent Option */}
                <button
                  type="button"
                  onClick={() => setSubscriptionType('permanent')}
                  className={`p-3 rounded-xl border text-right transition-all cursor-pointer flex flex-col gap-1 ${
                    subscriptionType === 'permanent'
                      ? 'bg-blue-50/70 border-blue-500 ring-1 ring-blue-500 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                      <i className="fa-solid fa-infinity text-blue-600"></i>
                      <span>اشتراك دائمي</span>
                    </span>
                    {subscriptionType === 'permanent' && (
                      <i className="fa-solid fa-circle-check text-blue-600 text-xs"></i>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-500 leading-tight">
                    مفتوح وغير مقيد بمدة صلاحية
                  </span>
                </button>

                {/* Monthly Option */}
                <button
                  type="button"
                  onClick={() => setSubscriptionType('monthly')}
                  className={`p-3 rounded-xl border text-right transition-all cursor-pointer flex flex-col gap-1 ${
                    subscriptionType === 'monthly'
                      ? 'bg-purple-50/70 border-purple-500 ring-1 ring-purple-500 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                      <i className="fa-solid fa-calendar-days text-purple-600"></i>
                      <span>اشتراك شهري</span>
                    </span>
                    {subscriptionType === 'monthly' && (
                      <i className="fa-solid fa-circle-check text-purple-600 text-xs"></i>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-500 leading-tight">
                    يتطلب تجديداً دورياً من الإدارة
                  </span>
                </button>
              </div>

              {/* Monthly Sub-Options: Duration Picker */}
              {subscriptionType === 'monthly' && (
                <div className="mt-2.5 p-2.5 bg-purple-50/50 border border-purple-200/70 rounded-xl space-y-2 animate-in fade-in duration-150">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-purple-900 text-[11px]">مدة الاشتراك الممنوحة:</span>
                    <span className="text-[10px] font-mono font-bold text-purple-700 bg-white px-2 py-0.5 rounded-md border border-purple-200">
                      ينتهي في: {getPreviewExpiryDate(subscriptionMonths)}
                    </span>
                  </div>

                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      { label: 'شهر واحد', months: 1 },
                      { label: '3 أشهر', months: 3 },
                      { label: '6 أشهر', months: 6 },
                      { label: 'سنة كاملة', months: 12 },
                    ].map((item) => (
                      <button
                        key={item.months}
                        type="button"
                        onClick={() => setSubscriptionMonths(item.months)}
                        className={`py-1.5 px-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                          subscriptionMonths === item.months
                            ? 'bg-purple-700 text-white shadow-xs'
                            : 'bg-white text-slate-700 border border-purple-200 hover:bg-purple-100/50'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#006940] hover:bg-[#005735] active:scale-98 text-white py-2.5 rounded-xl font-bold text-xs shadow-sm shadow-[#006940]/20 cursor-pointer transition-all flex items-center justify-center gap-2 disabled:opacity-50 mt-2"
            >
              {isSubmitting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                  <span>جاري إنشاء الحساب...</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-plus text-xs"></i>
                  <span>إنشاء حساب المدير الفرعي</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Status Counters Bar */}
        <div className="grid grid-cols-3 gap-2 mb-3">
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-2 text-center">
            <div className="text-[10px] text-slate-500 font-medium">إجمالي المدراء</div>
            <div className="font-black text-sm text-slate-900 font-mono mt-0.5">{managers.length}</div>
          </div>
          <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-xl p-2 text-center">
            <div className="text-[10px] text-emerald-800 font-medium">الحسابات النشطة</div>
            <div className="font-black text-sm text-emerald-700 font-mono mt-0.5">{activeCount}</div>
          </div>
          <div className="bg-amber-50/70 border border-amber-200/80 rounded-xl p-2 text-center">
            <div className="text-[10px] text-amber-800 font-medium">الموقوفة مؤقتاً</div>
            <div className="font-black text-sm text-amber-700 font-mono mt-0.5">{suspendedCount}</div>
          </div>
        </div>

        {/* Managers List Header */}
        <div className="flex items-center justify-between mb-2.5">
          <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <i className="fa-solid fa-list-check text-[11px] text-blue-600"></i>
            <span>قائمة الفروع والرموز السرية للمدراء ({managers.length})</span>
          </h4>
          <div className="flex items-center gap-2">
            {onRefreshManagers && (
              <button
                type="button"
                onClick={async () => {
                  setIsRefreshing(true);
                  try {
                    await onRefreshManagers();
                  } finally {
                    setIsRefreshing(false);
                  }
                }}
                disabled={isRefreshing || isLoading}
                className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-[11px] font-bold border border-blue-200/80 flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 disabled:opacity-50"
                title="تحديث البيانات من السحابة وجلب أحدث الرموز السرية"
              >
                <i className={`fa-solid fa-arrows-rotate text-[10px] ${isRefreshing || isLoading ? 'fa-spin' : ''}`}></i>
                <span>تحديث الرموز</span>
              </button>
            )}
            {isLoading && <i className="fa-solid fa-spinner fa-spin text-blue-600 text-xs"></i>}
          </div>
        </div>

        {/* Cloud sync tip */}
        <div className="mb-3 p-2.5 bg-blue-50/70 border border-blue-200/80 rounded-2xl flex items-start gap-2 text-[11px] text-blue-900">
          <i className="fa-solid fa-shield-halved text-blue-600 text-sm mt-0.5 shrink-0"></i>
          <div>
            <span className="font-bold">استرجاع ومتابعة الرموز السرية:</span> في حال قام أي مدير فرعي بتغيير رمزه السري، يتم حفظه وتحديثه فوراً في السحابة ليظهر لك هنا، حتى تتمكن من إرساله له أو إعادة تعيينه إذا نسيه.
          </div>
        </div>

        {/* Managers Cards List */}
        <div className="flex flex-col gap-2.5" id="managersListContainer">
          {managers.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
              <i className="fa-solid fa-users text-slate-300 text-2xl mb-2 block"></i>
              لا يوجد مدراء فرعيون حالياً. يمكنك إضافة مدير جديد من النموذج أعلاه.
            </div>
          ) : (
            managers.map((m) => {
              const isSuspended = m.isActive === false;
              const isMonthly = m.subscriptionType === 'monthly';
              const expired = isMonthly && isSubscriptionExpired(m.subscriptionType, m.subscriptionExpiresAt);
              const daysRemaining = isMonthly ? getSubscriptionDaysRemaining(m.subscriptionExpiresAt) : null;
              const inProgress = actionInProgressId === m.id;
              const pwd =
                m.plainPassword ||
                localStorage.getItem(`user_pwd_${m.id}`) ||
                localStorage.getItem(`user_pwd_${m.username}`) ||
                '';
              const isEditingPwd = editingPasswordManagerId === m.id;
              const isRevealed = Boolean(revealedPasswords[m.id]);
              const isCopied = copiedManagerId === m.id;
              const isShared = shareSuccessManagerId === m.id;

              return (
                <div
                  key={m.id}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    isSuspended
                      ? 'bg-amber-50/40 border-amber-200'
                      : expired
                      ? 'bg-red-50/30 border-red-200'
                      : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
                  }`}
                >
                  {/* Top Details Row */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-slate-900">{m.branch}</span>
                        
                        {/* Account Status Badge */}
                        {isSuspended ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                            <i className="fa-solid fa-ban text-[9px] text-amber-700"></i>
                            <span>حساب موقوف</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100/80 text-emerald-800 border border-emerald-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                            <span>نشط</span>
                          </span>
                        )}

                        {/* Subscription Badge */}
                        {!isMonthly ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                            <i className="fa-solid fa-infinity text-[9px] text-blue-600"></i>
                            <span>اشتراك دائمي</span>
                          </span>
                        ) : expired ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-800 border border-red-200 animate-pulse">
                            <i className="fa-solid fa-triangle-exclamation text-[9px] text-red-600"></i>
                            <span>اشتراك شهري منتهي ({formatDateArabic(m.subscriptionExpiresAt)})</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
                            <i className="fa-solid fa-calendar-check text-[9px] text-purple-600"></i>
                            <span>
                              شهري: ينتهي {formatDateArabic(m.subscriptionExpiresAt)} (متبقي {daysRemaining} يوم)
                            </span>
                          </span>
                        )}
                      </div>

                      <div className="text-xs text-slate-500 font-mono flex items-center gap-2 flex-wrap">
                        <span className="bg-slate-100/90 px-2 py-0.5 rounded-lg border border-slate-200 text-[11px]">
                          اسم المستخدم: <span className="font-bold text-slate-800">{m.username}</span>
                        </span>
                        
                        {/* Password display / share box */}
                        {pwd ? (
                          <div className="flex items-center gap-1.5 bg-slate-100/90 px-2 py-0.5 rounded-lg border border-slate-200 flex-wrap">
                            <span className="text-[10px] text-slate-500 font-bold">الرمز:</span>
                            <span className="font-bold text-slate-900 font-mono tracking-wider text-[11px] bg-white px-1.5 py-0.5 rounded border border-slate-200">
                              {isRevealed ? pwd : '••••••'}
                            </span>
                            <button
                              type="button"
                              onClick={() => togglePasswordVisibility(m.id)}
                              className="w-5 h-5 rounded hover:bg-slate-200 text-slate-500 flex items-center justify-center text-[10px] cursor-pointer"
                              title={isRevealed ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور'}
                            >
                              <i className={`fa-solid ${isRevealed ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleCopyManagerPassword(m.id, pwd)}
                              className="w-5 h-5 rounded hover:bg-blue-100 hover:text-blue-700 text-slate-500 flex items-center justify-center text-[10px] cursor-pointer"
                              title="نسخ كلمة المرور"
                            >
                              <i className={`fa-solid ${isCopied ? 'fa-check text-emerald-600' : 'fa-copy'}`}></i>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleShareCredentials(m, pwd)}
                              className="px-2 py-0.5 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 flex items-center gap-1 text-[10px] font-bold cursor-pointer transition-colors"
                              title="إرسال بيانات الدخول للمدير عبر واتساب"
                            >
                              <i className="fa-brands fa-whatsapp text-emerald-600"></i>
                              <span>{isShared ? 'تم التجهيز!' : 'إرسال للمدير'}</span>
                            </button>
                            {onUpdateManagerPassword && (
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingPasswordManagerId(isEditingPwd ? null : m.id);
                                  setEditingPasswordInput(pwd);
                                }}
                                className="w-5 h-5 rounded hover:bg-amber-100 text-slate-500 hover:text-amber-700 flex items-center justify-center text-[10px] cursor-pointer"
                                title="تعديل الرمز السري لهذا المدير"
                              >
                                <i className="fa-solid fa-pen"></i>
                              </button>
                            )}
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200 text-[10px]">
                            <span className="text-amber-800">الرمز مشفر</span>
                            {onUpdateManagerPassword && (
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingPasswordManagerId(isEditingPwd ? null : m.id);
                                  setEditingPasswordInput('');
                                }}
                                className="px-1.5 py-0.5 bg-amber-600 hover:bg-amber-700 text-white rounded font-bold cursor-pointer"
                              >
                                تعيين رمز
                              </button>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Inline Password Edit Form */}
                      {isEditingPwd && (
                        <div className="mt-2 p-2 bg-slate-50 border border-blue-200 rounded-xl space-y-1.5 animate-in fade-in duration-150">
                          <div className="text-[11px] font-bold text-slate-800 flex items-center justify-between">
                            <span>تعيين رمز سري جديد لـ ({m.username}):</span>
                            <span className="text-[10px] text-slate-500 font-normal">يُحفظ في السحابة فوراً</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              value={editingPasswordInput}
                              onChange={(e) => setEditingPasswordInput(e.target.value)}
                              placeholder="أدخل الرمز السري الجديد"
                              className="flex-1 px-2.5 py-1 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold outline-none focus:border-blue-600"
                            />
                            <button
                              type="button"
                              onClick={() => handleSavePasswordByAdmin(m.id)}
                              disabled={isSavingPasswordId === m.id}
                              className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-all cursor-pointer disabled:opacity-50 flex items-center gap-1"
                            >
                              {isSavingPasswordId === m.id ? (
                                <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                              ) : (
                                <i className="fa-solid fa-check text-xs"></i>
                              )}
                              <span>حفظ</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingPasswordManagerId(null)}
                              className="px-2 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-bold transition-all cursor-pointer"
                            >
                              إلغاء
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Delete Button */}
                    <button
                      type="button"
                      onClick={() => onDeleteManager(m.id)}
                      disabled={inProgress}
                      className="w-8 h-8 rounded-xl hover:bg-red-50 text-red-400 hover:text-red-600 flex items-center justify-center text-xs transition-colors cursor-pointer shrink-0"
                      title="حذف هذا المدير الفرعي نهائياً"
                    >
                      <i className="fa-regular fa-trash-can"></i>
                    </button>
                  </div>

                  {/* Actions Row: Instant Toggle & Renew Subscription */}
                  <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2">
                      {/* Instant Suspend / Activate Toggle */}
                      {isSuspended ? (
                        <button
                          type="button"
                          onClick={() => handleToggle(m.id, false)}
                          disabled={inProgress}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                          title="إعادة تنشيط دخول المدير فوراً"
                        >
                          {inProgress ? (
                            <i className="fa-solid fa-spinner fa-spin text-[10px]"></i>
                          ) : (
                            <i className="fa-solid fa-play text-[10px]"></i>
                          )}
                          <span>تنشيط الحساب لحظياً</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleToggle(m.id, true)}
                          disabled={inProgress}
                          className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50 active:scale-98"
                          title="إيقاف دخول المدير فوراً"
                        >
                          {inProgress ? (
                            <i className="fa-solid fa-spinner fa-spin text-[10px]"></i>
                          ) : (
                            <i className="fa-solid fa-pause text-[10px] text-amber-600"></i>
                          )}
                          <span>إيقاف لحظي</span>
                        </button>
                      )}

                      {/* Renew Subscription Button (for monthly accounts) */}
                      {isMonthly && (
                        <button
                          type="button"
                          onClick={() => handleRenew(m.id, 1)}
                          disabled={inProgress}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50 active:scale-98 ${
                            expired
                              ? 'bg-purple-600 hover:bg-purple-700 text-white shadow-xs'
                              : 'bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200'
                          }`}
                          title="تجديد الاشتراك لمدة شهر إضافي وتأكيد اعتماده من الإدارة"
                        >
                          {inProgress ? (
                            <i className="fa-solid fa-spinner fa-spin text-[10px]"></i>
                          ) : (
                            <i className="fa-solid fa-arrows-rotate text-[10px]"></i>
                          )}
                          <span>{expired ? 'تجديد الاشتراك الآن (+شهر)' : 'تمديد شهر'}</span>
                        </button>
                      )}
                    </div>

                    {/* Expiry Warning Text if Expired */}
                    {expired && (
                      <span className="text-[11px] font-bold text-red-600 flex items-center gap-1">
                        <i className="fa-solid fa-lock text-[10px]"></i>
                        <span>ممنوع من الدخول حتى تجديد الاشتراك</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
