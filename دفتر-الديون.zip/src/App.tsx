import React, { useState, useEffect, useCallback } from 'react';
import bcrypt from 'bcryptjs';
import { AppSettings, Debtor, DebtorTransaction, DebtStats, FilterType, Manager, SubscriptionType, TabType, User, ViewMode } from './types';
import {
  DEFAULT_SETTINGS,
  broadcastManagerStatusChange,
  broadcastDebtorsChange,
  sessionBroadcastChannel,
  debtorsBroadcastChannel,
  getLocalDebtorDates,
  getLocalDebtors,
  getLocalDebtorHistory,
  getLocalManagers,
  getLocalSession,
  getLocalSettings,
  queryTurso,
  setLocalDebtorDates,
  setLocalDebtors,
  setLocalDebtorHistory,
  setLocalManagers,
  setLocalSession,
  setLocalSettings,
} from './services/turso';
import {
  getIdbDebtors,
  saveIdbDebtors,
  putIdbDebtor,
  deleteIdbDebtor,
  getIdbStats,
  saveIdbStats,
  getIdbSettings,
  saveIdbSettings,
  getIdbManagers,
  saveIdbManagers,
} from './services/idb';
import { calculateDaysElapsed } from './utils/formatters';
import { LoginOverlay } from './components/LoginOverlay';
import { HeaderCard } from './components/HeaderCard';
import { Controls } from './components/Controls';
import { DebtorListItem } from './components/DebtorListItem';
import { DebtorHistoryModal } from './components/DebtorHistoryModal';
import { DebtorShareModal } from './components/DebtorShareModal';
import { AddDebtorModal } from './components/AddDebtorModal';
import { EditDebtorNameModal } from './components/EditDebtorNameModal';
import { TransactionModal } from './components/TransactionModal';
import { ConfirmModal } from './components/ConfirmModal';
import { SettleCompleteModal } from './components/SettleCompleteModal';
import { ManagersTab } from './components/ManagersTab';
import { ReportsTab } from './components/ReportsTab';
import { OverdueTab } from './components/OverdueTab';
import { SettingsTab } from './components/SettingsTab';
import { BottomNav } from './components/BottomNav';
import { ToastContainer, ToastMessage } from './components/Toast';
import { TrialLimitModal } from './components/TrialLimitModal';
import { generate100DemoDebtors, isDemoDebtor } from './utils/mockDebtors';

const getLocalStats = (userId: number): DebtStats | null => {
  try {
    const raw = localStorage.getItem(`debts_stats_${userId}`);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};

const setLocalStats = (userId: number, stats: DebtStats) => {
  try {
    localStorage.setItem(`debts_stats_${userId}`, JSON.stringify(stats));
  } catch (e) {
    console.error(e);
  }
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(() => getLocalSession());
  const [loginErrorMessage, setLoginErrorMessage] = useState<string | null>(null);
  const [allDebtors, setAllDebtors] = useState<Debtor[]>([]);
  const [managers, setManagers] = useState<Manager[]>([]);
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');
  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    try {
      const saved = localStorage.getItem('aldion_debtors_view_mode');
      return saved === 'list' ? 'list' : 'cards';
    } catch {
      return 'cards';
    }
  });

  const handleViewModeChange = (mode: ViewMode) => {
    setViewMode(mode);
    try {
      localStorage.setItem('aldion_debtors_view_mode', mode);
    } catch (e) {
      console.error(e);
    }
  };
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isTrialLimitModalOpen, setIsTrialLimitModalOpen] = useState(false);
  const isTrialMode = Boolean(currentUser && (currentUser.subscriptionType === 'trial' || currentUser.role === 'trial' || currentUser.id === 999999));

  const handleOpenAddModal = () => {
    if (isTrialMode && allDebtors.length >= 2) {
      setIsTrialLimitModalOpen(true);
      return;
    }
    setIsAddModalOpen(true);
  };
  const [isSavingCloud, setIsSavingCloud] = useState(false);
  const [isManagersLoading, setIsManagersLoading] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [settings, setSettings] = useState<AppSettings>(() => {
    const session = getLocalSession();
    return session ? getLocalSettings(session.id) : DEFAULT_SETTINGS;
  });
  const [stats, setStats] = useState<DebtStats>(() => {
    const session = getLocalSession();
    if (session) {
      const cached = getLocalStats(session.id);
      if (cached && !(cached.totalAdded === 70000 && cached.totalPaid === 25000)) {
        return cached;
      }
    }
    return { totalAdded: 0, totalPaid: 0 };
  });

  // Transaction Modal State (for Pay and Add Debt)
  const [transactionState, setTransactionState] = useState<{
    isOpen: boolean;
    type: 'pay' | 'add';
    debtor: Debtor | null;
  }>({
    isOpen: false,
    type: 'pay',
    debtor: null,
  });

  // Confirm Modal State
  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  // Debtor History Modal State
  const [historyModalState, setHistoryModalState] = useState<{
    isOpen: boolean;
    debtor: Debtor | null;
  }>({
    isOpen: false,
    debtor: null,
  });

  // Debtor Share Modal State
  const [shareModalState, setShareModalState] = useState<{
    isOpen: boolean;
    debtor: Debtor | null;
  }>({
    isOpen: false,
    debtor: null,
  });

  // Settle Complete Modal State (when debtor balance reaches 0)
  const [settleCompleteState, setSettleCompleteState] = useState<{
    isOpen: boolean;
    debtor: Debtor | null;
  }>({
    isOpen: false,
    debtor: null,
  });

  // Edit Debtor Name Modal State
  const [editingNameDebtor, setEditingNameDebtor] = useState<Debtor | null>(null);
  const [isEditNameModalOpen, setIsEditNameModalOpen] = useState(false);

  const handleOpenEditNameModal = (debtor: Debtor) => {
    setEditingNameDebtor(debtor);
    setIsEditNameModalOpen(true);
  };

  const handleSaveDebtorName = async (debtorId: number, newName: string, newPhone?: string) => {
    if (!currentUser) return;
    const trimmed = newName.trim();
    if (!trimmed) {
      showToast("يرجى إدخال اسم صحيح للمدين", "error");
      return;
    }
    const cleanPhone = (newPhone !== undefined ? newPhone : '').trim();

    // 1. Optimistic local state update
    const updatedDebtors = allDebtors.map((d) =>
      d.id === debtorId ? { ...d, name: trimmed, phone: newPhone !== undefined ? cleanPhone : d.phone } : d
    );
    setAllDebtors(updatedDebtors);
    setLocalDebtors(currentUser.id, updatedDebtors);

    const targetDebtor = updatedDebtors.find((d) => d.id === debtorId);
    if (targetDebtor) {
      await putIdbDebtor(targetDebtor);
    }

    // Also update history/share modal if currently open for this debtor
    setHistoryModalState((prev) => {
      if (prev.isOpen && prev.debtor?.id === debtorId) {
        return { ...prev, debtor: { ...prev.debtor, name: trimmed, phone: newPhone !== undefined ? cleanPhone : prev.debtor.phone } };
      }
      return prev;
    });

    setShareModalState((prev) => {
      if (prev.isOpen && prev.debtor?.id === debtorId) {
        return { ...prev, debtor: { ...prev.debtor, name: trimmed, phone: newPhone !== undefined ? cleanPhone : prev.debtor.phone } };
      }
      return prev;
    });

    showToast(`تم تحديث بيانات المدين "${trimmed}" بنجاح`, "success");

    // 2. Cloud DB update (skip for demo debtors and trial accounts)
    if (debtorId > 0 && !isTrialMode) {
      try {
        setIsSavingCloud(true);
        if (newPhone !== undefined) {
          await queryTurso("UPDATE debtors SET name = ?, phone = ? WHERE id = ? AND user_id = ?;", [
            trimmed,
            cleanPhone,
            debtorId,
            currentUser.id,
          ]);
        } else {
          await queryTurso("UPDATE debtors SET name = ? WHERE id = ? AND user_id = ?;", [
            trimmed,
            debtorId,
            currentUser.id,
          ]);
        }
        broadcastDebtorsChange(currentUser.id, 'edit');
      } catch (err: any) {
        console.warn("تنبيه تحديث اسم المدين في السحابة:", err);
      } finally {
        setIsSavingCloud(false);
      }
    }
  };

  const handleKeepSettledDebtor = () => {
    setSettleCompleteState({ isOpen: false, debtor: null });
    showToast("تم الاحتفاظ بالمدين في سجلك (خالي من الدين)", "info");
  };

  const handleDeleteSettledDebtor = async () => {
    const target = settleCompleteState.debtor;
    setSettleCompleteState({ isOpen: false, debtor: null });
    if (target) {
      await handleDeleteDebtor(target);
    }
  };

  const handleOpenHistoryModal = (debtor: Debtor) => {
    if (currentUser) {
      const historyMap = getLocalDebtorHistory(currentUser.id);
      const debtorHistory = historyMap[debtor.id] || debtor.history;
      setHistoryModalState({
        isOpen: true,
        debtor: {
          ...debtor,
          history: debtorHistory,
        },
      });
    } else {
      setHistoryModalState({
        isOpen: true,
        debtor,
      });
    }
  };

  const handleOpenShareModal = (debtor: Debtor) => {
    if (currentUser) {
      const historyMap = getLocalDebtorHistory(currentUser.id);
      const debtorHistory = historyMap[debtor.id] || debtor.history;
      setShareModalState({
        isOpen: true,
        debtor: {
          ...debtor,
          history: debtorHistory,
        },
      });
    } else {
      setShareModalState({
        isOpen: true,
        debtor,
      });
    }
  };

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  }, []);

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Fetch Cloud Data for current user - with real-time sync across browsers & devices
  const fetchAndCacheCloudData = useCallback(async (userId: number, isSilent = false) => {
    try {
      setIsSavingCloud(true);
      const sql = "SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors WHERE user_id = ? ORDER BY id DESC;";
      const args = [userId];

      let res;
      try {
        res = await queryTurso(sql, args);
      } catch {
        await queryTurso("ALTER TABLE debtors ADD COLUMN created_at TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE debtors ADD COLUMN history TEXT;").catch(() => {});
        res = await queryTurso(sql, args);
      }

      let rows: any[] = [];
      if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
        rows = res.results[0].response.result.rows;
      }

      const datesMap = getLocalDebtorDates(userId);
      const historyMap = getLocalDebtorHistory(userId);
      let datesModified = false;
      let historyModified = false;

      const cloudDebtors: Debtor[] = rows.map((r) => {
        const id = parseInt(r[0]?.value);
        const name = r[1]?.value || '';
        const phone = r[2]?.value || '';
        const amount = parseFloat(r[3]?.value || 0);
        const status = r[4]?.value || 'دين مرتفع';
        const uId = parseInt(r[5]?.value);
        const cloudCreatedAt = r[6]?.value;
        const cloudHistoryRaw = r[7]?.value;

        let createdAt = cloudCreatedAt || datesMap[id];
        if (!createdAt) {
          createdAt = new Date().toISOString();
          datesModified = true;
        } else if (cloudCreatedAt && datesMap[id] !== cloudCreatedAt) {
          datesModified = true;
        }
        datesMap[id] = createdAt;

        let debtorHistory: DebtorTransaction[] | undefined = undefined;
        if (cloudHistoryRaw) {
          try {
            const parsed = JSON.parse(cloudHistoryRaw);
            if (Array.isArray(parsed) && parsed.length > 0) {
              debtorHistory = parsed;
              historyMap[id] = parsed;
              historyModified = true;
            }
          } catch {}
        }
        if (!debtorHistory && historyMap[id]) {
          debtorHistory = historyMap[id];
        }

        return {
          id,
          name,
          phone,
          amount,
          status,
          userId: uId,
          createdAt,
          lastDebtDate: createdAt,
          history: debtorHistory,
        };
      });

      if (datesModified) {
        setLocalDebtorDates(userId, datesMap);
      }
      if (historyModified) {
        setLocalDebtorHistory(userId, historyMap);
      }

      setAllDebtors((prev) => {
        const demoDebtors = prev.filter(isDemoDebtor);
        const cleanCloudDebtors = cloudDebtors.filter((d) => !isDemoDebtor(d));
        const combined = [...demoDebtors, ...cleanCloudDebtors];
        setLocalDebtors(userId, combined);
        // Save only clean real debtors to IndexedDB
        saveIdbDebtors(userId, cleanCloudDebtors).catch(() => {});
        return combined;
      });

      if (!isSilent) {
        showToast("تمت المزامنة اللحظية مع السحابة بنجاح", "success");
      }
    } catch (err: any) {
      console.warn("تنبيه جلب البيانات السحابية:", err?.message || err);
      if (!isSilent) {
        const cached = getLocalDebtors(userId);
        if (!cached || cached.length === 0) {
          showToast("تعذر الاتصال بالسحابة، يعمل التطبيق في الوضع المحلي", "info");
        }
      }
    } finally {
      setIsSavingCloud(false);
    }
  }, [showToast]);

  // Smart Zero-Waste Cloud Sync: Checks lightweight fingerprint (30 bytes) before downloading records
  const syncCloudDataIfChanged = useCallback(async (userId: number, force = false, isSilent = true) => {
    try {
      const cached = getLocalDebtors(userId) || [];
      const realLocal = cached.filter((d) => !isDemoDebtor(d));

      // If this browser has zero local records (fresh browser or first login) or forced: fetch full list
      if (realLocal.length === 0 || force) {
        await fetchAndCacheCloudData(userId, isSilent);
        return;
      }

      // Ultra-lightweight fingerprint check (returns only 3 numbers, ~30 bytes data transfer)
      let fpRes;
      try {
        fpRes = await queryTurso(
          "SELECT COUNT(*), COALESCE(MAX(id), 0), COALESCE(SUM(amount), 0) FROM debtors WHERE user_id = ?;",
          [userId]
        );
      } catch {
        // If table doesn't exist or error, fallback to normal fetch
        await fetchAndCacheCloudData(userId, isSilent);
        return;
      }

      if (fpRes.results && fpRes.results[0] && fpRes.results[0].response?.result?.rows) {
        const row = fpRes.results[0].response.result.rows[0];
        const cloudCount = parseInt(row[0]?.value || 0);
        const cloudMaxId = parseInt(row[1]?.value || 0);
        const cloudSum = parseFloat(row[2]?.value || 0);

        const localCount = realLocal.length;
        const localMaxId = realLocal.reduce((max, d) => (d.id > max ? d.id : max), 0);
        const localSum = realLocal.reduce((sum, d) => sum + (d.amount || 0), 0);

        // If local matches cloud exactly: 0 records downloaded! 0 data consumed!
        if (cloudCount === localCount && cloudMaxId === localMaxId && Math.abs(cloudSum - localSum) < 0.01) {
          if (!isSilent) {
            showToast("البيانات متطابقة ومحدثة مع السحابة بدون استهلاك بيانات", "success");
          }
          return;
        }
      }

      // If difference detected (changes made on another browser/device): fetch fresh records
      await fetchAndCacheCloudData(userId, isSilent);
    } catch (err: any) {
      console.warn("فحص البصمة السحابية:", err?.message || err);
    }
  }, [fetchAndCacheCloudData, showToast]);

  // Load managers from cloud (for admin)
  const loadManagersFromCloud = useCallback(async (isSilent = true) => {
    try {
      setIsManagersLoading(true);
      let res;
      try {
        res = await queryTurso(
          "SELECT id, username, branch_name, is_active, subscription_type, subscription_expires_at, plain_password FROM users WHERE role = 'manager';"
        );
      } catch {
        // In case the column plain_password is not created yet
        await queryTurso("ALTER TABLE users ADD COLUMN plain_password TEXT;").catch(() => {});
        res = await queryTurso(
          "SELECT id, username, branch_name, is_active, subscription_type, subscription_expires_at, plain_password FROM users WHERE role = 'manager';"
        );
      }

      let rows: any[] = [];
      if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
        rows = res.results[0].response.result.rows;
      }

      const cloudManagers: Manager[] = rows.map((r) => {
        const id = parseInt(r[0].value);
        const username = r[1].value;
        const isActiveVal = r[3]?.value;
        const isActive = isActiveVal === 0 || isActiveVal === '0' ? false : true;
        const subscriptionType = (r[4]?.value as SubscriptionType) || 'permanent';
        const subscriptionExpiresAt = r[5]?.value || null;
        const plainPassword = r[6]?.value || '';

        if (plainPassword) {
          localStorage.setItem(`user_pwd_${id}`, plainPassword);
          localStorage.setItem(`user_pwd_${username}`, plainPassword);
        }

        const effectivePassword =
          plainPassword ||
          localStorage.getItem(`user_pwd_${id}`) ||
          localStorage.getItem(`user_pwd_${username}`) ||
          undefined;

        return {
          id,
          username,
          branch: r[2]?.value || 'فرع بدون اسم',
          isActive,
          subscriptionType,
          subscriptionExpiresAt,
          plainPassword: effectivePassword,
        };
      });

      setLocalManagers(cloudManagers);
      setManagers(cloudManagers);
      await saveIdbManagers(cloudManagers);
    } catch (err: any) {
      if (!isSilent) {
        console.warn("تنبيه جلب قائمة المدراء:", err?.message || err);
      }
    } finally {
      setIsManagersLoading(false);
    }
  }, []);

  // Initialize session data from IndexedDB & LocalStorage (Zero delay), then verify fingerprint
  useEffect(() => {
    if (!currentUser) {
      setStats({ totalAdded: 0, totalPaid: 0 });
      return;
    }

    let isMounted = true;

    async function loadData() {
      if (!currentUser) return;

      // 1. Settings (IDB first)
      const idbSettings = await getIdbSettings(currentUser.id);
      if (idbSettings && isMounted) {
        setSettings(idbSettings);
      } else {
        const localSettings = getLocalSettings(currentUser.id);
        if (isMounted) setSettings(localSettings);
        saveIdbSettings(currentUser.id, localSettings);
      }

      // 2. Stats (IDB first, isolated per branch manager)
      const idbStats = await getIdbStats(currentUser.id);
      if (idbStats && !(idbStats.totalAdded === 70000 && idbStats.totalPaid === 25000) && isMounted) {
        setStats(idbStats);
      } else {
        const cachedStats = getLocalStats(currentUser.id);
        if (cachedStats && !(cachedStats.totalAdded === 70000 && cachedStats.totalPaid === 25000)) {
          if (isMounted) setStats(cachedStats);
          saveIdbStats(currentUser.id, cachedStats);
        } else {
          const initialStats = { totalAdded: 0, totalPaid: 0 };
          if (isMounted) setStats(initialStats);
          setLocalStats(currentUser.id, initialStats);
          saveIdbStats(currentUser.id, initialStats);
        }
      }

      // 3. Debtors: Render local data first (Instant 0ms display with 0 bytes data usage)
      const idbDebtors = await getIdbDebtors(currentUser.id);
      if (idbDebtors && idbDebtors.length > 0) {
        const hasDemo = idbDebtors.some(isDemoDebtor);
        let enriched = idbDebtors.map((d) => (isDemoDebtor(d) ? { ...d, isDemo: true } : d));
        if (hasDemo && currentUser.role === 'admin') {
          const realOnly = enriched.filter((d) => !isDemoDebtor(d));
          const newDemo = generate100DemoDebtors(currentUser.id, idbSettings?.highDebtThreshold || 25000);
          enriched = [...newDemo, ...realOnly];
        }
        if (isMounted) setAllDebtors(enriched);
      } else {
        const cachedDebtors = getLocalDebtors(currentUser.id);
        if (cachedDebtors !== null && cachedDebtors.length > 0) {
          const datesMap = getLocalDebtorDates(currentUser.id);
          let datesModified = false;
          let debtorsWithDates = cachedDebtors.map((d, idx) => {
            const isDemo = isDemoDebtor(d);
            if (!d.createdAt) {
              if (datesMap[d.id]) {
                d.createdAt = datesMap[d.id];
              } else {
                const pastDays = (idx % 3) + 1;
                d.createdAt = new Date(Date.now() - pastDays * 24 * 60 * 60 * 1000).toISOString();
                datesMap[d.id] = d.createdAt;
                datesModified = true;
              }
            }
            return isDemo ? { ...d, isDemo: true } : d;
          });

          if (debtorsWithDates.some(isDemoDebtor) && currentUser.role === 'admin') {
            const realOnly = debtorsWithDates.filter((d) => !isDemoDebtor(d));
            const newDemo = generate100DemoDebtors(currentUser.id, idbSettings?.highDebtThreshold || 25000);
            debtorsWithDates = [...newDemo, ...realOnly];
          }

          if (datesModified) {
            setLocalDebtorDates(currentUser.id, datesMap);
          }

          if (isMounted) setAllDebtors(debtorsWithDates);
        }
      }

      // 4. Managers if admin
      if (currentUser.role === 'admin') {
        const idbManagers = await getIdbManagers();
        if (idbManagers && idbManagers.length > 0) {
          if (isMounted) setManagers(idbManagers);
        } else {
          const cachedManagers = getLocalManagers();
          if (cachedManagers !== null && isMounted) {
            setManagers(cachedManagers);
            saveIdbManagers(cachedManagers);
          }
        }
      }

      // 5. Smart Fingerprint Check: Only downloads records if changed on another device!
      if (isMounted && !isTrialMode) {
        await syncCloudDataIfChanged(currentUser.id, false, true);
        if (currentUser.role === 'admin') {
          await loadManagersFromCloud(true);
        }
      }
    }

    loadData();

    return () => {
      isMounted = false;
    };
  }, [currentUser, syncCloudDataIfChanged, loadManagersFromCloud]);

  // Event-Driven Sync (No continuous background polling to save 100% of data traffic)
  useEffect(() => {
    if (!currentUser || isTrialMode) return;

    // A. Multi-tab local sync via BroadcastChannel (0 internet data usage)
    const handleBroadcastDebtors = (event: MessageEvent) => {
      if (event.data?.type === 'DEBTORS_UPDATED' && event.data?.userId === currentUser.id) {
        fetchAndCacheCloudData(currentUser.id, true);
      }
    };

    // B. Reconnection sync when device comes back online
    const handleOnline = () => {
      syncCloudDataIfChanged(currentUser.id, false, false);
      if (currentUser.role === 'admin') {
        loadManagersFromCloud(false);
      }
    };

    window.addEventListener('online', handleOnline);

    if (debtorsBroadcastChannel) {
      debtorsBroadcastChannel.addEventListener('message', handleBroadcastDebtors);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      if (debtorsBroadcastChannel) {
        debtorsBroadcastChannel.removeEventListener('message', handleBroadcastDebtors);
      }
    };
  }, [currentUser, fetchAndCacheCloudData, syncCloudDataIfChanged, loadManagersFromCloud]);

  const handleForceLogout = useCallback((reason: string) => {
    setCurrentUser(null);
    setLocalSession(null);
    setActiveTab('home');
    setAllDebtors([]);
    setStats({ totalAdded: 0, totalPaid: 0 });
    setLoginErrorMessage(reason);
    showToast(reason, "error");
  }, [showToast]);

  const handleLoginSuccess = async (user: User) => {
    setLoginErrorMessage(null);
    setCurrentUser(user);
    setSettings(getLocalSettings(user.id));
    const cachedStats = getLocalStats(user.id);
    if (cachedStats && !(cachedStats.totalAdded === 70000 && cachedStats.totalPaid === 25000)) {
      setStats(cachedStats);
    } else {
      const freshStats = { totalAdded: 0, totalPaid: 0 };
      setStats(freshStats);
      setLocalStats(user.id, freshStats);
      saveIdbStats(user.id, freshStats);
    }
    setActiveTab('home');
    showToast(`مرحباً بك! فرع: ${user.branch_name}`, "success");
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setLocalSession(null);
    setActiveTab('home');
    setAllDebtors([]);
    setStats({ totalAdded: 0, totalPaid: 0 });
    setLoginErrorMessage(null);
    showToast("تم تسجيل الخروج بنجاح", "info");
  };

  // Real-time verification of sub-manager active status
  const checkManagerActiveStatus = useCallback(async (user: User): Promise<boolean> => {
    if (!user || user.role === 'admin' || user.role === 'trial' || user.subscriptionType === 'trial' || user.id === 999999) return true;

    // 1. Immediate local flag check (Fastest response across same browser)
    const localFlag = localStorage.getItem(`force_logout_user_${user.id}`);
    if (localFlag) {
      let reason = 'تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.';
      try {
        const parsed = JSON.parse(localFlag);
        if (parsed.reason) reason = parsed.reason;
      } catch {}
      handleForceLogout(reason);
      return false;
    }

    // 2. Check local managers cache
    const cachedManagers = getLocalManagers();
    if (cachedManagers) {
      const found = cachedManagers.find((m) => m.id === user.id);
      if (found && found.isActive === false) {
        handleForceLogout('تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.');
        return false;
      }
    }

    // 3. Query Turso database in real-time (Ensures instant logout across all devices & tabs)
    try {
      const res = await queryTurso(
        "SELECT is_active, subscription_type, subscription_expires_at FROM users WHERE id = ?;",
        [user.id]
      );
      let rows: any[] = [];
      if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
        rows = res.results[0].response.result.rows;
      }

      if (rows.length === 0) {
        handleForceLogout('تم حذف هذا الحساب من قبل الإدارة العامة، وتم إنهاء الجلسة.');
        return false;
      }

      const row = rows[0];
      const isActiveVal = row[0]?.value;
      const isActive = isActiveVal === 0 || isActiveVal === '0' || isActiveVal === false ? false : true;
      const subscriptionType = row[1]?.value || 'permanent';
      const subscriptionExpiresAt = row[2]?.value || null;

      if (!isActive) {
        handleForceLogout('تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.');
        return false;
      }

      if (subscriptionType === 'monthly') {
        if (!subscriptionExpiresAt || new Date(subscriptionExpiresAt).getTime() <= Date.now()) {
          handleForceLogout('انتهت فترة الاشتراك الشهري لهذا الحساب. يرجى مراجعة الإدارة لتجديده.');
          return false;
        }
      }

      // Sync updated subscription information to current user state & storage
      setCurrentUser((prev) => {
        if (!prev) return null;
        if (prev.subscriptionType !== subscriptionType || prev.subscriptionExpiresAt !== subscriptionExpiresAt) {
          const updated: User = {
            ...prev,
            subscriptionType: subscriptionType as SubscriptionType,
            subscriptionExpiresAt,
            isActive,
          };
          setLocalSession(updated);
          return updated;
        }
        return prev;
      });

      return true;
    } catch {
      // In case of transient offline, allow continuing until next check
      return true;
    }
  }, [handleForceLogout]);

  // Real-time synchronization for sub-managers: BroadcastChannel + Storage Event + Heartbeat
  useEffect(() => {
    if (!currentUser || currentUser.role === 'admin') return;

    let isCancelled = false;

    // A. Initial check on mount
    checkManagerActiveStatus(currentUser);

    // B. BroadcastChannel listener (Instant zero-delay notification across tabs)
    const handleBroadcastMessage = (event: MessageEvent) => {
      if (isCancelled) return;
      const data = event.data;
      if (data && data.type === 'FORCE_LOGOUT' && data.targetUserId === currentUser.id) {
        handleForceLogout(data.reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.');
      }
    };

    if (sessionBroadcastChannel) {
      sessionBroadcastChannel.addEventListener('message', handleBroadcastMessage);
    }

    // C. Cross-tab storage change listener
    const handleStorageEvent = (e: StorageEvent) => {
      if (isCancelled) return;
      if (e.key === `force_logout_user_${currentUser.id}` && e.newValue) {
        let reason = 'تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.';
        try {
          const parsed = JSON.parse(e.newValue);
          if (parsed.reason) reason = parsed.reason;
        } catch {}
        handleForceLogout(reason);
      } else if (e.key === 'local_managers_list' && e.newValue) {
        try {
          const list: Manager[] = JSON.parse(e.newValue);
          const found = list.find((m) => m.id === currentUser.id);
          if (found && found.isActive === false) {
            handleForceLogout('تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.');
          }
        } catch {}
      } else if (e.key === 'session_user' && !e.newValue) {
        handleForceLogout('تم تسجيل الخروج من هذا الحساب.');
      }
    };
    window.addEventListener('storage', handleStorageEvent);

    // D. Periodic heartbeat polling against Turso cloud database (Every 3.5 seconds)
    const intervalId = setInterval(() => {
      if (!isCancelled && document.visibilityState === 'visible') {
        checkManagerActiveStatus(currentUser);
      }
    }, 3500);

    // E. Tab focus / visibility change handler
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && !isCancelled) {
        checkManagerActiveStatus(currentUser);
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleVisibilityChange);

    return () => {
      isCancelled = true;
      if (sessionBroadcastChannel) {
        sessionBroadcastChannel.removeEventListener('message', handleBroadcastMessage);
      }
      window.removeEventListener('storage', handleStorageEvent);
      clearInterval(intervalId);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleVisibilityChange);
    };
  }, [currentUser, checkManagerActiveStatus, handleForceLogout]);

  // Real-time synchronization for Admin: listen to manager password changes & list updates
  useEffect(() => {
    if (!currentUser || currentUser.role !== 'admin') return;

    const handleAdminBroadcastMessage = (event: MessageEvent) => {
      const data = event.data;
      if (data && data.type === 'MANAGER_PASSWORD_CHANGED') {
        setManagers((prev) =>
          prev.map((m) =>
            m.id === data.managerId ? { ...m, plainPassword: data.newPassword } : m
          )
        );
        localStorage.setItem(`user_pwd_${data.managerId}`, data.newPassword);
        localStorage.setItem(`user_pwd_${data.username}`, data.newPassword);
      }
    };

    if (sessionBroadcastChannel) {
      sessionBroadcastChannel.addEventListener('message', handleAdminBroadcastMessage);
    }

    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'local_managers_list' && e.newValue) {
        try {
          const list: Manager[] = JSON.parse(e.newValue);
          setManagers(list);
        } catch {}
      }
    };
    window.addEventListener('storage', handleStorage);

    return () => {
      if (sessionBroadcastChannel) {
        sessionBroadcastChannel.removeEventListener('message', handleAdminBroadcastMessage);
      }
      window.removeEventListener('storage', handleStorage);
    };
  }, [currentUser]);

  const handleUpdateSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    if (currentUser) {
      setLocalSettings(currentUser.id, newSettings);
      saveIdbSettings(currentUser.id, newSettings);
    }
    showToast("تم حفظ وتطبيق إعدادات التنبيهات وسقف الدين بنجاح", "success");
  };

  const handleUpdateStats = (newStats: DebtStats) => {
    if (!currentUser) return;
    setStats(newStats);
    setLocalStats(currentUser.id, newStats);
    saveIdbStats(currentUser.id, newStats);
    showToast("تم تحديث أرقام التقارير بنجاح", "success");
  };

  const handleResetStats = () => {
    if (!currentUser) return;
    setConfirmState({
      isOpen: true,
      title: "تصفير سجل التقارير",
      message: "هل أنت متأكد من تصفير إحصائيات الديون التراكمية في صفحة التقارير لبدء دورة محاسبية جديدة؟",
      onConfirm: async () => {
        const zeroStats = { totalAdded: 0, totalPaid: 0 };
        setStats(zeroStats);
        setLocalStats(currentUser.id, zeroStats);
        await saveIdbStats(currentUser.id, zeroStats);
        setConfirmState((prev) => ({ ...prev, isOpen: false }));
        showToast("تم تصفير سجل التقارير والإحصائيات بنجاح", "info");
      },
    });
  };

  // Backup & Restore Import Handler for Debtors
  const handleImportDebtors = async (importedDebtors: Debtor[], mode: 'merge' | 'replace') => {
    if (!currentUser) return;
    setIsSavingCloud(true);
    try {
      let finalDebtors: Debtor[] = [];
      const currentHistoryMap = getLocalDebtorHistory(currentUser.id);
      const updatedHistoryMap = { ...currentHistoryMap };
      const currentDatesMap = getLocalDebtorDates(currentUser.id);
      const updatedDatesMap = { ...currentDatesMap };

      if (mode === 'replace') {
        // Replace entire list with imported debtors
        finalDebtors = importedDebtors.map((d, index) => {
          const debtorId = d.id || Date.now() + index;
          if (d.history && d.history.length > 0) {
            updatedHistoryMap[debtorId] = d.history;
          }
          if (d.createdAt || d.lastDebtDate) {
            updatedDatesMap[debtorId] = d.lastDebtDate || d.createdAt || new Date().toISOString();
          }
          return {
            ...d,
            id: debtorId,
            userId: currentUser.id,
          };
        });
      } else {
        // Merge mode: match existing debtor by name
        const existingMap = new Map<string, Debtor>();
        allDebtors.forEach((d) => {
          existingMap.set(d.name.trim().toLowerCase(), d);
        });

        const mergedList = [...allDebtors];
        importedDebtors.forEach((imp, index) => {
          const key = imp.name.trim().toLowerCase();
          const existing = existingMap.get(key);

          if (existing) {
            const debtorId = existing.id;
            const updated: Debtor = {
              ...existing,
              phone: imp.phone || existing.phone,
              amount: imp.amount,
              status: imp.status || (imp.amount <= 0 ? 'خالي من الدين' : 'مستمر'),
              createdAt: existing.createdAt || imp.createdAt,
              lastDebtDate: imp.lastDebtDate || existing.lastDebtDate,
              history: imp.history && imp.history.length > 0 ? imp.history : existing.history,
            };
            const idx = mergedList.findIndex((d) => d.id === existing.id);
            if (idx !== -1) mergedList[idx] = updated;

            if (imp.history && imp.history.length > 0) {
              updatedHistoryMap[debtorId] = imp.history;
            }
            if (imp.lastDebtDate || imp.createdAt) {
              updatedDatesMap[debtorId] = imp.lastDebtDate || imp.createdAt || new Date().toISOString();
            }
          } else {
            const debtorId = imp.id || Date.now() + index;
            const newDebtor: Debtor = {
              ...imp,
              id: debtorId,
              userId: currentUser.id,
            };
            mergedList.push(newDebtor);
            if (imp.history && imp.history.length > 0) {
              updatedHistoryMap[debtorId] = imp.history;
            }
            if (imp.lastDebtDate || imp.createdAt) {
              updatedDatesMap[debtorId] = imp.lastDebtDate || imp.createdAt || new Date().toISOString();
            }
          }
        });
        finalDebtors = mergedList;
      }

      // 1. Update State
      setAllDebtors(finalDebtors);

      // 2. Update LocalStorage
      setLocalDebtors(currentUser.id, finalDebtors);
      setLocalDebtorHistory(currentUser.id, updatedHistoryMap);
      setLocalDebtorDates(currentUser.id, updatedDatesMap);

      // 3. Update IndexedDB
      await saveIdbDebtors(currentUser.id, finalDebtors);

      // 4. Update Cloud DB (Turso)
      try {
        if (mode === 'replace') {
          await queryTurso("DELETE FROM debtors WHERE user_id = ?;", [currentUser.id]);
        }
        for (const d of finalDebtors) {
          const dCreatedAt = d.createdAt || d.lastDebtDate || new Date().toISOString();
          await queryTurso(
            "INSERT OR REPLACE INTO debtors (id, name, phone, amount, status, user_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?);",
            [d.id, d.name, d.phone || '', d.amount || 0, d.status || 'مستمر', currentUser.id, dCreatedAt]
          );
        }
      } catch (cloudErr) {
        console.warn("Notice: Cloud backup sync warning:", cloudErr);
      }

      showToast(
        `تم بنجاح ${mode === 'replace' ? 'استبدال واسترجاع' : 'دمج واسترجاع'} بيانات (${importedDebtors.length}) مدين`,
        "success"
      );
    } catch (err: any) {
      console.error("Import error:", err);
      showToast(`فشل استيراد النسخة الاحتياطية: ${err?.message || 'خطأ غير معروف'}`, "error");
      throw err;
    } finally {
      setIsSavingCloud(false);
    }
  };

  // Add Debtor Handler
  const handleSaveDebtor = async (
    name: string,
    phone: string,
    amount: number,
    debtDate?: string,
    notes?: string
  ) => {
    if (!currentUser) return;
    if (isTrialMode) {
      if (allDebtors.length >= 2) {
        setIsTrialLimitModalOpen(true);
        return;
      }
    } else if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    const tempId = Date.now();
    const createdAt = debtDate || new Date().toISOString();
    const isHigh = amount >= settings.highDebtThreshold;
    const initialStatus = amount <= 0 ? 'خالي من الدين' : (isHigh ? 'دين مرتفع' : 'دين عادي');

    const cleanNotes = notes?.trim() || '';
    const initialDescription = cleanNotes
      ? `فتح حساب: ${cleanNotes}`
      : 'فتح حساب وتسجيل دين أولي';

    const initialTx: DebtorTransaction = {
      id: `tx-init-${tempId}-${Date.now()}`,
      debtorId: tempId,
      type: 'initial',
      amount,
      balanceAfter: amount,
      date: createdAt,
      description: initialDescription,
    };

    const newDebtor: Debtor = {
      id: tempId,
      name,
      phone,
      amount,
      status: initialStatus,
      userId: currentUser.id,
      createdAt,
      lastDebtDate: createdAt,
      notes: cleanNotes || undefined,
      history: [initialTx],
    };

    // Store date & history
    const datesMap = getLocalDebtorDates(currentUser.id);
    datesMap[tempId] = createdAt;
    setLocalDebtorDates(currentUser.id, datesMap);

    const historyMap = getLocalDebtorHistory(currentUser.id);
    historyMap[tempId] = [initialTx];
    setLocalDebtorHistory(currentUser.id, historyMap);

    // 1. Immediate local update (State + LocalStorage + IndexedDB)
    const updated = [newDebtor, ...allDebtors];
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);
    await putIdbDebtor(newDebtor);

    setStats((prev) => {
      const next = { ...prev, totalAdded: prev.totalAdded + amount };
      setLocalStats(currentUser.id, next);
      saveIdbStats(currentUser.id, next);
      return next;
    });
    showToast(`تمت إضافة المدين "${name}" بنجاح`, "success");

    // 2. Background sync to Turso (skip for trial accounts)
    if (isTrialMode) {
      return;
    }
    try {
      setIsSavingCloud(true);
      let res;
      try {
        res = await queryTurso(
          "INSERT INTO debtors (name, phone, amount, status, user_id, created_at, history) VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id;",
          [name, phone, amount, newDebtor.status, currentUser.id, createdAt, JSON.stringify([initialTx])]
        );
      } catch {
        await queryTurso("ALTER TABLE debtors ADD COLUMN created_at TEXT;").catch(() => {});
        await queryTurso("ALTER TABLE debtors ADD COLUMN history TEXT;").catch(() => {});
        res = await queryTurso(
          "INSERT INTO debtors (name, phone, amount, status, user_id, created_at, history) VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id;",
          [name, phone, amount, newDebtor.status, currentUser.id, createdAt, JSON.stringify([initialTx])]
        );
      }
      if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
        const realId = parseInt(res.results[0].response.result.rows[0][0].value);
        if (!isNaN(realId)) {
          await deleteIdbDebtor(tempId);
          newDebtor.id = realId;
          await putIdbDebtor(newDebtor);
          datesMap[realId] = createdAt;
          delete datesMap[tempId];
          setLocalDebtorDates(currentUser.id, datesMap);

          const updatedTxList = (historyMap[tempId] || [initialTx]).map((tx) => ({
            ...tx,
            debtorId: realId,
          }));
          historyMap[realId] = updatedTxList;
          delete historyMap[tempId];
          setLocalDebtorHistory(currentUser.id, historyMap);

          newDebtor.history = updatedTxList;

          const finalUpdated = updated.map((d) => (d.id === tempId ? { ...d, id: realId, history: updatedTxList } : d));
          setAllDebtors(finalUpdated);
          setLocalDebtors(currentUser.id, finalUpdated);
        }
      }
      broadcastDebtorsChange(currentUser.id, 'add');
    } catch (err: any) {
      console.warn("تنبيه المزامنة السحابية أثناء الإضافة (محفوظ في IndexedDB):", err?.message || err);
    } finally {
      setIsSavingCloud(false);
    }
  };

  // Pay Debt Handler
  const handleOpenPayModal = (debtor: Debtor) => {
    setTransactionState({
      isOpen: true,
      type: 'pay',
      debtor,
    });
  };

  const handleConfirmPay = async (debtorId: number, payVal: number, customDate?: string, notes?: string) => {
    if (!currentUser) return;
    if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    const target = allDebtors.find((d) => d.id === debtorId);
    if (!target) return;

    const newAmount = Math.max(0, target.amount - payVal);
    const newStatus = newAmount <= 0 ? 'خالي من الدين' : (newAmount >= settings.highDebtThreshold ? 'دين مرتفع' : target.status);
    const txDate = customDate || new Date().toISOString();

    // Record history transaction
    const payTx: DebtorTransaction = {
      id: `tx-pay-${debtorId}-${Date.now()}`,
      debtorId,
      type: 'pay',
      amount: payVal,
      balanceAfter: newAmount,
      date: txDate,
      description: notes ? notes : 'تسديد دفعة نقدية',
      notes: notes || undefined,
    };

    const historyMap = getLocalDebtorHistory(currentUser.id);
    const existingHistory = historyMap[debtorId] || target.history || (target.createdAt ? [{
      id: `tx-init-${target.id}`,
      debtorId: target.id,
      type: 'initial' as const,
      amount: target.amount,
      balanceAfter: target.amount,
      date: target.createdAt,
      description: 'فتح حساب وتسجيل الرصيد الأولي',
    }] : []);
    const updatedHistory = [payTx, ...existingHistory];
    historyMap[debtorId] = updatedHistory;
    setLocalDebtorHistory(currentUser.id, historyMap);

    // 1. Immediate local update
    const updatedDebtor = { ...target, amount: newAmount, status: newStatus, history: updatedHistory };
    const updated = allDebtors.map((d) => (d.id === debtorId ? updatedDebtor : d));
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);
    await putIdbDebtor(updatedDebtor);

    // Also update history modal debtor if currently open for this debtor
    setHistoryModalState((prev) => {
      if (prev.isOpen && prev.debtor?.id === debtorId) {
        return { ...prev, debtor: updatedDebtor };
      }
      return prev;
    });

    setStats((prev) => {
      const next = { ...prev, totalPaid: prev.totalPaid + payVal };
      setLocalStats(currentUser.id, next);
      saveIdbStats(currentUser.id, next);
      return next;
    });
    showToast(`تم تسديد ${payVal.toLocaleString('en-US')} د.ع من حساب ${target.name}`, "success");

    // Prompt user whether to keep or delete debtor upon settling all debt
    if (newAmount <= 0) {
      setSettleCompleteState({
        isOpen: true,
        debtor: updatedDebtor,
      });
    }

    // 2. Background sync to Turso (only this single record, skip for demo records and trial)
    if (debtorId > 0 && !updatedDebtor.isDemo && !isTrialMode) {
      try {
        setIsSavingCloud(true);
        await queryTurso(
          "UPDATE debtors SET amount = ?, status = ?, history = ? WHERE id = ? AND user_id = ?;",
          [newAmount, newStatus, JSON.stringify(updatedHistory), debtorId, currentUser.id]
        );
        broadcastDebtorsChange(currentUser.id, 'pay');
      } catch (err: any) {
        console.warn("تنبيه المزامنة السحابية أثناء التسديد:", err?.message || err);
      } finally {
        setIsSavingCloud(false);
      }
    }
  };

  // Add Debt Handler
  const handleOpenAddDebtModal = (debtor: Debtor) => {
    setTransactionState({
      isOpen: true,
      type: 'add',
      debtor,
    });
  };

  const handleConfirmAddDebt = async (debtorId: number, addVal: number, customDate?: string, notes?: string) => {
    if (!currentUser) return;
    if (currentUser.role !== 'admin') {
      const active = await checkManagerActiveStatus(currentUser);
      if (!active) return;
    }

    const target = allDebtors.find((d) => d.id === debtorId);
    if (!target) return;

    const newAmount = target.amount + addVal;
    const newStatus = newAmount >= settings.highDebtThreshold ? 'دين مرتفع' : target.status;
    const txDate = customDate || new Date().toISOString();

    // Record history transaction
    const addTx: DebtorTransaction = {
      id: `tx-add-${debtorId}-${Date.now()}`,
      debtorId,
      type: 'add',
      amount: addVal,
      balanceAfter: newAmount,
      date: txDate,
      description: notes ? notes : 'إضافة دين جديد',
      notes: notes || undefined,
    };

    const historyMap = getLocalDebtorHistory(currentUser.id);
    const existingHistory = historyMap[debtorId] || target.history || (target.createdAt ? [{
      id: `tx-init-${target.id}`,
      debtorId: target.id,
      type: 'initial' as const,
      amount: target.amount,
      balanceAfter: target.amount,
      date: target.createdAt,
      description: 'فتح حساب وتسجيل الرصيد الأولي',
    }] : []);
    const updatedHistory = [addTx, ...existingHistory];
    historyMap[debtorId] = updatedHistory;
    setLocalDebtorHistory(currentUser.id, historyMap);

    // 1. Immediate local update
    const updatedDebtor = {
      ...target,
      amount: newAmount,
      status: newStatus,
      lastDebtDate: txDate,
      history: updatedHistory,
    };
    const updated = allDebtors.map((d) => (d.id === debtorId ? updatedDebtor : d));
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);
    await putIdbDebtor(updatedDebtor);

    // Also update history modal debtor if currently open for this debtor
    setHistoryModalState((prev) => {
      if (prev.isOpen && prev.debtor?.id === debtorId) {
        return { ...prev, debtor: updatedDebtor };
      }
      return prev;
    });

    setStats((prev) => {
      const next = { ...prev, totalAdded: prev.totalAdded + addVal };
      setLocalStats(currentUser.id, next);
      saveIdbStats(currentUser.id, next);
      return next;
    });
    showToast(`تمت إضافة ${addVal.toLocaleString('en-US')} د.ع إلى دين ${target.name}`, "success");

    // 2. Background sync to Turso (only this single record, skip for demo records and trial)
    if (debtorId > 0 && !target.isDemo && !isTrialMode) {
      try {
        setIsSavingCloud(true);
        await queryTurso(
          "UPDATE debtors SET amount = amount + ?, status = ?, history = ? WHERE id = ? AND user_id = ?;",
          [addVal, newStatus, JSON.stringify(updatedHistory), debtorId, currentUser.id]
        );
        broadcastDebtorsChange(currentUser.id, 'add_debt');
      } catch (err: any) {
        console.warn("تنبيه المزامنة السحابية أثناء إضافة الدين:", err?.message || err);
      } finally {
        setIsSavingCloud(false);
      }
    }
  };

  // Toggle Overdue Status
  const handleToggleOverdueStatus = async (debtor: Debtor) => {
    if (!currentUser) return;
    const newStatus = debtor.status === 'متأخر' ? (debtor.amount <= 0 ? 'خالي من الدين' : 'دين مرتفع') : 'متأخر';
    const updatedDebtor = { ...debtor, status: newStatus };
    const updated = allDebtors.map((d) => (d.id === debtor.id ? updatedDebtor : d));
    setAllDebtors(updated);
    setLocalDebtors(currentUser.id, updated);
    await putIdbDebtor(updatedDebtor);

    showToast(
      newStatus === 'متأخر'
        ? `تم تحديد "${debtor.name}" كمتأخر عن السداد`
        : `تم إلغاء وسم التأخير عن "${debtor.name}"`,
      'info'
    );

    // Cloud update (skip for demo debtors and trial)
    if (debtor.id > 0 && !debtor.isDemo && !isTrialMode) {
      try {
        setIsSavingCloud(true);
        await queryTurso("UPDATE debtors SET status = ? WHERE id = ? AND user_id = ?;", [newStatus, debtor.id, currentUser.id]);
        broadcastDebtorsChange(currentUser.id, 'toggle_status');
      } catch (err: any) {
        console.warn("تنبيه المزامنة السحابية أثناء تعديل الحالة:", err?.message || err);
      } finally {
        setIsSavingCloud(false);
      }
    }
  };

  // Delete Debtor Handler
  const handleDeleteDebtor = (debtor: Debtor) => {
    setConfirmState({
      isOpen: true,
      title: "حذف سجل المدين",
      message: `هل أنت متأكد من رغبتك في حذف سجل المدين "${debtor.name}" نهائياً؟`,
      onConfirm: async () => {
        if (!currentUser) return;

        // Clean up history
        const historyMap = getLocalDebtorHistory(currentUser.id);
        const debtorTxs = historyMap[debtor.id] || [];
        if (historyMap[debtor.id]) {
          delete historyMap[debtor.id];
          setLocalDebtorHistory(currentUser.id, historyMap);
        }

        // 1. Immediate local update
        const updated = allDebtors.filter((d) => d.id !== debtor.id);
        setAllDebtors(updated);
        setLocalDebtors(currentUser.id, updated);
        await deleteIdbDebtor(debtor.id);

        // Calculate amount added and paid by this specific debtor
        let debtorAdded = 0;
        let debtorPaid = 0;
        if (debtorTxs.length > 0) {
          debtorAdded = debtorTxs.filter((t) => t.type === 'add').reduce((s, t) => s + t.amount, 0);
          debtorPaid = debtorTxs.filter((t) => t.type === 'pay').reduce((s, t) => s + t.amount, 0);
        } else {
          debtorAdded = debtor.amount || 0;
          debtorPaid = 0;
        }

        // Update stats state & storage immediately
        if (updated.length === 0) {
          const zeroStats = { totalAdded: 0, totalPaid: 0 };
          setStats(zeroStats);
          setLocalStats(currentUser.id, zeroStats);
          await saveIdbStats(currentUser.id, zeroStats);
        } else {
          setStats((prev) => {
            const nextPaid = Math.max(0, prev.totalPaid - debtorPaid);
            const currentRemainingDebts = updated.reduce((s, d) => s + (d.amount || 0), 0);
            const nextAdded = Math.max(
              currentRemainingDebts + nextPaid,
              Math.max(0, prev.totalAdded - debtorAdded)
            );
            const next = { totalAdded: nextAdded, totalPaid: nextPaid };
            setLocalStats(currentUser.id, next);
            saveIdbStats(currentUser.id, next);
            return next;
          });
        }

        setConfirmState((prev) => ({ ...prev, isOpen: false }));
        showToast(`تم حذف سجل "${debtor.name}"`, "info");

        // 2. Background sync to Turso (skip for demo debtors and trial)
        if (debtor.id > 0 && !debtor.isDemo && !isTrialMode) {
          try {
            setIsSavingCloud(true);
            await queryTurso("DELETE FROM debtors WHERE id = ? AND user_id = ?;", [debtor.id, currentUser.id]);
            broadcastDebtorsChange(currentUser.id, 'delete');
          } catch (err: any) {
            console.warn("تنبيه المزامنة السحابية أثناء الحذف:", err?.message || err);
          } finally {
            setIsSavingCloud(false);
          }
        }
      },
    });
  };

  // Admin-Only: Add 100 Demo Debtors for Testing (Local Only, Never Saved to Cloud DB)
  const handleAddDemoDebtors = () => {
    if (!currentUser || currentUser.role !== 'admin') return;

    // Filter out existing demo debtors if any to avoid stacking duplicates
    const realDebtors = allDebtors.filter((d) => !isDemoDebtor(d));
    const demoList = generate100DemoDebtors(currentUser.id, settings.highDebtThreshold);

    const historyMap = getLocalDebtorHistory(currentUser.id);
    const datesMap = getLocalDebtorDates(currentUser.id);

    demoList.forEach((d) => {
      if (d.history) {
        historyMap[d.id] = d.history;
      }
      if (d.createdAt) {
        datesMap[d.id] = d.createdAt;
      }
    });

    const combined = [...demoList, ...realDebtors];
    setAllDebtors(combined);
    setLocalDebtors(currentUser.id, combined);
    setLocalDebtorHistory(currentUser.id, historyMap);
    setLocalDebtorDates(currentUser.id, datesMap);

    showToast("تمت إضافة 100 مدين تجريبي بنجاح للاختبار (محلية فقط دون التأثير على السحابة)", "success");
  };

  // Admin-Only: Clear All Demo Debtors
  const handleClearDemoDebtors = async () => {
    if (!currentUser || currentUser.role !== 'admin') return;

    // Detect all demo debtors using robust multi-attribute check
    const demoDebtorsToRemove = allDebtors.filter(isDemoDebtor);
    const remainingReal = allDebtors.filter((d) => !isDemoDebtor(d));
    const demoCount = demoDebtorsToRemove.length;

    if (demoCount === 0) {
      showToast("لا يوجد أي مدينين تجريبيين في القائمة حالياً", "info");
      return;
    }

    // 1. Immediately update State
    setAllDebtors(remainingReal);

    // 2. Immediately update LocalStorage
    setLocalDebtors(currentUser.id, remainingReal);

    // 3. Immediately overwrite IndexedDB with ONLY remaining real debtors (crucial to prevent resurrection on reload)
    try {
      await saveIdbDebtors(currentUser.id, remainingReal);
      // Clean each demo debtor ID explicitly from IndexedDB
      for (const d of demoDebtorsToRemove) {
        await deleteIdbDebtor(d.id).catch(() => {});
      }
    } catch (err) {
      console.warn("IndexedDB clear demo error:", err);
    }

    // 4. Clean demo history and dates from local maps
    const historyMap = getLocalDebtorHistory(currentUser.id);
    const datesMap = getLocalDebtorDates(currentUser.id);
    demoDebtorsToRemove.forEach((d) => {
      delete historyMap[d.id];
      delete datesMap[d.id];
    });
    setLocalDebtorHistory(currentUser.id, historyMap);
    setLocalDebtorDates(currentUser.id, datesMap);

    // 5. Clean up from Turso cloud database if any demo record ever slipped into cloud
    try {
      setIsSavingCloud(true);
      await queryTurso(
        "DELETE FROM debtors WHERE user_id = ? AND (phone LIKE '%*%' OR phone LIKE '%X%' OR phone = '077********' OR id < 0);",
        [currentUser.id]
      );
    } catch (err: any) {
      console.warn("Turso cloud demo cleanup notice:", err);
    } finally {
      setIsSavingCloud(false);
    }

    // 6. Recalculate statistics to match strictly the real debtors
    const remainingDebtsTotal = remainingReal.reduce((s, d) => s + (Number(d.amount) || 0), 0);
    setStats((prev) => {
      const nextAdded = Math.max(remainingDebtsTotal + prev.totalPaid, 0);
      const next = { ...prev, totalAdded: nextAdded };
      setLocalStats(currentUser.id, next);
      saveIdbStats(currentUser.id, next);
      return next;
    });

    showToast(`تم حذف كافة البيانات التجريبية بنجاح (${demoCount} مدين) من كافة التبويبات وقاعدة البيانات`, "success");
  };

  // Create Manager Handler
  const handleCreateManager = async (
    branch: string,
    user: string,
    pass: string,
    subscriptionType: SubscriptionType = 'permanent',
    subscriptionMonths: number = 1
  ) => {
    try {
      setIsSavingCloud(true);
      const salt = bcrypt.genSaltSync(10);
      const hashedPassword = bcrypt.hashSync(pass, salt);

      let expiresAt: string | null = null;
      if (subscriptionType === 'monthly') {
        const exp = new Date();
        exp.setMonth(exp.getMonth() + (subscriptionMonths || 1));
        expiresAt = exp.toISOString().split('T')[0];
      }

      let res;
      try {
        res = await queryTurso(
          "INSERT INTO users (username, password, plain_password, role, branch_name, is_active, subscription_type, subscription_expires_at) VALUES (?, ?, ?, 'manager', ?, 1, ?, ?) RETURNING id;",
          [user, hashedPassword, pass, branch, subscriptionType, expiresAt]
        );
      } catch {
        await queryTurso("ALTER TABLE users ADD COLUMN plain_password TEXT;").catch(() => {});
        res = await queryTurso(
          "INSERT INTO users (username, password, plain_password, role, branch_name, is_active, subscription_type, subscription_expires_at) VALUES (?, ?, ?, 'manager', ?, 1, ?, ?) RETURNING id;",
          [user, hashedPassword, pass, branch, subscriptionType, expiresAt]
        );
      }

      if (res.results && res.results[0] && res.results[0].response?.result?.rows) {
        const newManagerId = parseInt(res.results[0].response.result.rows[0][0].value);
        if (!isNaN(newManagerId)) {
          // Initialize pristine zero statistics for the new manager
          setLocalStats(newManagerId, { totalAdded: 0, totalPaid: 0 });
          saveIdbStats(newManagerId, { totalAdded: 0, totalPaid: 0 });
          setLocalDebtors(newManagerId, []);
          saveIdbDebtors(newManagerId, []);
          setLocalSettings(newManagerId, DEFAULT_SETTINGS);
          saveIdbSettings(newManagerId, DEFAULT_SETTINGS);

          // Cache manager password locally so it can be viewed and verified
          localStorage.setItem(`user_pwd_${newManagerId}`, pass);
          localStorage.setItem(`user_pwd_${user}`, pass);

          const newMgr: Manager = {
            id: newManagerId,
            username: user,
            branch,
            isActive: true,
            subscriptionType,
            subscriptionExpiresAt: expiresAt,
            plainPassword: pass,
          };
          const updatedManagers = [...managers, newMgr];
          setManagers(updatedManagers);
          setLocalManagers(updatedManagers);
          saveIdbManagers(updatedManagers);
        }
      }
      showToast("تم إنشاء حساب المدير الفرعي بنجاح!", "success");
    } catch (err: any) {
      throw new Error("خطأ أثناء الإنشاء: " + (err.message || 'خطأ غير معروف'));
    } finally {
      setIsSavingCloud(false);
    }
  };

  // Update / Reset Manager Password (by Admin)
  const handleUpdateManagerPassword = async (managerId: number, newPass: string) => {
    try {
      setIsSavingCloud(true);
      const salt = bcrypt.genSaltSync(10);
      const hashedPassword = bcrypt.hashSync(newPass, salt);

      try {
        await queryTurso("UPDATE users SET password = ?, plain_password = ? WHERE id = ?;", [
          hashedPassword,
          newPass,
          managerId,
        ]);
      } catch {
        await queryTurso("ALTER TABLE users ADD COLUMN plain_password TEXT;").catch(() => {});
        await queryTurso("UPDATE users SET password = ?, plain_password = ? WHERE id = ?;", [
          hashedPassword,
          newPass,
          managerId,
        ]);
      }

      const mgr = managers.find((m) => m.id === managerId);
      localStorage.setItem(`user_pwd_${managerId}`, newPass);
      if (mgr) {
        localStorage.setItem(`user_pwd_${mgr.username}`, newPass);
      }

      const updated = managers.map((m) =>
        m.id === managerId ? { ...m, plainPassword: newPass } : m
      );
      setManagers(updated);
      setLocalManagers(updated);
      await saveIdbManagers(updated);

      showToast("تم تحديث وحفظ كلمة مرور المدير الفرعي بنجاح!", "success");
    } catch (err: any) {
      showToast("فشل تحديث كلمة المرور: " + (err.message || 'خطأ غير معروف'), "error");
      throw err;
    } finally {
      setIsSavingCloud(false);
    }
  };

  // Instant Suspend / Activate Manager Handler
  const handleToggleManagerStatus = async (id: number, currentActive: boolean) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;
    const newActive = !currentActive;

    // 1. Instant optimistic local update
    const updated = managers.map((m) => (m.id === id ? { ...m, isActive: newActive } : m));
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    // 2. Broadcast force logout across all tabs and devices
    if (!newActive) {
      broadcastManagerStatusChange(
        id,
        false,
        `تم إيقاف حساب المدير "${target.username}" من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.`
      );
      if (currentUser && currentUser.id === id) {
        handleForceLogout(`تم إيقاف حسابك من قبل الإدارة العامة فوراً، وتم إنهاء الجلسة.`);
        return;
      }
    } else {
      broadcastManagerStatusChange(id, true);
    }

    showToast(
      newActive
        ? `تم تنشيط حساب المدير "${target.username}" فوراً`
        : `تم إيقاف حساب المدير "${target.username}" فوراً وإنهاء جلسته`,
      newActive ? 'success' : 'info'
    );

    // 3. Background sync to database
    try {
      setIsSavingCloud(true);
      await queryTurso("UPDATE users SET is_active = ? WHERE id = ?;", [newActive ? 1 : 0, id]);
    } catch (err: any) {
      console.warn("تنبيه تحديث حالة المدير في السحابة:", err);
    } finally {
      setIsSavingCloud(false);
    }
  };

  // Renew Manager Monthly Subscription Handler
  const handleRenewSubscription = async (id: number, months: number = 1) => {
    const target = managers.find((m) => m.id === id);
    if (!target) return;

    let baseDate = new Date();
    if (target.subscriptionExpiresAt) {
      const existingExp = new Date(target.subscriptionExpiresAt);
      if (existingExp.getTime() > Date.now()) {
        baseDate = existingExp;
      }
    }
    baseDate.setMonth(baseDate.getMonth() + months);
    const newExpiresAt = baseDate.toISOString().split('T')[0];

    // 1. Instant optimistic local update (also ensure isActive is true upon renewal)
    const updated = managers.map((m) =>
      m.id === id
        ? {
            ...m,
            subscriptionExpiresAt: newExpiresAt,
            isActive: true,
          }
        : m
    );
    setManagers(updated);
    setLocalManagers(updated);
    await saveIdbManagers(updated);

    // 2. Clear force logout flag & broadcast activation
    broadcastManagerStatusChange(id, true);

    showToast(
      `تم تجديد الاشتراك الشهري للمدير "${target.username}" حتى ${newExpiresAt} وتنشيط حسابه`,
      'success'
    );

    // 3. Background sync to database
    try {
      setIsSavingCloud(true);
      await queryTurso(
        "UPDATE users SET subscription_expires_at = ?, is_active = 1 WHERE id = ?;",
        [newExpiresAt, id]
      );
    } catch (err: any) {
      console.warn("تنبيه تجديد اشتراك المدير في السحابة:", err);
    } finally {
      setIsSavingCloud(false);
    }
  };

  // Delete Manager Handler
  const handleDeleteManager = (id: number) => {
    const targetManager = managers.find((m) => m.id === id);
    setConfirmState({
      isOpen: true,
      title: "حذف المدير الفرعي",
      message: `هل أنت متأكد من حذف حساب المدير "${targetManager?.username || id}"؟ سيتم إنهاء جلسته فوراً.`,
      onConfirm: async () => {
        try {
          setIsSavingCloud(true);
          const updated = managers.filter((m) => m.id !== id);
          setManagers(updated);
          setLocalManagers(updated);
          saveIdbManagers(updated);

          // Force logout for deleted manager immediately
          broadcastManagerStatusChange(id, false, "تم حذف هذا الحساب من قبل الإدارة العامة.");
          if (currentUser && currentUser.id === id) {
            handleForceLogout("تم حذف هذا الحساب من قبل الإدارة العامة.");
          }

          setConfirmState((prev) => ({ ...prev, isOpen: false }));
          showToast("تم حذف المدير بنجاح", "info");

          await queryTurso("DELETE FROM users WHERE id = ?;", [id]);
        } catch (err: any) {
          showToast(err.message || "حدث خطأ أثناء الحذف", "error");
        } finally {
          setIsSavingCloud(false);
        }
      },
    });
  };

  // Calculations
  const totalAmount = allDebtors.reduce((sum, d) => sum + (d.amount || 0), 0);
  const debtorsOnlyCount = allDebtors.filter((d) => d.amount > 0).length;
  const paidOnlyCount = allDebtors.filter((d) => d.amount <= 0).length;
  const highDebtorsCount = allDebtors.filter(
    (d) => d.amount >= settings.highDebtThreshold && d.amount > 0
  ).length;
  const demoDebtorsCount = allDebtors.filter(isDemoDebtor).length;
  const alertTriggeredCount = allDebtors.filter((d) => {
    if (!settings.enableDebtAlerts || d.amount <= 0) return false;
    const days = calculateDaysElapsed(d.createdAt);
    return days >= settings.alertDaysThreshold;
  }).length;

  const overdueCount = allDebtors.filter((d) => {
    if (d.amount <= 0 || d.status === 'خالي من الدين') return false;
    if (d.status === 'متأخر') return true;
    if (settings.enableDebtAlerts) {
      const days = calculateDaysElapsed(d.createdAt);
      return days >= settings.alertDaysThreshold;
    }
    return false;
  }).length;

  // Filtered Cards - Sorted from Highest Debt to Lowest Debt
  const filteredDebtors = allDebtors
    .filter((d) => {
      const query = searchTerm.toLowerCase().trim();
      const matchesQuery =
        !query ||
        d.name.toLowerCase().includes(query) ||
        (d.phone && d.phone.includes(query));

      if (!matchesQuery) return false;
      if (filter === 'debtors_only') return d.amount > 0;
      if (filter === 'paid_only') return d.amount <= 0;
      if (filter === 'high_debt') return d.amount >= settings.highDebtThreshold && d.amount > 0;
      return true;
    })
    .sort((a, b) => {
      // Sort from highest debt to lowest debt
      if (b.amount !== a.amount) {
        return b.amount - a.amount;
      }
      return a.name.localeCompare(b.name, 'ar');
    });

  if (!currentUser) {
    return (
      <div className="min-h-screen w-full bg-[#080f24] text-slate-100 antialiased font-sans" dir="rtl">
        <ToastContainer toasts={toasts} onDismiss={dismissToast} />
        <LoginOverlay
          onLoginSuccess={handleLoginSuccess}
          initialErrorMessage={loginErrorMessage}
        />
      </div>
    );
  }

  return (
    <div className="h-[100dvh] max-w-[480px] mx-auto flex flex-col bg-slate-50 text-slate-800 relative shadow-2xl overflow-hidden select-none" dir="rtl">
      {/* Toast Messages */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Main App Container */}
      <main className="flex-1 flex flex-col overflow-hidden relative" id="appContainer">
        {/* HOME TAB */}
        {activeTab === 'home' && (
          <div id="tab-home" className="flex-1 flex flex-col overflow-hidden animate-in fade-in duration-150">
            {/* Fixed Top Header & Filters (stays 100% fixed) */}
            <div className="shrink-0 z-30 bg-slate-50 shadow-xs border-b border-slate-200/40">
              <HeaderCard
                currentUser={currentUser}
                debtorsCount={allDebtors.length}
                totalAmount={totalAmount}
                onLogout={handleLogout}
                isSaving={isSavingCloud}
                searchTerm={searchTerm}
                onSearchChange={setSearchTerm}
              />

              <Controls
                searchTerm={searchTerm}
                onSearchChange={setSearchTerm}
                filter={filter}
                onFilterChange={setFilter}
                totalCount={allDebtors.length}
                debtorsOnlyCount={debtorsOnlyCount}
                paidOnlyCount={paidOnlyCount}
                highDebtCount={highDebtorsCount}
                viewMode={viewMode}
                onViewModeChange={handleViewModeChange}
                displayedCount={filteredDebtors.length}
              />
            </div>

            {/* Scrollable Debtors List ONLY */}
            <div
              className="flex-1 overflow-y-auto overscroll-contain px-4 pt-2.5 pb-32 sm:pb-36 space-y-2 focus:outline-none"
              id="debtorsListScrollContainer"
            >
              {filteredDebtors.length === 0 ? (
                <div className="text-center py-10 bg-white rounded-2xl border border-dashed border-slate-200 p-6 shadow-xs">
                  <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center mx-auto mb-3 text-lg">
                    {filter === 'paid_only' ? (
                      <i className="fa-solid fa-circle-check text-emerald-500"></i>
                    ) : filter === 'high_debt' ? (
                      <i className="fa-solid fa-arrow-trend-up text-red-500"></i>
                    ) : (
                      <i className="fa-solid fa-users-slash"></i>
                    )}
                  </div>
                  <div className="font-bold text-sm text-slate-700 mb-1">
                    {searchTerm
                      ? 'لم يتم العثور على نتائج مطابقة'
                      : filter === 'paid_only'
                      ? 'لا يوجد مدينين خاليين من الدين حالياً'
                      : filter === 'high_debt'
                      ? 'لا يوجد عملاء بذمم تتجاوز سقف الدين المرتفع'
                      : filter === 'debtors_only'
                      ? 'لا يوجد مدينين بذمم قائمة حالياً'
                      : 'لا يوجد مدينين مسجلين بعد'}
                  </div>
                  <p className="text-xs text-slate-400 mb-4">
                    {searchTerm
                      ? 'تأكد من كتابة الاسم أو رقم الهاتف بشكل صحيح'
                      : filter === 'paid_only'
                      ? 'عند قيام أحد المدينين بتسديد رصيده كاملاً سيظهر هنا'
                      : filter === 'high_debt'
                      ? `سقف الدين المرتفع محدد حالياً بـ (${settings.highDebtThreshold.toLocaleString()} د.ع)`
                      : 'يمكنك إضافة مدين جديد عبر زر (+) في الشريط السفلي'}
                  </p>
                </div>
              ) : (
                <div className="flex flex-col gap-2" id="debtorsListContainer">
                  {filteredDebtors.map((debtor) => (
                    <DebtorListItem
                      key={debtor.id}
                      debtor={debtor}
                      settings={settings}
                      onPay={handleOpenPayModal}
                      onAddDebt={handleOpenAddDebtModal}
                      onDelete={handleDeleteDebtor}
                      onShowToast={showToast}
                      onViewHistory={handleOpenHistoryModal}
                      onShare={handleOpenShareModal}
                      onEditName={handleOpenEditNameModal}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* REPORTS TAB */}
        {activeTab === 'reports' && (
          <div className="flex-1 overflow-y-auto overscroll-contain">
            <ReportsTab
              currentUser={currentUser}
              debtors={allDebtors}
              stats={stats}
              settings={settings}
              onUpdateStats={handleUpdateStats}
              onResetStats={handleResetStats}
            />
          </div>
        )}

        {/* OVERDUE TAB */}
        {activeTab === 'overdue' && (
          <div className="flex-1 overflow-y-auto overscroll-contain">
            <OverdueTab
              debtors={allDebtors}
              settings={settings}
              onOpenPayModal={handleOpenPayModal}
              onToggleOverdueStatus={handleToggleOverdueStatus}
              onShowToast={showToast}
              onViewHistory={handleOpenHistoryModal}
              onShare={handleOpenShareModal}
            />
          </div>
        )}

        {/* SETTINGS TAB */}
        {activeTab === 'settings' && (
          <div className="flex-1 overflow-y-auto overscroll-contain">
            <SettingsTab
              currentUser={currentUser}
              managers={managers}
              stats={stats}
              currentDebts={totalAmount}
              onUpdateStats={handleUpdateStats}
              onCreateManager={handleCreateManager}
              onToggleManagerStatus={handleToggleManagerStatus}
              onRenewSubscription={handleRenewSubscription}
              onDeleteManager={handleDeleteManager}
              onLogout={handleLogout}
              isManagersLoading={isManagersLoading}
              settings={settings}
              onUpdateSettings={handleUpdateSettings}
              totalDebtorsCount={allDebtors.length}
              highDebtorsCount={highDebtorsCount}
              alertTriggeredCount={alertTriggeredCount}
              allDebtors={allDebtors}
              onImportDebtors={handleImportDebtors}
              onShowToast={showToast}
              onAddDemoDebtors={handleAddDemoDebtors}
              onClearDemoDebtors={handleClearDemoDebtors}
              demoDebtorsCount={demoDebtorsCount}
              onUpdateManagerPassword={handleUpdateManagerPassword}
              onRefreshManagers={loadManagersFromCloud}
            />
          </div>
        )}

        {/* MANAGERS TAB (Fallback) */}
        {activeTab === 'managers' && currentUser.role === 'admin' && (
          <div className="flex-1 overflow-y-auto overscroll-contain p-4">
            <ManagersTab
              managers={managers}
              onCreateManager={handleCreateManager}
              onToggleManagerStatus={handleToggleManagerStatus}
              onRenewSubscription={handleRenewSubscription}
              onDeleteManager={handleDeleteManager}
              onUpdateManagerPassword={handleUpdateManagerPassword}
              onRefreshManagers={loadManagersFromCloud}
              isLoading={isManagersLoading}
            />
          </div>
        )}
      </main>

          {/* DEBTOR HISTORY MODAL */}
          <DebtorHistoryModal
            isOpen={historyModalState.isOpen}
            debtor={historyModalState.debtor}
            onClose={() => setHistoryModalState({ isOpen: false, debtor: null })}
            onShowToast={showToast}
          />

          {/* DEBTOR SHARE MODAL */}
          {shareModalState.isOpen && shareModalState.debtor && (
            <DebtorShareModal
              isOpen={shareModalState.isOpen}
              debtor={shareModalState.debtor}
              storeName={currentUser.branch_name || settings.storeName || 'دفتر الديون'}
              onClose={() => setShareModalState({ isOpen: false, debtor: null })}
              onShowToast={showToast}
            />
          )}

          {/* ADD DEBTOR MODAL */}
          <AddDebtorModal
            isOpen={isAddModalOpen}
            onClose={() => setIsAddModalOpen(false)}
            onSave={handleSaveDebtor}
          />

          {/* TRANSACTION MODAL (Pay / Add Debt) */}
          <TransactionModal
            isOpen={transactionState.isOpen}
            type={transactionState.type}
            debtor={transactionState.debtor}
            onClose={() =>
              setTransactionState({ isOpen: false, type: 'pay', debtor: null })
            }
            onConfirm={
              transactionState.type === 'pay'
                ? handleConfirmPay
                : handleConfirmAddDebt
            }
          />

          {/* CONFIRM MODAL */}
          <ConfirmModal
            isOpen={confirmState.isOpen}
            title={confirmState.title}
            message={confirmState.message}
            onConfirm={confirmState.onConfirm}
            onCancel={() => setConfirmState((prev) => ({ ...prev, isOpen: false }))}
          />

          {/* SETTLE COMPLETE MODAL (Keep or Delete upon full payment) */}
          <SettleCompleteModal
            isOpen={settleCompleteState.isOpen}
            debtor={settleCompleteState.debtor}
            onKeep={handleKeepSettledDebtor}
            onDelete={handleDeleteSettledDebtor}
          />

          {/* EDIT DEBTOR NAME MODAL */}
          <EditDebtorNameModal
            isOpen={isEditNameModalOpen}
            debtor={editingNameDebtor}
            onClose={() => {
              setIsEditNameModalOpen(false);
              setEditingNameDebtor(null);
            }}
            onSave={handleSaveDebtorName}
          />

          {/* TRIAL LIMIT MODAL */}
          <TrialLimitModal
            isOpen={isTrialLimitModalOpen}
            onClose={() => setIsTrialLimitModalOpen(false)}
            debtorsCount={allDebtors.length}
          />

          {/* BOTTOM NAVIGATION */}
          <BottomNav
            activeTab={activeTab}
            onSelectTab={setActiveTab}
            onOpenAddModal={handleOpenAddModal}
            isAdmin={currentUser.role === 'admin'}
            overdueCount={overdueCount}
          />
    </div>
  );
}
