/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import {
  LayoutDashboard,
  ShoppingCart,
  Pill,
  Tags,
  Receipt,
  PackageOpen,
  ShoppingBag,
  Users,
  Truck,
  BarChart3,
  DatabaseBackup,
  Settings,
  Menu,
  X,
  Activity,
  ShieldCheck,
  LogOut
} from "lucide-react";

interface NavigationProps {
  currentView: string;
  onViewChange: (view: string) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  pharmacyName: string;
  logo: string;
  lowStockCount: number;
  expiredCount: number;
  userRole?: string;
  onLogout?: () => void;
}

export default function Navigation({
  currentView,
  onViewChange,
  sidebarOpen,
  setSidebarOpen,
  pharmacyName,
  logo,
  lowStockCount,
  expiredCount,
  userRole,
  onLogout
}: NavigationProps) {
  const alertsTotal = lowStockCount + expiredCount;

  const baseMenuItems = [
    { id: "dashboard", label: "الرئيسية", icon: LayoutDashboard },
    { id: "pos", label: "شاشة البيع (POS)", icon: ShoppingCart },
    { id: "products", label: "إدارة الأدوية", icon: Pill },
    { id: "categories", label: "فئات الأدوية", icon: Tags },
    { id: "invoices", label: "سجل المبيعات", icon: Receipt },
    { id: "inventory", label: "المخزون والرفوف", icon: PackageOpen, badge: alertsTotal > 0 ? alertsTotal : undefined, badgeColor: expiredCount > 0 ? "bg-rose-500" : "bg-amber-500" },
    { id: "purchases", label: "المشتريات والوارد", icon: ShoppingBag },
    { id: "customers", label: "العملاء والديون", icon: Users },
    { id: "suppliers", label: "الموردون والحسابات", icon: Truck },
    { id: "reports", label: "التقارير المالية", icon: BarChart3 },
    { id: "backup", label: "النسخ الاحتياطي", icon: DatabaseBackup },
    { id: "settings", label: "الإعدادات", icon: Settings }
  ];

  const menuItems = [...baseMenuItems];
  if (userRole === "super_admin") {
    menuItems.push({ id: "admin", label: "لوحة تحكم المدير", icon: ShieldCheck });
  }

  const handleItemClick = (id: string) => {
    onViewChange(id);
    setSidebarOpen(false); // Close drawer on mobile after clicking
  };

  return (
    <>
      {/* --- DESKTOP SIDEBAR --- */}
      <aside className="hidden lg:flex flex-col w-72 h-screen fixed top-0 right-0 border-l border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-y-auto select-none z-30">
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
          {logo ? (
            <img src={logo} alt="Logo" className="w-10 h-10 rounded-xl object-cover" referrerPolicy="no-referrer" />
          ) : (
            <div className="w-10 h-10 rounded-xl bg-emerald-600 dark:bg-emerald-500 flex items-center justify-center text-white font-bold shadow-md shadow-emerald-500/10">
              <Activity className="w-6 h-6" />
            </div>
          )}
          <div>
            <h2 className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate w-48">
              {pharmacyName || "صيدلية الرافدين"}
            </h2>
            <span className="text-xs text-slate-400 dark:text-slate-500 font-mono">نظام صيدلي برو</span>
          </div>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                id={`nav-${item.id}`}
                onClick={() => handleItemClick(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-right text-sm font-medium transition-all duration-150 cursor-pointer ${
                  isActive
                    ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 font-semibold"
                    : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:text-slate-900 dark:hover:text-slate-200"
                }`}
              >
                <Icon className={`w-5 h-5 shrink-0 ${isActive ? "text-emerald-600 dark:text-emerald-400" : "text-slate-400 dark:text-slate-500"}`} />
                <span className="flex-1 text-right">{item.label}</span>
                {item.badge !== undefined && (
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold text-white font-mono ${item.badgeColor}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {onLogout && (
          <div className="px-4 pb-2">
            <button
              onClick={onLogout}
              className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-right text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/20 hover:text-rose-700 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4 shrink-0 text-rose-500" />
              <span>تسجيل الخروج</span>
            </button>
          </div>
        )}

        <div className="p-4 border-t border-slate-100 dark:border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">
            صيدلي برو v1.2.0 • أوفلاين بالكامل
          </p>
        </div>
      </aside>

      {/* --- MOBILE SIDEBAR DRAWER OVERLAY --- */}
      {sidebarOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 backdrop-blur-xs z-40 transition-opacity"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <div
        className={`lg:hidden fixed top-0 right-0 h-full w-80 bg-white dark:bg-slate-900 z-50 shadow-2xl transition-transform duration-300 transform border-l border-slate-200 dark:border-slate-800 overflow-y-auto ${
          sidebarOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {logo ? (
              <img src={logo} alt="Logo" className="w-9 h-9 rounded-xl object-cover" referrerPolicy="no-referrer" />
            ) : (
              <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center text-white font-bold">
                <Activity className="w-5 h-5" />
              </div>
            )}
            <div>
              <h2 className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate w-40">
                {pharmacyName || "صيدلية الرافدين"}
              </h2>
            </div>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="p-4 space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                id={`mobile-nav-${item.id}`}
                onClick={() => handleItemClick(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-right text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 font-semibold"
                    : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
                }`}
              >
                <Icon className={`w-5 h-5 shrink-0 ${isActive ? "text-emerald-600 dark:text-emerald-400" : "text-slate-400 dark:text-slate-500"}`} />
                <span className="flex-1 text-right">{item.label}</span>
                {item.badge !== undefined && (
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold text-white font-mono ${item.badgeColor}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {onLogout && (
          <div className="p-4 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => {
                setSidebarOpen(false);
                onLogout();
              }}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-right text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/20 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4 shrink-0 text-rose-500" />
              <span>تسجيل الخروج</span>
            </button>
          </div>
        )}
      </div>

      {/* --- MOBILE BOTTOM NAVIGATION --- */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 h-16 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-around px-2 z-40 select-none pb-safe">
        <button
          onClick={() => handleItemClick("dashboard")}
          className={`flex flex-col items-center justify-center gap-1 w-16 h-full transition-colors ${
            currentView === "dashboard" ? "text-emerald-600 dark:text-emerald-400" : "text-slate-400 dark:text-slate-500"
          }`}
        >
          <LayoutDashboard className="w-5 h-5" />
          <span className="text-[10px] font-medium font-sans">الرئيسية</span>
        </button>

        <button
          onClick={() => handleItemClick("pos")}
          className={`flex flex-col items-center justify-center gap-1 w-16 h-full transition-colors ${
            currentView === "pos" ? "text-emerald-600 dark:text-emerald-400" : "text-slate-400 dark:text-slate-500"
          }`}
        >
          <ShoppingCart className="w-5 h-5" />
          <span className="text-[10px] font-medium font-sans">البيع</span>
        </button>

        <button
          onClick={() => handleItemClick("products")}
          className={`flex flex-col items-center justify-center gap-1 w-16 h-full transition-colors ${
            currentView === "products" ? "text-emerald-600 dark:text-emerald-400" : "text-slate-400 dark:text-slate-500"
          }`}
        >
          <Pill className="w-5 h-5" />
          <span className="text-[10px] font-medium font-sans">الأدوية</span>
        </button>

        <button
          onClick={() => handleItemClick("inventory")}
          className={`relative flex flex-col items-center justify-center gap-1 w-16 h-full transition-colors ${
            currentView === "inventory" ? "text-emerald-600 dark:text-emerald-400" : "text-slate-400 dark:text-slate-500"
          }`}
        >
          <PackageOpen className="w-5 h-5" />
          <span className="text-[10px] font-medium font-sans">المخزون</span>
          {alertsTotal > 0 && (
            <span className={`absolute top-2 right-4 w-2 h-2 rounded-full ${expiredCount > 0 ? "bg-rose-500 animate-pulse" : "bg-amber-500"}`} />
          )}
        </button>

        <button
          onClick={() => setSidebarOpen(true)}
          className="flex flex-col items-center justify-center gap-1 w-16 h-full text-slate-400 dark:text-slate-500"
        >
          <Menu className="w-5 h-5" />
          <span className="text-[10px] font-medium font-sans">القائمة</span>
        </button>
      </nav>
    </>
  );
}
