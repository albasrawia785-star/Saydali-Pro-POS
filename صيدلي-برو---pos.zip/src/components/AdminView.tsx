/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { FirebaseService } from "../firebase";
import {
  Users,
  Key,
  ShieldAlert,
  UserPlus,
  Search,
  CheckCircle,
  XCircle,
  Calendar,
  Phone,
  Trash2,
  Lock,
  Edit2,
  Plus,
  RefreshCw,
  Copy,
  TrendingUp,
  Activity,
  Award,
  Globe
} from "lucide-react";
import { motion } from "motion/react";

export default function AdminView() {
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    expiredUsers: 0,
    disabledUsers: 0,
    totalCodes: 0,
    usedCodes: 0,
    unusedCodes: 0
  });

  const [users, setUsers] = useState<any[]>([]);
  const [codes, setCodes] = useState<any[]>([]);
  
  // UI states
  const [userSearch, setUserSearch] = useState("");
  const [codeSearch, setCodeSearch] = useState("");
  const [activeTab, setActiveTab] = useState<"users" | "codes">("users");

  // User form state (Creation / Edition)
  const [showUserModal, setShowUserModal] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [targetUserId, setTargetUserId] = useState("");
  
  const [formUsername, setFormUsername] = useState("");
  const [formPassword, setFormPassword] = useState("");
  const [formPharmacyName, setFormPharmacyName] = useState("");
  const [formOwnerName, setFormOwnerName] = useState("");
  const [formPhone, setFormPhone] = useState("");
  const [formRole, setFormRole] = useState("user");
  const [formActive, setFormActive] = useState(true);
  const [formExpireDate, setFormExpireDate] = useState("");

  // Code form state
  const [codeDuration, setCodeDuration] = useState<"1_month" | "3_months" | "6_months" | "1_year">("1_month");
  const [newlyCreatedCode, setNewlyCreatedCode] = useState("");
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Notifications
  const [toast, setToast] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const showToast = (text: string, type: "success" | "error" = "success") => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3000);
  };

  const loadAllData = async () => {
    setLoading(true);
    try {
      await FirebaseService.bootstrapSystem();
      const loadedStats = await FirebaseService.getAdminStats();
      const loadedUsers = await FirebaseService.getAllUsers();
      const loadedCodes = await FirebaseService.getAllLicenseCodes();

      setStats(loadedStats);
      setUsers(loadedUsers);
      setCodes(loadedCodes);
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ في جلب البيانات من فايربيس", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  const handleOpenCreateModal = () => {
    setIsEditMode(false);
    setTargetUserId("");
    setFormUsername("");
    setFormPassword("");
    setFormPharmacyName("");
    setFormOwnerName("");
    setFormPhone("");
    setFormRole("user");
    setFormActive(true);
    
    // Default expire date to 1 month from now
    const nextMonth = new Date();
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    setFormExpireDate(nextMonth.toISOString().split("T")[0]);

    setShowUserModal(true);
  };

  const handleOpenEditModal = (user: any) => {
    setIsEditMode(true);
    setTargetUserId(user.uid);
    setFormUsername(user.username);
    setFormPassword(""); // Leave empty unless modifying
    setFormPharmacyName(user.pharmacyName || "");
    setFormOwnerName(user.ownerName || "");
    setFormPhone(user.phone || "");
    setFormRole(user.role || "user");
    setFormActive(user.active !== false);
    setFormExpireDate(user.expireDate || "");

    setShowUserModal(true);
  };

  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formUsername.trim()) {
      showToast("اسم المستخدم مطلوب!", "error");
      return;
    }

    setLoading(true);
    try {
      if (isEditMode) {
        // Update user
        const updates: any = {
          username: formUsername.trim(),
          pharmacyName: formPharmacyName.trim(),
          ownerName: formOwnerName.trim(),
          phone: formPhone.trim(),
          role: formRole,
          active: formActive,
          expireDate: formExpireDate
        };

        if (formPassword.trim()) {
          updates.passwordPlain = formPassword.trim();
        }

        const res = await FirebaseService.updateUser(targetUserId, updates);
        if (res.success) {
          showToast("تم تحديث بيانات المستخدم بنجاح.");
          setShowUserModal(false);
          await loadAllData();
        } else {
          showToast(res.error || "فشل تحديث المستخدم", "error");
        }
      } else {
        // Create user
        if (!formPassword.trim()) {
          showToast("يجب إدخال كلمة مرور للمستخدم الجديد!", "error");
          setLoading(false);
          return;
        }

        const res = await FirebaseService.createUser({
          username: formUsername.trim(),
          passwordPlain: formPassword.trim(),
          pharmacyName: formPharmacyName.trim(),
          ownerName: formOwnerName.trim(),
          phone: formPhone.trim(),
          role: formRole,
          active: formActive,
          expireDate: formExpireDate
        });

        if (res.success) {
          showToast("تم إنشاء المستخدم الجديد بنجاح في قاعدة البيانات.");
          setShowUserModal(false);
          await loadAllData();
        } else {
          showToast(res.error || "فشل إضافة مستخدم", "error");
        }
      }
    } catch (err: any) {
      showToast(err.message || "حدث خطأ غير متوقع", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (uid: string, username: string) => {
    if (uid === "super_ali" || username === "ali") {
      showToast("حساب المدير العام ali محمي تماماً من الحذف!", "error");
      return;
    }

    if (!window.confirm(`هل أنت متأكد من حذف الحساب "${username}" نهائياً من قاعدة البيانات؟`)) {
      return;
    }

    setLoading(true);
    try {
      const res = await FirebaseService.deleteUser(uid);
      if (res.success) {
        showToast("تم حذف المستخدم نهائياً.");
        await loadAllData();
      } else {
        showToast(res.error || "فشل حذف المستخدم", "error");
      }
    } catch (err: any) {
      showToast(err.message, "error");
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateCode = async () => {
    setLoading(true);
    try {
      const code = await FirebaseService.createLicenseCode(codeDuration);
      setNewlyCreatedCode(code);
      showToast("تم توليد كود اشتراك جديد بنجاح!");
      await loadAllData();
    } catch (err) {
      showToast("حدث خطأ أثناء توليد الكود", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCode = async (code: string) => {
    if (!window.confirm("هل أنت متأكد من حذف هذا الكود؟ لن يتمكن أحد من استخدامه.")) {
      return;
    }

    setLoading(true);
    try {
      const ok = await FirebaseService.deleteLicenseCode(code);
      if (ok) {
        showToast("تم حذف كود التفعيل.");
        await loadAllData();
      } else {
        showToast("فشل الحذف", "error");
      }
    } catch (err) {
      showToast("حدث خطأ", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code).then(() => {
      setCopiedCode(code);
      setTimeout(() => setCopiedCode(null), 2000);
      showToast("تم نسخ الكود إلى الحافظة!");
    }).catch(() => {
      showToast("فشل النسخ التلقائي، يرجى نسخه يدوياً.", "error");
    });
  };

  const getDurationLabel = (dur: string) => {
    switch (dur) {
      case "1_month": return "شهر واحد";
      case "3_months": return "3 أشهر";
      case "6_months": return "6 أشهر";
      case "1_year": return "سنة كاملة";
      default: return dur;
    }
  };

  const filteredUsers = users.filter((u) => {
    const q = userSearch.toLowerCase();
    return (
      u.username?.toLowerCase().includes(q) ||
      u.pharmacyName?.toLowerCase().includes(q) ||
      u.ownerName?.toLowerCase().includes(q) ||
      u.phone?.toLowerCase().includes(q)
    );
  });

  const filteredCodes = codes.filter((c) => {
    const q = codeSearch.toLowerCase();
    return (
      c.code?.toLowerCase().includes(q) ||
      c.duration?.toLowerCase().includes(q) ||
      c.usedBy?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 text-slate-800 dark:text-slate-100" dir="rtl">
      
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed bottom-6 left-6 z-50 px-4 py-3 rounded-xl shadow-lg border text-xs font-bold flex items-center gap-2 animate-bounce ${
          toast.type === "success" 
            ? "bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-900 text-emerald-600 dark:text-emerald-400" 
            : "bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400"
        }`}>
          <Activity className="w-4 h-4" />
          <span>{toast.text}</span>
        </div>
      )}

      {/* Header Panel */}
      <div className="bg-gradient-to-r from-slate-900 to-emerald-950 p-6 md:p-8 rounded-3xl text-white relative overflow-hidden shadow-lg">
        <div className="absolute top-0 left-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2.5">
              <Award className="w-6 h-6 text-emerald-400" />
              <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 font-bold rounded-full text-[10px] tracking-wider uppercase font-sans">
                المدير العام (Super Admin)
              </span>
            </div>
            <h1 className="text-2xl font-black">لوحة التحكم وإدارة التراخيص المشفرة</h1>
            <p className="text-xs text-slate-300">
              قم بإنشاء وتعديل حسابات الصيدليات المعتمدة، التحكم بصلاحية الاشتراكات، وتوليد أكواد التفعيل الفورية.
            </p>
          </div>
          <button
            onClick={loadAllData}
            disabled={loading}
            className="self-start md:self-auto px-4 py-2.5 bg-white/10 hover:bg-white/15 text-white text-xs font-bold rounded-xl transition-all flex items-center gap-2 border border-white/10 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
            <span>تحديث البيانات</span>
          </button>
        </div>
      </div>

      {/* Firebase Database Config Warning Indicator */}
      {!FirebaseService.isConfigured() && (
        <div className="p-4 bg-amber-500/10 border border-amber-500/25 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-amber-500 flex items-center gap-1.5">
                <span>تنبيه: تطبيقك قيد التشغيل في وضع المحاكاة المحلى (Sandbox)</span>
              </h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                لم يتم إدخال كود الاتصال بـ Firebase Realtime Database بعد في ملف <strong className="font-mono">/src/firebase.ts</strong>.
                جميع التعديلات والبيانات الحالية تُخزن محلياً في الـ LocalStorage. لتشغيله عبر الإنترنت، يرجى إدخال إعدادات فايربيس فقط.
              </p>
            </div>
          </div>
          <div className="px-3 py-1.5 bg-amber-500/20 text-amber-600 dark:text-amber-400 rounded-xl text-[10px] font-bold font-mono">
            LOCAL_SANDBOX
          </div>
        </div>
      )}

      {/* Statistics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400 dark:text-slate-555">إجمالي المستخدمين</div>
            <div className="text-lg font-extrabold">{stats.totalUsers}</div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/30 flex items-center justify-center text-emerald-500 shrink-0">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400 dark:text-slate-555">المشتركون النشطون</div>
            <div className="text-lg font-extrabold text-emerald-500">{stats.activeUsers}</div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/30 flex items-center justify-center text-amber-500 shrink-0">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400 dark:text-slate-555">اشتراكات منتهية</div>
            <div className="text-lg font-extrabold text-amber-500">{stats.expiredUsers}</div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-100 dark:border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950/30 flex items-center justify-center text-rose-500 shrink-0">
            <XCircle className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-slate-400 dark:text-slate-555">حسابات معطلة</div>
            <div className="text-lg font-extrabold text-rose-500">{stats.disabledUsers}</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-2">
        <button
          onClick={() => setActiveTab("users")}
          className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === "users"
              ? "border-emerald-500 text-emerald-600 dark:text-emerald-400 font-black"
              : "border-transparent text-slate-400 dark:text-slate-500 hover:text-slate-600"
          }`}
        >
          إدارة حسابات الصيدليات ({users.length})
        </button>
        <button
          onClick={() => setActiveTab("codes")}
          className={`px-5 py-3 text-xs font-bold border-b-2 transition-all cursor-pointer ${
            activeTab === "codes"
              ? "border-emerald-500 text-emerald-600 dark:text-emerald-400 font-black"
              : "border-transparent text-slate-400 dark:text-slate-500 hover:text-slate-600"
          }`}
        >
          أكواد التفعيل والاشتراكات ({codes.length})
        </button>
      </div>

      {/* VIEW A: USERS MANAGEMENT */}
      {activeTab === "users" && (
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            {/* Search */}
            <div className="relative w-full md:max-w-md">
              <span className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                <Search className="w-4 h-4" />
              </span>
              <input
                type="text"
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder="البحث عن صيدلية، اسم مستخدم، هاتف..."
                className="w-full pr-10 pl-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-xs text-slate-700 dark:text-slate-200"
              />
            </div>
            
            {/* Add User button */}
            <button
              onClick={handleOpenCreateModal}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md flex items-center gap-2 cursor-pointer transition-colors"
            >
              <UserPlus className="w-4 h-4" />
              <span>إضافة صيدلية جديدة</span>
            </button>
          </div>

          {/* Users List Card */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-150 dark:border-slate-800 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 dark:bg-slate-950 text-slate-400 font-bold border-b border-slate-100 dark:border-slate-800">
                  <tr>
                    <th className="p-4">صيدلية / مالك</th>
                    <th className="p-4">اسم الدخول</th>
                    <th className="p-4">رقم الهاتف</th>
                    <th className="p-4">انتهاء الترخيص</th>
                    <th className="p-4">النوع / الدور</th>
                    <th className="p-4">الحالة</th>
                    <th className="p-4">آخر دخول</th>
                    <th className="p-4 text-center">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-400">
                        لا يوجد مستخدمون متوافقون مع شروط البحث الحالية.
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((u) => {
                      const isSuper = u.username === "ali";
                      const todayStr = new Date().toISOString().split("T")[0];
                      const isExpired = !isSuper && u.expireDate < todayStr;
                      const isActive = u.active !== false;

                      return (
                        <tr key={u.uid} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                          <td className="p-4">
                            <div className="font-bold">{u.pharmacyName || "غير محدد"}</div>
                            <div className="text-[10px] text-slate-400 mt-0.5">{u.ownerName || "لا يوجد"}</div>
                          </td>
                          <td className="p-4 font-mono font-semibold">{u.username}</td>
                          <td className="p-4 font-mono">{u.phone || "—"}</td>
                          <td className="p-4">
                            {isSuper ? (
                              <span className="text-emerald-500 font-black">أبدي (لا ينتهي)</span>
                            ) : (
                              <div className="flex items-center gap-1.5">
                                <span className={isExpired ? "text-rose-500 font-bold font-mono" : "font-mono"}>
                                  {u.expireDate || "—"}
                                </span>
                                {isExpired && (
                                  <span className="px-1.5 py-0.5 bg-rose-500/10 text-rose-500 text-[9px] font-bold rounded">
                                    منتهي
                                  </span>
                                )}
                              </div>
                            )}
                          </td>
                          <td className="p-4">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              isSuper 
                                ? "bg-amber-100 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400" 
                                : "bg-slate-100 dark:bg-slate-800 text-slate-500"
                            }`}>
                              {u.role === "super_admin" ? "مدير عام" : "مستخدم عادٍ"}
                            </span>
                          </td>
                          <td className="p-4">
                            {isSuper ? (
                              <span className="text-emerald-500 font-semibold flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                نشط دائم
                              </span>
                            ) : isActive ? (
                              <span className="text-emerald-500 font-semibold flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                نشط
                              </span>
                            ) : (
                              <span className="text-rose-500 font-semibold flex items-center gap-1">
                                <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                                معطل
                              </span>
                            )}
                          </td>
                          <td className="p-4 text-slate-400 text-[10px] font-mono">
                            {u.lastLogin || "لم يسجل دخول بعد"}
                          </td>
                          <td className="p-4 text-center">
                            <div className="flex items-center justify-center gap-2">
                              <button
                                onClick={() => handleOpenEditModal(u)}
                                className="p-1.5 text-slate-400 hover:text-emerald-500 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                                title="تعديل الحساب"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              
                              <button
                                onClick={() => handleDeleteUser(u.uid, u.username)}
                                disabled={isSuper}
                                className={`p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${
                                  isSuper 
                                    ? "text-slate-300 dark:text-slate-800 cursor-not-allowed" 
                                    : "text-slate-400 hover:text-rose-500 cursor-pointer"
                                }`}
                                title="حذف الحساب"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VIEW B: LICENSE CODES */}
      {activeTab === "codes" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Create Code Section */}
          <div className="lg:col-span-1 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-150 dark:border-slate-800 space-y-4">
            <h3 className="font-bold text-xs text-slate-800 dark:text-slate-250 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
              <Key className="w-5 h-5 text-emerald-500" />
              <span>توليد أكواد التفعيل فئة VIP</span>
            </h3>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold">حدد مدة صلاحية الكود الجديد</label>
                <select
                  value={codeDuration}
                  onChange={(e: any) => setCodeDuration(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs"
                >
                  <option value="1_month">شهر واحد (30 يوم)</option>
                  <option value="3_months">3 أشهر (90 يوم)</option>
                  <option value="6_months">6 أشهر (180 يوم)</option>
                  <option value="1_year">سنة كاملة (365 يوم)</option>
                </select>
              </div>

              <button
                onClick={handleGenerateCode}
                disabled={loading}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>توليد الكود الآن</span>
              </button>

              {newlyCreatedCode && (
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-emerald-500/20 text-center space-y-2">
                  <span className="text-[10px] text-slate-400 block font-semibold">الكود الذي تم توليده هو:</span>
                  <div className="font-mono text-base font-black tracking-widest text-emerald-600 dark:text-emerald-400">
                    {newlyCreatedCode}
                  </div>
                  <button
                    onClick={() => handleCopyCode(newlyCreatedCode)}
                    className="mx-auto flex items-center gap-1 text-[11px] font-bold text-slate-500 hover:text-slate-800 dark:hover:text-slate-100 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>نسخ الكود</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Code List Section */}
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-150 dark:border-slate-800 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-xs text-slate-800 dark:text-slate-250 flex items-center gap-2">
                <Globe className="w-5 h-5 text-emerald-500" />
                <span>سجل تتبع أكواد التفعيل والتراخيص</span>
              </h3>
              
              <div className="relative w-full md:max-w-xs">
                <span className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                  <Search className="w-3.5 h-3.5" />
                </span>
                <input
                  type="text"
                  value={codeSearch}
                  onChange={(e) => setCodeSearch(e.target.value)}
                  placeholder="البحث عن كود، مده، مستخدم..."
                  className="w-full pr-9 pl-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-[11px]"
                />
              </div>
            </div>

            <div className="overflow-y-auto max-h-[400px]">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 dark:bg-slate-950 text-slate-400 font-bold">
                  <tr>
                    <th className="p-3">الكود</th>
                    <th className="p-3">صلاحيته</th>
                    <th className="p-3">الحالة</th>
                    <th className="p-3">استخدم بواسطة</th>
                    <th className="p-3 text-center">حذف</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
                  {filteredCodes.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-6 text-center text-slate-400 text-xs">
                        لا توجد أكواد تفعيل حالية.
                      </td>
                    </tr>
                  ) : (
                    filteredCodes.map((c) => {
                      const isUsed = c.used === true || c.used === "true";
                      return (
                        <tr key={c.code} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                          <td className="p-3">
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-bold text-slate-700 dark:text-slate-250">{c.code}</span>
                              <button
                                onClick={() => handleCopyCode(c.code)}
                                className="text-slate-400 hover:text-slate-800 dark:hover:text-white p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                                title="نسخ الكود"
                              >
                                {copiedCode === c.code ? (
                                  <span className="text-[10px] text-emerald-500 font-bold">تم!</span>
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>
                          </td>
                          <td className="p-3 font-semibold text-slate-600 dark:text-slate-400">
                            {getDurationLabel(c.duration)}
                          </td>
                          <td className="p-3">
                            {isUsed ? (
                              <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-400 text-[10px] font-bold rounded-full">
                                مستعمل
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold rounded-full">
                                متاح للتفعيل
                              </span>
                            )}
                          </td>
                          <td className="p-3 font-semibold">
                            {isUsed ? (
                              <div>
                                <span className="text-slate-700 dark:text-slate-300 font-mono">{c.usedBy}</span>
                                {c.usedAt && (
                                  <div className="text-[9px] text-slate-400 mt-0.5 font-mono">{c.usedAt.split("T")[0]}</div>
                                )}
                              </div>
                            ) : (
                              <span className="text-slate-300 dark:text-slate-700">—</span>
                            )}
                          </td>
                          <td className="p-3 text-center">
                            <button
                              onClick={() => handleDeleteCode(c.code)}
                              className="p-1.5 text-slate-400 hover:text-rose-500 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                              title="حذف الكود"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* USER CREATION / EDITION MODAL */}
      {showUserModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800"
          >
            {/* Header */}
            <div className="bg-slate-50 dark:bg-slate-950 p-5 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
              <h3 className="font-bold text-sm text-slate-800 dark:text-slate-200 flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-emerald-500" />
                <span>{isEditMode ? "تعديل بيانات الصيدلية المشتركة" : "إضافة صيدلية مشتركة جديدة"}</span>
              </h3>
              <button
                onClick={() => setShowUserModal(false)}
                className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSaveUser} className="p-6 space-y-4 max-h-[500px] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Pharmacy Name */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold">اسم الصيدلية</label>
                  <input
                    type="text"
                    required
                    value={formPharmacyName}
                    onChange={(e) => setFormPharmacyName(e.target.value)}
                    placeholder="صيدلية الشفاء"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs text-slate-800 dark:text-slate-200"
                  />
                </div>

                {/* Owner Name */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold">اسم مالك الصيدلية</label>
                  <input
                    type="text"
                    required
                    value={formOwnerName}
                    onChange={(e) => setFormOwnerName(e.target.value)}
                    placeholder="الدكتور محمد علي"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs text-slate-800 dark:text-slate-200"
                  />
                </div>

                {/* Phone */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold">رقم هاتف الصيدلية</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                      <Phone className="w-3.5 h-3.5" />
                    </span>
                    <input
                      type="text"
                      value={formPhone}
                      onChange={(e) => setFormPhone(e.target.value)}
                      placeholder="077XXXXXXXX"
                      className="w-full pr-9 pl-3 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs text-slate-800 dark:text-slate-200 font-mono"
                    />
                  </div>
                </div>

                {/* Username */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold">اسم دخول الحساب (Username)</label>
                  <input
                    type="text"
                    required
                    disabled={isEditMode && formUsername === "ali"}
                    value={formUsername}
                    onChange={(e) => setFormUsername(e.target.value.toLowerCase().replace(/\s+/g, ""))}
                    placeholder="مثال: pharma_baghdad"
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs text-slate-800 dark:text-slate-200 font-mono disabled:opacity-50"
                  />
                </div>

                {/* Password */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold">
                    {isEditMode ? "كلمة مرور جديدة (اتركه فارغاً للإبقاء)" : "كلمة مرور الدخول"}
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                      <Lock className="w-3.5 h-3.5" />
                    </span>
                    <input
                      type="password"
                      required={!isEditMode}
                      value={formPassword}
                      onChange={(e) => setFormPassword(e.target.value)}
                      placeholder={isEditMode ? "غير مطلوب ما لم تعدل" : "أدخل كلمة مرور قوية"}
                      className="w-full pr-9 pl-3 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs text-slate-800 dark:text-slate-200"
                    />
                  </div>
                </div>

                {/* Role */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold">نوع الحساب / الدور الصيدلي</label>
                  <select
                    disabled={isEditMode && formUsername === "ali"}
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs text-slate-800 dark:text-slate-200 disabled:opacity-50"
                  >
                    <option value="user">مستخدم عادي (صيدلية)</option>
                    <option value="super_admin">مدير عام (Super Admin)</option>
                  </select>
                </div>

                {/* Expiry Date */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold">تاريخ انتهاء الاشتراك</label>
                  <input
                    type="date"
                    required
                    disabled={isEditMode && formUsername === "ali"}
                    value={formExpireDate}
                    onChange={(e) => setFormExpireDate(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs text-slate-800 dark:text-slate-200 font-mono disabled:opacity-50"
                  />
                </div>

                {/* Active Status */}
                <div className="space-y-1.5 flex flex-col justify-end">
                  <label className="flex items-center gap-2.5 text-xs font-semibold select-none pb-3">
                    <input
                      type="checkbox"
                      disabled={isEditMode && formUsername === "ali"}
                      checked={formActive}
                      onChange={(e) => setFormActive(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 border-slate-300 rounded focus:ring-emerald-500"
                    />
                    <span>حالة الحساب نشطة (يمكنه الدخول)</span>
                  </label>
                </div>

              </div>

              {/* Warnings */}
              {isEditMode && formUsername === "ali" && (
                <p className="text-[10px] text-amber-500 font-semibold leading-relaxed">
                  * هذا هو الحساب الأساسي للمدير العام ali. صلاحياته دائمية ولا يمكن تمديد تاريخه أو إلغاء تفعيله لحماية النظام.
                </p>
              )}

              {/* Submit buttons */}
              <div className="flex gap-2.5 pt-4 border-t border-slate-100 dark:border-slate-850">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md transition-colors cursor-pointer"
                >
                  {isEditMode ? "حفظ التعديلات الحالية" : "إضافة الحساب لقاعدة البيانات"}
                </button>
                <button
                  type="button"
                  onClick={() => setShowUserModal(false)}
                  className="px-5 py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 font-bold rounded-xl transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
              </div>

            </form>
          </motion.div>
        </div>
      )}

    </div>
  );
}
