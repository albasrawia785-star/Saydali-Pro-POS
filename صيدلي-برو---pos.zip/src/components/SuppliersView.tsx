/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Truck,
  Plus,
  Pencil,
  Trash2,
  Search,
  DollarSign,
  X,
  CheckCircle,
  AlertTriangle,
  ShoppingBag,
  MapPin,
  Phone
} from "lucide-react";
import { IndexedDBService } from "../db/indexedDB";
import { Supplier, PurchaseInvoice } from "../types";

interface SuppliersViewProps {
  currency: string;
}

export default function SuppliersView({ currency }: SuppliersViewProps) {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [purchases, setPurchases] = useState<PurchaseInvoice[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  // Form / Modal States
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState<Supplier | null>(null);

  // Settlement States (تسديد الدفعات للموردين)
  const [settlingSupplier, setSettlingSupplier] = useState<Supplier | null>(null);
  const [settleAmount, setSettleAmount] = useState(0);

  // View purchase history
  const [viewHistorySup, setViewHistorySup] = useState<Supplier | null>(null);

  // Form Fields
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [balance, setBalance] = useState<number>(0);

  // Toast
  const [toast, setToast] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const showToast = (text: string, type: "success" | "error" = "success") => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3000);
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const sups = await IndexedDBService.getAll<Supplier>("suppliers");
      const purc = await IndexedDBService.getAll<PurchaseInvoice>("purchases");
      setSuppliers(sups);
      setPurchases(purc);
    } catch (err) {
      console.error(err);
      showToast("خطأ أثناء جلب بيانات الموردين", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openAddModal = () => {
    setEditingSupplier(null);
    setName("");
    setPhone("");
    setAddress("");
    setBalance(0);
    setShowFormModal(true);
  };

  const openEditModal = (sup: Supplier) => {
    setEditingSupplier(sup);
    setName(sup.name);
    setPhone(sup.phone);
    setAddress(sup.address);
    setBalance(sup.balance);
    setShowFormModal(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    try {
      const supData: Supplier = {
        id: editingSupplier ? editingSupplier.id : `sup-${Date.now()}`,
        name,
        phone,
        address: address || "غير محدد",
        balance,
      };

      if (editingSupplier) {
        await IndexedDBService.update("suppliers", supData);
        showToast("تم تحديث معلومات المورد بنجاح");
      } else {
        await IndexedDBService.add("suppliers", supData);
        showToast("تم تسجيل المورد الجديد بنجاح");
      }

      setShowFormModal(false);
      loadData();
    } catch (err) {
      console.error(err);
      showToast("فشلت عملية حفظ المورد", "error");
    }
  };

  const handleDelete = async () => {
    if (!showDeleteModal) return;

    try {
      await IndexedDBService.delete("suppliers", showDeleteModal.id);
      showToast(`تم حذف المورد (${showDeleteModal.name}) بنجاح`);
      setShowDeleteModal(null);
      loadData();
    } catch (err) {
      console.error(err);
      showToast("فشل في حذف المورد من قاعدة البيانات", "error");
    }
  };

  const handlePaymentToSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settlingSupplier || settleAmount <= 0) return;

    if (settleAmount > settlingSupplier.balance) {
      showToast("مبلغ التسديد أكبر من الرصيد المطالب به للمورد!", "error");
      return;
    }

    try {
      const updated = { ...settlingSupplier };
      updated.balance -= settleAmount;
      await IndexedDBService.update("suppliers", updated);

      showToast(`تم تسجيل تسديد دفعة بقيمة ${settleAmount.toLocaleString("ar-IQ")} د.ع للمورد: ${settlingSupplier.name}`);
      setSettlingSupplier(null);
      setSettleAmount(0);
      loadData();
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ أثناء تسوية الدفعات للمورد", "error");
    }
  };

  const getSupplierPurchases = (id: string) => {
    return purchases.filter((p) => p.supplierId === id);
  };

  const filteredSuppliers = suppliers.filter(
    (sup) =>
      sup.name.toLowerCase().includes(search.toLowerCase()) ||
      sup.phone.includes(search) ||
      sup.address.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 text-xs font-sans">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 font-sans">دليل الموردين ومذاخر الأدوية</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 font-sans">إدارة حسابات شركات ومكاتب ومذاخر تجهيز الأدوية وجدولة مستحقاتهم المالية.</p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-md cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>تسجيل مورد جديد</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
        <div className="relative w-full max-w-sm">
          <input
            type="text"
            placeholder="ابحث عن مورد بالاسم، الهاتف، أو العنوان..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-9 pl-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-slate-850 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
          />
          <Search className="absolute right-3 top-3 w-4 h-4 text-slate-400" />
        </div>
        <span className="text-slate-400 font-mono">الموردون النشطون: {suppliers.length}</span>
      </div>

      {/* Suppliers Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-850 border-b text-slate-500 dark:text-slate-400 font-bold text-xs">
                <th className="p-4">اسم المورد / المذخر العلمي</th>
                <th className="p-4">رقم الهاتف والتواصل</th>
                <th className="p-4">المقر / العنوان الرئيسي</th>
                <th className="p-4">الرصيد الدائن (مستحقات المورد)</th>
                <th className="p-4">عدد الفواتير المستوردة</th>
                <th className="p-4 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {loading ? (
                <tr>
                  <td colSpan={6} className="p-10 text-center">
                    <div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                    <span>جاري تحميل قائمة مذاخر الأدوية...</span>
                  </td>
                </tr>
              ) : filteredSuppliers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-12 text-center text-slate-400">
                    لم يتم العثور على موردين مسجلين مطابقين للبحث.
                  </td>
                </tr>
              ) : (
                filteredSuppliers.map((sup) => {
                  const supPurchases = getSupplierPurchases(sup.id);
                  return (
                    <tr key={sup.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                      <td className="p-4 font-bold text-slate-800 dark:text-slate-200">
                        {sup.name}
                      </td>
                      <td className="p-4 font-mono text-slate-600 dark:text-slate-400">
                        {sup.phone || "—"}
                      </td>
                      <td className="p-4 text-slate-500 dark:text-slate-400">
                        {sup.address}
                      </td>
                      <td className="p-4">
                        {sup.balance > 0 ? (
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-amber-600 bg-amber-50 dark:bg-amber-950/30 px-2 py-0.5 rounded-md font-mono">
                              {sup.balance.toLocaleString("ar-IQ")} {currency}
                            </span>
                            <button
                              onClick={() => setSettlingSupplier(sup)}
                              className="px-2 py-0.5 rounded-md border border-amber-300 text-amber-700 font-semibold hover:bg-amber-600 hover:text-white transition-colors cursor-pointer text-[10px]"
                            >
                              تسديد دفعة
                            </button>
                          </div>
                        ) : (
                          <span className="text-emerald-600 font-bold bg-emerald-50 dark:bg-emerald-950/30 px-2 py-0.5 rounded-md">
                            مسدد بالكامل
                          </span>
                        )}
                      </td>
                      <td className="p-4 font-mono font-semibold text-slate-600">
                        {supPurchases.length} فواتير توريد
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setViewHistorySup(sup)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-850 text-slate-600 dark:text-slate-450 cursor-pointer flex items-center gap-1"
                            title="سجل التوريدات"
                          >
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>فواتير</span>
                          </button>
                          <button
                            onClick={() => openEditModal(sup)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-850 text-slate-600 dark:text-slate-450 cursor-pointer"
                            title="تعديل"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setShowDeleteModal(sup)}
                            className="p-1.5 rounded-lg border border-rose-100 hover:bg-rose-50 text-rose-600 cursor-pointer"
                            title="حذف"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* --- ADD / EDIT SUPPLIER FORM MODAL --- */}
      <AnimatePresence>
        {showFormModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-md shadow-2xl"
            >
              <div className="flex items-center justify-between border-b pb-3 mb-4">
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm">
                  {editingSupplier ? "تعديل بيانات المورد" : "تسجيل مورد/مذخر جديد"}
                </h3>
                <button onClick={() => setShowFormModal(false)} className="p-1 rounded-lg hover:bg-slate-100 text-slate-500">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4 font-sans text-xs">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">اسم المورد/المذخر العلمي:</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: مكتب بابل العلمي للأدوية..."
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">رقم الهاتف وتواصل المبيعات:</label>
                  <input
                    type="text"
                    placeholder="مثال: 07802345678..."
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">العنوان / المقر الرئيسي:</label>
                  <input
                    type="text"
                    placeholder="مثال: بغداد - الحارثية - قرب نفق الزيتون..."
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الرصيد المطالب به حالياً للمورد:</label>
                  <input
                    type="number"
                    value={balance === 0 ? "" : balance}
                    onChange={(e) => setBalance(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none font-mono text-left"
                  />
                </div>

                <div className="flex items-center gap-3 pt-2 justify-end">
                  <button
                    type="button"
                    onClick={() => setShowFormModal(false)}
                    className="px-4 py-2.5 rounded-xl border text-slate-500 font-bold cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-500 cursor-pointer"
                  >
                    حفظ المورد
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- SUPPLIER SETTLEMENT FORM MODAL --- */}
      <AnimatePresence>
        {settlingSupplier && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-sm shadow-2xl"
            >
              <div className="flex items-center justify-between border-b pb-3 mb-4">
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm">تسجيل سداد دفعة للمذخر</h3>
                <button onClick={() => setSettlingSupplier(null)} className="p-1 rounded-lg hover:bg-slate-100 text-slate-500">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handlePaymentToSupplier} className="space-y-4">
                <p className="text-xs text-slate-500">
                  المورد: <b className="text-slate-800 dark:text-slate-100">{settlingSupplier.name}</b>
                </p>
                <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-lg text-xs">
                  الرصيد الدائن المطلوب: <b className="text-amber-600 font-mono text-sm">{settlingSupplier.balance.toLocaleString("ar-IQ")} د.ع</b>
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1 text-xs font-sans">المبلغ المدفوع كدفعة (بالدينار):</label>
                  <input
                    type="number"
                    required
                    placeholder="اكتب المبلغ المدفوع للمندوب..."
                    value={settleAmount === 0 ? "" : settleAmount}
                    onChange={(e) => setSettleAmount(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none font-mono text-left"
                  />
                </div>

                <div className="flex items-center gap-3 pt-2 justify-end text-xs font-semibold">
                  <button
                    type="button"
                    onClick={() => {
                      setSettlingSupplier(null);
                      setSettleAmount(0);
                    }}
                    className="px-4 py-2 rounded-xl border text-slate-500 cursor-pointer"
                  >
                    إلغاء الأمر
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-emerald-600 text-white cursor-pointer"
                  >
                    تأكيد تسديد المبلغ
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- SUPPLIER INBOUND INVOICES LOG OVERLAY --- */}
      <AnimatePresence>
        {viewHistorySup && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-lg shadow-2xl my-8 max-h-[85vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b pb-3 mb-4">
                <h3 className="font-bold text-slate-800 dark:text-slate-150 text-sm">أرشيف فواتير توريد المذخر: {viewHistorySup.name}</h3>
                <button onClick={() => setViewHistorySup(null)} className="p-1 rounded-lg hover:bg-slate-100 text-slate-500">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {getSupplierPurchases(viewHistorySup.id).length === 0 ? (
                <div className="py-8 text-center text-slate-400">
                  لا توجد فواتير شراء مستوردة من هذا المورد في أرشيف الصيدلية.
                </div>
              ) : (
                <div className="space-y-3">
                  {getSupplierPurchases(viewHistorySup.id).map((inv) => (
                    <div key={inv.id} className="p-3 border rounded-xl bg-slate-50 dark:bg-slate-800/40 text-xs font-sans space-y-2">
                      <div className="flex justify-between font-bold">
                        <span className="font-mono text-slate-800 dark:text-slate-250">{inv.invoiceNumber}</span>
                        <span className="text-slate-400">{new Date(inv.date).toLocaleDateString("ar-IQ")}</span>
                      </div>
                      
                      {/* Items */}
                      <div className="text-[10px] space-y-1 text-slate-500">
                        {inv.items.map((it, i) => (
                          <div key={i} className="flex justify-between">
                            <span>{it.commercialName} × {it.quantity} علبة</span>
                            <span className="font-mono font-bold">{it.total.toLocaleString("ar-IQ")} د.ع</span>
                          </div>
                        ))}
                      </div>

                      <div className="flex justify-between border-t border-dashed border-slate-200 dark:border-slate-700 pt-2 font-bold text-slate-800 dark:text-slate-250">
                        <span>إجمالي قيمة الفاتورة الموردة:</span>
                        <span className="text-emerald-600 font-mono">{inv.total.toLocaleString("ar-IQ")} د.ع</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <button
                onClick={() => setViewHistorySup(null)}
                className="w-full mt-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold cursor-pointer text-xs"
              >
                إغلاق النافذة
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- DELETE CONFIRM MODAL --- */}
      <AnimatePresence>
        {showDeleteModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-sm shadow-2xl text-center font-sans"
            >
              <div className="w-12 h-12 rounded-full bg-rose-50 dark:bg-rose-950 flex items-center justify-center mx-auto text-rose-600 mb-4 animate-pulse">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm mb-2">تأكيد حذف المورد</h3>
              <p className="text-slate-500 dark:text-slate-400 text-xs mb-6">
                هل أنت متأكد من حذف المورد <span className="font-bold text-slate-800 dark:text-slate-100">"{showDeleteModal.name}"</span>؟ سيتم تصفير حساباته وحذف مذكراته نهائياً.
              </p>
              
              <div className="flex items-center gap-3 justify-center text-xs">
                <button
                  onClick={() => setShowDeleteModal(null)}
                  className="px-4 py-2 rounded-xl border text-slate-500 cursor-pointer hover:bg-slate-50"
                >
                  إلغاء الأمر
                </button>
                <button
                  onClick={handleDelete}
                  className="px-4 py-2 rounded-xl bg-rose-600 text-white cursor-pointer hover:bg-rose-500"
                >
                  نعم، احذف المورد
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-6 right-6 z-50 px-5 py-3.5 rounded-2xl shadow-xl flex items-center gap-2.5 border text-xs max-w-sm ${
              toast.type === "success"
                ? "bg-emerald-50 border-emerald-100 dark:bg-emerald-950/90 dark:border-emerald-900 text-emerald-800 dark:text-emerald-355"
                : "bg-rose-50 border-rose-100 dark:bg-rose-950/90 dark:border-rose-900 text-rose-800 dark:text-rose-355"
            }`}
          >
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500" />
            <span className="font-semibold leading-relaxed">{toast.text}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
