/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { FirebaseService } from "../firebase";
import { KeyRound, User, Lock, Activity, AlertCircle, Key, CheckCircle, ShieldAlert, Wifi, WifiOff } from "lucide-react";
import { motion } from "motion/react";

interface LoginViewProps {
  onLoginSuccess: (user: any) => void;
}

export default function LoginView({ onLoginSuccess }: LoginViewProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [showActivation, setShowActivation] = useState(false);

  // Activation/License Code fields
  const [activationCode, setActivationCode] = useState("");
  const [activationUser, setActivationUser] = useState<any>(null);
  const [activationSuccess, setActivationSuccess] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setErrorMsg("الرجاء ملء جميع الحقول المطلوبة.");
      return;
    }

    setLoading(true);
    setErrorMsg("");
    setActivationUser(null);

    try {
      const res = await FirebaseService.login(username, password);
      if (res.success && res.user) {
        // Successful login
        // Save to localStorage
        const user = res.user;
        localStorage.setItem("pharmapro_uid", user.uid);
        localStorage.setItem("pharmapro_username", user.username);
        localStorage.setItem("pharmapro_role", user.role);
        localStorage.setItem("pharmapro_pharmacyName", user.pharmacyName || "");
        localStorage.setItem("pharmapro_expireDate", user.expireDate || "");
        localStorage.setItem("pharmapro_ownerName", user.ownerName || "");
        
        onLoginSuccess(user);
      } else {
        if (res.error === "DISABLED") {
          setErrorMsg("تم تعطيل هذا الحساب، يرجى التواصل مع الإدارة.");
        } else if (res.error === "EXPIRED") {
          setErrorMsg("انتهت صلاحية الاشتراك، يرجى التواصل مع الإدارة.");
          // Save the expired user so they can optionally self-activate
          // We can fetch the user details to let them activate using an active license code
          const allUsers = await FirebaseService.getAllUsers();
          const matched = allUsers.find(u => u.username.toLowerCase() === username.trim().toLowerCase());
          if (matched) {
            setActivationUser(matched);
            setShowActivation(true);
          }
        } else {
          setErrorMsg(res.error || "اسم المستخدم أو كلمة المرور غير صحيحة!");
        }
      }
    } catch (err: any) {
      setErrorMsg("حدث خطأ في النظام. يرجى مراجعة الاتصال بالإنترنت.");
    } finally {
      setLoading(false);
    }
  };

  const handleRedeemCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activationCode.trim() || !activationUser) {
      setErrorMsg("الرجاء إدخال كود تفعيل صالح.");
      return;
    }

    setLoading(true);
    setErrorMsg("");
    setActivationSuccess("");

    try {
      const res = await FirebaseService.redeemCode(
        activationCode.trim(),
        activationUser.username,
        activationUser.uid
      );

      if (res.success) {
        setActivationSuccess(`تم تفعيل الاشتراك بنجاح لمدة ${res.durationMsg}! تاريخ الانتهاء الجديد: ${res.newExpireDate}`);
        setActivationCode("");
        setErrorMsg("");
        
        // Auto-login after brief delay
        setTimeout(() => {
          // Log user in automatically
          const updatedUser = { ...activationUser, expireDate: res.newExpireDate, active: true };
          localStorage.setItem("pharmapro_uid", updatedUser.uid);
          localStorage.setItem("pharmapro_username", updatedUser.username);
          localStorage.setItem("pharmapro_role", updatedUser.role);
          localStorage.setItem("pharmapro_pharmacyName", updatedUser.pharmacyName || "");
          localStorage.setItem("pharmapro_expireDate", updatedUser.expireDate || "");
          localStorage.setItem("pharmapro_ownerName", updatedUser.ownerName || "");
          onLoginSuccess(updatedUser);
        }, 3000);
      } else {
        setErrorMsg(res.error || "فشل تفعيل الكود. تأكد من صحة الرمز.");
      }
    } catch (err: any) {
      setErrorMsg("خطأ أثناء الاتصال بالخادم.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 md:p-8 relative overflow-hidden" dir="rtl">
      {/* Absolute Decorative Background Elements */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md bg-slate-850 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl relative z-10 space-y-6">
        
        {/* Connection Mode Indicator */}
        <div className="flex justify-between items-center text-xs">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 font-mono">
            <span>صيدلي برو v1.2.0</span>
          </div>
          {navigator.onLine ? (
            <div className="flex items-center gap-1 text-emerald-400">
              <Wifi className="w-3.5 h-3.5" />
              <span>متصل بالشبكة</span>
            </div>
          ) : (
            <div className="flex items-center gap-1 text-amber-400">
              <WifiOff className="w-3.5 h-3.5" />
              <span>أوفلاين (وضع محلي)</span>
            </div>
          )}
        </div>

        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-emerald-500 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
            <Activity className="w-8 h-8 animate-pulse" />
          </div>
          <h1 className="text-xl font-extrabold text-white tracking-tight">نظام صيدلي برو لإدارة الصيدليات</h1>
          <p className="text-xs text-slate-400">بوابة تسجيل الدخول وإدارة التراخيص</p>
        </div>

        {/* Display normal Login or License Activation Form */}
        {!showActivation ? (
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">اسم المستخدم</label>
              <div className="relative">
                <span className="absolute inset-y-0 right-0 flex items-center pr-3.5 pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="مثال: ali"
                  className="w-full pr-11 pl-4 py-3 bg-slate-900 border border-slate-750 text-white rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-sm transition-all placeholder:text-slate-550"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-300">كلمة المرور</label>
              <div className="relative">
                <span className="absolute inset-y-0 right-0 flex items-center pr-3.5 pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </span>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pr-11 pl-4 py-3 bg-slate-900 border border-slate-750 text-white rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-sm transition-all placeholder:text-slate-550"
                />
              </div>
            </div>

            {errorMsg && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/25 rounded-xl flex items-start gap-2.5 text-xs text-rose-400 animate-bounce">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span className="leading-relaxed">{errorMsg}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-md cursor-pointer transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/35 border-t-white rounded-full animate-spin"></div>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  <span>تسجيل الدخول</span>
                </>
              )}
            </button>
          </form>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-4"
          >
            {/* Self-serve license code activation */}
            <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl space-y-1.5">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>عذراً، انتهت صلاحية اشتراكك!</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                حسابك <strong>({activationUser?.username})</strong> منتهى الصلاحية. يمكنك لصق كود التفعيل الجديد الذي حصلت عليه من الإدارة فوراً لتفعيل الحساب دون انتظار الدعم.
              </p>
            </div>

            <form onSubmit={handleRedeemCode} className="space-y-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-300">أدخل كود التفعيل (License Code)</label>
                <div className="relative">
                  <span className="absolute inset-y-0 right-0 flex items-center pr-3.5 pointer-events-none text-slate-400">
                    <Key className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    required
                    value={activationCode}
                    onChange={(e) => setActivationCode(e.target.value.toUpperCase())}
                    placeholder="مثال: ABCD-1234-EFGH"
                    className="w-full pr-11 pl-4 py-3 bg-slate-900 border border-slate-750 text-white font-mono text-center rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none text-sm transition-all placeholder:text-slate-550 placeholder:font-sans"
                  />
                </div>
              </div>

              {errorMsg && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/25 rounded-xl flex items-start gap-2.5 text-xs text-rose-400">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{errorMsg}</span>
                </div>
              )}

              {activationSuccess && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/25 rounded-xl flex items-start gap-2.5 text-xs text-emerald-400">
                  <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{activationSuccess}</span>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  disabled={loading || !activationCode.trim()}
                  className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-md transition-colors cursor-pointer disabled:opacity-50"
                >
                  {loading ? "جاري التفعيل..." : "تفعيل الاشتراك"}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowActivation(false);
                    setErrorMsg("");
                    setActivationSuccess("");
                  }}
                  className="px-4 py-3 bg-slate-800 hover:bg-slate-750 text-slate-300 font-semibold rounded-xl transition-colors cursor-pointer"
                >
                  رجوع
                </button>
              </div>
            </form>
          </motion.div>
        )}

        <div className="text-center text-[10px] text-slate-500 font-sans border-t border-slate-800 pt-4 leading-relaxed">
          جميع البيانات المحلية والسرية مشفرة بالكامل على جهازك. <br />
          يتطلب الاتصال بالإنترنت فقط عند التحقق من حالة الترخيص.
        </div>

      </div>
    </div>
  );
}
