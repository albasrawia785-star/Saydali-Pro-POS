/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Database,
  Download,
  Upload,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  Flame,
  FileCode,
  Sparkles,
  Copy,
  Check,
  X
} from "lucide-react";
import { IndexedDBService } from "../db/indexedDB";
import { Product } from "../types";

export default function BackupView() {
  const [loading, setLoading] = useState(false);
  const [progressMsg, setProgressMsg] = useState("");
  
  // Text backup states
  const [generatedCode, setGeneratedCode] = useState<string>("");
  const [pasteCode, setPasteCode] = useState<string>("");
  const [copied, setCopied] = useState(false);
  const [showImportArea, setShowImportArea] = useState(false);

  // Toast
  const [toast, setToast] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const showToast = (text: string, type: "success" | "error" = "success") => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3500);
  };

  // 1. Export entire DB to secure Base64 JSON text
  const handleExportBackupText = async () => {
    setLoading(true);
    setProgressMsg("جاري تجميع وحزم الجداول المحلية...");
    try {
      const backupData = {
        categories: await IndexedDBService.getAll("categories"),
        products: await IndexedDBService.getAll("products"),
        sales: await IndexedDBService.getAll("sales"),
        purchases: await IndexedDBService.getAll("purchases"),
        customers: await IndexedDBService.getAll("customers"),
        suppliers: await IndexedDBService.getAll("suppliers"),
        settings: await IndexedDBService.getAll("settings"),
        exportVersion: "1.0",
        exportDate: new Date().toISOString()
      };

      const dataStr = JSON.stringify(backupData);
      
      // Multi-byte safe Base64 encoding
      const base64Code = btoa(unescape(encodeURIComponent(dataStr)));
      
      setGeneratedCode(base64Code);
      showToast("تم توليد رمز النسخة الاحتياطية بنجاح! يمكنك نسخه الآن.");
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ أثناء حزم وتصدير البيانات", "error");
    } finally {
      setLoading(false);
      setProgressMsg("");
    }
  };

  // Copy code utility
  const handleCopyCode = () => {
    if (!generatedCode) return;
    navigator.clipboard.writeText(generatedCode).then(() => {
      setCopied(true);
      showToast("تم نسخ رمز الاحتياطي بنجاح إلى الحافظة!");
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {
      // Fallback for WebViews without navigator.clipboard support
      const textarea = document.createElement("textarea");
      textarea.value = generatedCode;
      textarea.style.position = "fixed"; // Avoid scrolling to bottom
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      try {
        document.execCommand("copy");
        setCopied(true);
        showToast("تم نسخ رمز الاحتياطي بنجاح إلى الحافظة!");
        setTimeout(() => setCopied(false), 2000);
      } catch (err) {
        showToast("فشل النسخ التلقائي، يرجى تحديد النص ونسخه يدوياً", "error");
      }
      document.body.removeChild(textarea);
    });
  };

  // 2. Import Base64 JSON and restore DB
  const handleImportBackupText = async () => {
    if (!pasteCode.trim()) {
      showToast("الرجاء لصق رمز النسخة الاحتياطية أولاً!", "error");
      return;
    }

    setLoading(true);
    setProgressMsg("جاري فك تشفير وتحليل كود الاستعادة...");

    try {
      // Multi-byte safe Base64 decoding
      const decodedJson = decodeURIComponent(escape(atob(pasteCode.trim())));
      const parsedData = JSON.parse(decodedJson);
      
      // Basic validation
      if (!parsedData.products || !parsedData.categories) {
        throw new Error("رمز النسخة الاحتياطية غير متوافق أو تالف!");
      }

      setProgressMsg("جاري تصفير البيانات القديمة واستيراد الجداول الجديدة...");

      // Bulk seed
      await IndexedDBService.bulkRestore(parsedData);

      showToast("تهانينا! تم استعادة قواعد البيانات ومزامنتها بنجاح كامل.");
      // Reload page after a brief delay
      setTimeout(() => window.location.reload(), 1500);
    } catch (err: any) {
      console.error(err);
      showToast("الكود المدخل غير صالح أو غير مكتمل. يرجى التأكد من نسخه بالكامل.", "error");
    } finally {
      setLoading(false);
      setProgressMsg("");
    }
  };

  // 3. Generate 10k Products for performance stress test
  const handleGenerateStressTestData = async () => {
    setLoading(true);
    setProgressMsg("جاري تهيئة مولد البيانات الضخمة (10,000 دواء)...");
    try {
      // Fetch existing categories to assign
      const cats = await IndexedDBService.getAll<{ id: string }>("categories");
      if (cats.length === 0) {
        showToast("الرجاء إضافة تصنيف واحد على الأقل أولاً لتوليد المنتجات", "error");
        setLoading(false);
        return;
      }

      setProgressMsg("جاري توليد وحقن 10,000 صنف دواء في IndexedDB بصورة متوازية...");

      // We will generate products in batches
      const mockMedicinesCommercial = [
        "Panadol", "Amoxicillin", "Lipitor", "Metformin", "Ibuprofen", "Zantac", "Voltaren", "Aspirin", "Plavix", "Augmentin",
        "Nexium", "Singulair", "Crestor", "Sinthrome", "Lasix", "Zocor", "Ventolin", "Brufen", "Ponstan", "Spasmo-Canulase",
        "Olfen", "Gaviscon", "Procto-Glyvenol", "Dulcolax", "Histadin", "Clarinase", "Fludrex", "Solpadeine", "Zinnat"
      ];

      const mockMedicinesScientific = [
        "Paracetamol", "Amoxicillin Trihydrate", "Atorvastatin Calcium", "Metformin Hydrochloride", "Ibuprofen BP", "Ranitidine", "Diclofenac Sodium", "Acetylsalicylic Acid", "Clopidogrel Bisulfate", "Co-amoxiclav",
        "Esomeprazole", "Montelukast Sodium", "Rosuvastatin Calcium", "Acenocoumarol", "Furosemide", "Simvastatin", "Salbutamol Sulfate", "Mefenamic Acid", "Spasmolytic complex",
        "Loratadine", "Pseudoephedrine Sulfate", "Paracetamol + Caffeine"
      ];

      const shelfLocations = ["A-1", "A-2", "B-1", "B-3", "C-2", "C-4", "D-1", "D-5", "E-2", "الثلاجة - 1", "الثلاجة - 2", "الرف العلوي"];
      const manufacturers = ["SDI (العراق)", "Pioneer (السليمانية)", "Awamedica (أربيل)", "Pfizer (أمريكا)", "Novartis (سويسرا)", "GlaxoSmithKline (بريطانيا)", "Sanofi (فرنسا)", "Hikma (الأردن)", "Dar Al Dawa (الأردن)", "Julphar (الإمارات)"];

      const bulkProducts: Product[] = [];
      const batchSize = 10000;

      for (let i = 1; i <= batchSize; i++) {
        const commRand = mockMedicinesCommercial[Math.floor(Math.random() * mockMedicinesCommercial.length)];
        const sciRand = mockMedicinesScientific[Math.floor(Math.random() * mockMedicinesScientific.length)];
        const catRand = cats[Math.floor(Math.random() * cats.length)];
        const mfgRand = manufacturers[Math.floor(Math.random() * manufacturers.length)];
        const shelfRand = shelfLocations[Math.floor(Math.random() * shelfLocations.length)];

        // Random prices
        const buyPrice = Math.floor(500 + Math.random() * 8000);
        const sellPrice = buyPrice + Math.floor(250 + Math.random() * 4000);
        const wholesalePrice = buyPrice + Math.floor(100 + Math.random() * 1000);

        // Expiration dates
        const expDate = new Date();
        expDate.setMonth(expDate.getMonth() + Math.floor(-12 + Math.random() * 36)); // expired to near exp to healthy
        const expStr = expDate.toISOString().split("T")[0];

        bulkProducts.push({
          id: `stress-prod-${i}-${Date.now()}`,
          commercialName: `${commRand} ${i}`,
          scientificName: sciRand,
          categoryId: catRand.id,
          buyPrice,
          sellPrice,
          wholesalePrice,
          quantity: Math.floor(Math.random() * 150),
          minStock: Math.floor(5 + Math.random() * 15),
          expirationDate: expStr,
          productionDate: "2025-01-01",
          batchNumber: `B-${Math.floor(100000 + Math.random() * 900000)}`,
          location: shelfRand,
          manufacturer: mfgRand
        });
      }

      // Add to DB in bulk
      await IndexedDBService.bulkAddProducts(bulkProducts);

      showToast(`تم نجاح توليد وحقن ${batchSize.toLocaleString("ar-IQ")} دواء! جاري إعادة تهيئة الدليل.`);
      setTimeout(() => window.location.reload(), 1500);
    } catch (err) {
      console.error(err);
      showToast("فشلت عملية توليد بيانات الفحص", "error");
    } finally {
      setLoading(false);
      setProgressMsg("");
    }
  };

  return (
    <div className="space-y-6 font-sans text-xs">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 font-sans">الأمان والنسخ الاحتياطي للأدلة</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 font-sans">تصدير أرشيف كامل للمبيعات والمنتجات، واستعادة الأنظمة محلياً بالكامل بدون شبكة.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Core Backup controls */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-5">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-2">
            <Database className="w-5 h-5 text-emerald-500" />
            <h2 className="font-bold text-slate-850 dark:text-slate-150 text-xs">أدوات النسخ الاحتياطي بالرمز المشفر</h2>
          </div>

          <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-xs">
            تخطي قيود حماية المتصفحات وهواتف الـ APK! تعتمد هذه الطريقة على توليد رمز نصي مشفر (JSON String) يحتوي على كامل بياناتك (المنتجات، المبيعات، الإعدادات). يمكنك نسخه وحفظه واستعادته في أي وقت بلمح البصر.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            {/* Generate Code Button */}
            <button
              onClick={handleExportBackupText}
              disabled={loading}
              className="flex items-center justify-center gap-2 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-md cursor-pointer disabled:opacity-50 transition-colors"
              id="btn-generate-backup"
            >
              <Download className="w-4 h-4" />
              <span>توليد كود الاحتياطي</span>
            </button>

            {/* Toggle Import Box Button */}
            <button
              onClick={() => {
                setShowImportArea(!showImportArea);
                setGeneratedCode(""); // clear export view to avoid confusion
              }}
              disabled={loading}
              className="flex items-center justify-center gap-2 py-3 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl cursor-pointer transition-colors"
              id="btn-toggle-import"
            >
              <Upload className="w-4 h-4 text-emerald-500" />
              <span>{showImportArea ? "إغلاق نافذة الاستيراد" : "استيراد من كود نصي"}</span>
            </button>
          </div>

          {/* Export Display Area */}
          {generatedCode && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-700 dark:text-slate-300">رمز النسخة الاحتياطية الجاهز:</span>
                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold shadow-sm transition-colors cursor-pointer"
                  id="btn-copy-backup-code"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? "تم النسخ!" : "نسخ الكود"}</span>
                </button>
              </div>
              <textarea
                readOnly
                value={generatedCode}
                onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                className="w-full h-32 p-3 font-mono text-[10px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-lg focus:outline-none resize-none break-all text-slate-600 dark:text-slate-400"
              />
              <p className="text-[10px] text-amber-600 dark:text-amber-400 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>انسخ الرمز بالكامل واحفظه في ملف نصي أو عبر الواتساب/السحابة للرجوع إليه لاحقاً.</span>
              </p>
            </motion.div>
          )}

          {/* Import Text Input Area */}
          {showImportArea && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 p-4 bg-slate-50 dark:bg-slate-950 rounded-xl border border-amber-200 dark:border-amber-900/50 space-y-3"
            >
              <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span className="font-bold">استعادة قواعد البيانات بالكامل</span>
              </div>
              
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                قم بلصق كود الاحتياطي المشفر الطويل الذي قمت بتوليده سابقاً في الحقل أدناه لاسترجاع كافة الأدوية، المبيعات، والعملاء.
              </p>

              <textarea
                value={pasteCode}
                onChange={(e) => setPasteCode(e.target.value)}
                placeholder="إلصق الكود المشفر هنا..."
                className="w-full h-32 p-3 font-mono text-[10px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none text-slate-800 dark:text-slate-200"
              />

              <div className="flex gap-2">
                <button
                  onClick={handleImportBackupText}
                  disabled={loading || !pasteCode.trim()}
                  className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg shadow-sm disabled:opacity-50 transition-colors cursor-pointer"
                  id="btn-confirm-import"
                >
                  تأكيد واستعادة البيانات الآن
                </button>
                <button
                  onClick={() => {
                    setShowImportArea(false);
                    setPasteCode("");
                  }}
                  className="px-4 py-2.5 bg-slate-200 hover:bg-slate-300 dark:bg-slate-850 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-355 font-semibold rounded-lg transition-colors cursor-pointer"
                  id="btn-cancel-import"
                >
                  إلغاء
                </button>
              </div>

              <p className="text-[9px] text-rose-500 font-semibold leading-relaxed">
                * تحذير: استعادة البيانات ستمسح كافة السجلات الحالية نهائياً وتستبدلها ببيانات النسخة الاحتياطية المرفقة!
              </p>
            </motion.div>
          )}
        </div>

        {/* Performance Stress test engine */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-5">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-2">
            <Flame className="w-5 h-5 text-amber-500" />
            <h2 className="font-bold text-slate-850 dark:text-slate-150 text-xs">جهاز فحص ضغط البيانات (Stress Test)</h2>
          </div>

          <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-xs">
            تريد التأكد من متانة صيدلي برو وسرعته مع أكثر من 10,000+ صنف أدوية على جهازك؟ اضغط لتوليد بيانات عشوائية ضخمة من الأدوية بلمح البصر، وشاهد كفاءة محرك البحث اللحظي وفهرسة IndexedDB السريعة.
          </p>

          <button
            onClick={handleGenerateStressTestData}
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-3.5 bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white font-bold rounded-xl shadow-md cursor-pointer disabled:opacity-50 transition-colors"
          >
            <Sparkles className="w-4 h-4" />
            <span>توليد وحقن 10,000 دواء فوراً</span>
          </button>
        </div>
      </div>

      {/* Loading overlay for Backup */}
      <AnimatePresence>
        {loading && (
          <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-900/80 backdrop-blur-xs p-4 text-center">
            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border max-w-sm space-y-4">
              <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-xs font-bold text-slate-800 dark:text-slate-100">{progressMsg || "جاري المعالجة..."}</p>
              <p className="text-[10px] text-slate-400 leading-relaxed">الرجاء عدم إغلاق المتصفح أو التحديث ريثما تنتهي عمليات كتابة وحقن الذاكرة.</p>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-6 right-6 z-50 px-5 py-3.5 rounded-2xl shadow-xl flex items-center gap-2.5 border text-xs max-w-sm ${
              toast.type === "success"
                ? "bg-emerald-50 border-emerald-100 dark:bg-emerald-950/90 dark:border-emerald-900 text-emerald-800 dark:text-emerald-355"
                : "bg-rose-50 border-rose-100 dark:bg-rose-950/90 dark:border-rose-900 text-rose-800 dark:text-rose-355"
            }`}
          >
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500" />
            <span className="font-semibold leading-relaxed">{toast.text}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
