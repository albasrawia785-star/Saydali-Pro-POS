/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { motion } from "motion/react";
import { Activity, ShieldCheck } from "lucide-react";

interface SplashScreenProps {
  onComplete?: () => void;
  pharmacyName?: string;
}

export default function SplashScreen({ onComplete, pharmacyName }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState("جاري تشغيل النظام...");

  useEffect(() => {
    const timer1 = setTimeout(() => {
      setProgress(30);
      setStatusText("جاري تهيئة قاعدة البيانات المحلية (IndexedDB)...");
    }, 400);

    const timer2 = setTimeout(() => {
      setProgress(65);
      setStatusText("جاري فحص صلاحية الأدوية والمخزون...");
    }, 1000);

    const timer3 = setTimeout(() => {
      setProgress(90);
      setStatusText("تحميل واجهة صيدلي برو الذكية...");
    }, 1500);

    const timer4 = setTimeout(() => {
      setProgress(100);
      setStatusText("جاهز!");
      if (onComplete) {
        setTimeout(onComplete, 300);
      }
    }, 2000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-900 text-white select-none">
      <div className="text-center max-w-sm px-6">
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="relative flex items-center justify-center mx-auto w-24 h-24 bg-emerald-600 rounded-3xl shadow-xl shadow-emerald-900/30 mb-6"
        >
          {/* Pharmacy Cross Icon */}
          <Activity className="w-12 h-12 text-white" />
          <motion.div
            className="absolute -inset-1 rounded-3xl border-2 border-emerald-400 opacity-30"
            animate={{ scale: [1, 1.15, 1], opacity: [0.3, 0.6, 0.3] }}
            transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
          />
        </motion.div>

        <motion.h1
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="text-3xl font-bold tracking-tight mb-2 text-emerald-400"
        >
          صيدلي برو
        </motion.h1>

        <motion.p
          initial={{ y: 15, opacity: 0 }}
          animate={{ y: 0, opacity: 0.7 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="text-sm text-slate-300 font-medium mb-8"
        >
          نظام مبيعات وإدارة الصيدليات العراقي الذكي
        </motion.p>

        {/* Progress Bar Container */}
        <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden mb-4">
          <motion.div
            className="bg-emerald-500 h-full rounded-full"
            initial={{ width: "0%" }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          />
        </div>

        {/* Status Text */}
        <motion.p
          key={statusText}
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-xs text-slate-400 font-mono text-center min-h-[16px]"
        >
          {statusText}
        </motion.p>
      </div>

      <div className="absolute bottom-8 flex items-center gap-2 text-xs text-slate-500">
        <ShieldCheck className="w-4 h-4 text-emerald-600" />
        <span>قاعدة بيانات مشفرة ومحلية بالكامل 100% أوفلاين</span>
      </div>
    </div>
  );
}
