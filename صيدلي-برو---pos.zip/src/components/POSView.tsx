/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Search,
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  CheckCircle,
  AlertCircle,
  User,
  Tags,
  BadgeAlert,
  X
} from "lucide-react";
import { IndexedDBService } from "../db/indexedDB";
import { Product, Category, Customer, SaleInvoice, SaleInvoiceItem } from "../types";
import { Html5Qrcode, Html5QrcodeSupportedFormats } from "html5-qrcode";

interface POSViewProps {
  currency: string;
  onNavigate: (view: string) => void;
}

export default function POSView({ currency, onNavigate }: POSViewProps) {
  // DB States
  const [categories, setCategories] = useState<Category[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  
  // Search / Filters
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [productsList, setProductsList] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(false);

  // Cart
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  const [discount, setDiscount] = useState<number>(0); // in IQD
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>("");
  const [paymentType, setPaymentType] = useState<"cash" | "debt">("cash");
  const [invoiceNotes, setInvoiceNotes] = useState("");

  // UI state
  const [message, setMessage] = useState<{ text: string; type: "success" | "error" } | null>(null);
  const [showAddCustomerModal, setShowAddCustomerModal] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState("");
  const [newCustomerPhone, setNewCustomerPhone] = useState("");
  const [showPOSScanner, setShowPOSScanner] = useState(false);

  // Load Categories & Customers on mount
  useEffect(() => {
    async function loadInitialPOSData() {
      try {
        const cats = await IndexedDBService.getAll<Category>("categories");
        const custs = await IndexedDBService.getAll<Customer>("customers");
        setCategories(cats);
        setCustomers(custs);
      } catch (err) {
        console.error("Error loading POS initial data:", err);
      }
    }
    loadInitialPOSData();
  }, []);

  // Search products when query or category changes
  useEffect(() => {
    let active = true;
    async function fetchProducts() {
      setLoadingProducts(true);
      try {
        const result = await IndexedDBService.searchProducts(
          searchTerm,
          selectedCategory || undefined,
          undefined,
          false,
          40, // limit to 40 for perfect responsiveness
          0
        );
        if (active) {
          setProductsList(result.items);
        }
      } catch (err) {
        console.error("Error fetching POS products:", err);
      } finally {
        if (active) setLoadingProducts(false);
      }
    }

    const timer = setTimeout(fetchProducts, 150); // debounce slightly for performance
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [searchTerm, selectedCategory]);

  const showMessage = (text: string, type: "success" | "error") => {
    setMessage({ text, type });
    setTimeout(() => setMessage(null), 3000);
  };

  // Triggered when a barcode is scanned in POS view
  const handleBarcodeScanned = async (scannedBarcode: string) => {
    try {
      const allProds = await IndexedDBService.getAll<Product>("products");
      const matchedProd = allProds.find((p) => (p.barcode || "").trim() === scannedBarcode.trim());

      if (!matchedProd) {
        showMessage(`عذراً، لم يتم العثور على أي دواء بالباركود: ${scannedBarcode}`, "error");
        return;
      }

      // Found the product! Let's check stock
      if (matchedProd.quantity <= 0) {
        showMessage(`عذراً، الدواء (${matchedProd.commercialName}) نفذ من المخزن!`, "error");
        return;
      }

      let addedSuccessfully = false;

      setCart((prevCart) => {
        const existingIndex = prevCart.findIndex((item) => item.product.id === matchedProd.id);
        if (existingIndex > -1) {
          const currentQtyInCart = prevCart[existingIndex].quantity;
          if (currentQtyInCart >= matchedProd.quantity) {
            addedSuccessfully = false;
            return prevCart;
          }
          const newCart = [...prevCart];
          newCart[existingIndex].quantity += 1;
          addedSuccessfully = true;
          return newCart;
        } else {
          addedSuccessfully = true;
          return [...prevCart, { product: matchedProd, quantity: 1 }];
        }
      });

      // Beep sound!
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.type = "sine";
        osc.frequency.setValueAtTime(1000, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.15);
      } catch (e) {}

      showMessage(`تمت إضافة ${matchedProd.commercialName} إلى السلة بنجاح!`, "success");
      setShowPOSScanner(false);
    } catch (err) {
      console.error("Error matching scanned barcode:", err);
      showMessage("فشل البحث عن الدواء بواسطة الباركود", "error");
    }
  };

  // Barcode Camera Scanner logic for POS checkout
  useEffect(() => {
    let html5QrCode: Html5Qrcode | null = null;

    if (showPOSScanner) {
      const timer = setTimeout(() => {
        try {
          html5QrCode = new Html5Qrcode("pos-scanner-viewport", {
            formatsToSupport: [
              Html5QrcodeSupportedFormats.EAN_13,
              Html5QrcodeSupportedFormats.EAN_8,
              Html5QrcodeSupportedFormats.CODE_128,
              Html5QrcodeSupportedFormats.UPC_A,
              Html5QrcodeSupportedFormats.UPC_E,
              Html5QrcodeSupportedFormats.CODE_39,
              Html5QrcodeSupportedFormats.QR_CODE
            ],
            verbose: false,
            experimentalFeatures: {
              useBarCodeDetectorIfSupported: true // Native hardware acceleration on mobile Chrome/Safari!
            },
            rememberLastUsedCamera: true
          } as any);
          html5QrCode.start(
            { facingMode: "environment" },
            {
              fps: 12, // Balanced frame rate to avoid thermal CPU throttling
              qrbox: { width: 280, height: 160 }, // Perfect centered scanning box dimension for standard/small retail barcodes
              videoConstraints: {
                facingMode: "environment",
                width: { ideal: 1920 },
                height: { ideal: 1080 }
              }
            },
            (decodedText) => {
              handleBarcodeScanned(decodedText);
            },
            () => {} // Completely silent on scan failure frames to avoid slow rendering/console lag
          ).then(() => {
            // Camera successfully started! Now apply zoom and auto-focus fine-tuning if supported
            try {
              const track = (html5QrCode as any)?.getRunningTrack?.();
              if (track) {
                const capabilities = (track as any).getCapabilities?.() || {};
                const constraints: any = {};
                
                // Let's set focus mode if supported
                if (capabilities.focusMode && capabilities.focusMode.includes("continuous")) {
                  constraints.focusMode = "continuous";
                }
                
                // For small barcodes (medicines), let's set a slight zoom so users don't have to get too close
                if (capabilities.zoom) {
                  const minZoom = capabilities.zoom.min || 1;
                  const maxZoom = capabilities.zoom.max || 1;
                  if (maxZoom > minZoom) {
                    // Sane moderate zoom (e.g., zoom in slightly, e.g. 1.5x)
                    const targetZoom = Math.min(minZoom + 0.8, maxZoom); 
                    constraints.zoom = targetZoom;
                  }
                }
                
                if (Object.keys(constraints).length > 0) {
                  track.applyConstraints({ advanced: [constraints] }).catch((e) => {
                    console.warn("Failed to apply advanced constraints dynamically:", e);
                  });
                }
              }
            } catch (e) {
              console.warn("Error fine-tuning video track:", e);
            }
          }).catch((err) => {
            console.warn("POS Camera start with high constraints failed, retrying with simple constraints...", err);
            // Fallback starting attempt with simple environment facing mode to guarantee camera works on all devices
            html5QrCode?.start(
              { facingMode: "environment" },
              {
                fps: 12,
                qrbox: { width: 280, height: 160 }
              },
              (decodedText) => {
                handleBarcodeScanned(decodedText);
              },
              () => {}
            ).catch((fallbackErr) => {
              console.error("Fallback POS camera start failed entirely:", fallbackErr);
            });
          });
        } catch (err) {
          console.error("POS Scanner setup failed:", err);
        }
      }, 400);

      return () => {
        clearTimeout(timer);
        if (html5QrCode) {
          if (html5QrCode.isScanning) {
            html5QrCode.stop()
              .then(() => console.log("POS Scanner stopped."))
              .catch((e) => console.error("Error stopping POS scanner:", e));
          }
        }
      };
    }
  }, [showPOSScanner]);

  const addToCart = (product: Product) => {
    if (product.quantity <= 0) {
      showMessage("عذراً، هذا الدواء غير متوفر في المخزن حالياً!", "error");
      return;
    }

    const existingIndex = cart.findIndex((item) => item.product.id === product.id);
    if (existingIndex > -1) {
      const currentQtyInCart = cart[existingIndex].quantity;
      if (currentQtyInCart >= product.quantity) {
        showMessage(`لا يمكنك تجاوز الكمية المتوفرة في المخزن (${product.quantity} علبة)!`, "error");
        return;
      }
      const newCart = [...cart];
      newCart[existingIndex].quantity += 1;
      setCart(newCart);
    } else {
      setCart([...cart, { product, quantity: 1 }]);
    }
  };

  const updateCartQty = (productId: string, delta: number) => {
    const existingIndex = cart.findIndex((item) => item.product.id === productId);
    if (existingIndex === -1) return;

    const item = cart[existingIndex];
    const newQty = item.quantity + delta;

    if (newQty <= 0) {
      // Remove from cart
      const newCart = cart.filter((i) => i.product.id !== productId);
      setCart(newCart);
      return;
    }

    if (newQty > item.product.quantity) {
      showMessage(`الكمية المطلوبة تتجاوز المتاح في المخزن (${item.product.quantity} علبة)!`, "error");
      return;
    }

    const newCart = [...cart];
    newCart[existingIndex].quantity = newQty;
    setCart(newCart);
  };

  const removeFromCart = (productId: string) => {
    setCart(cart.filter((item) => item.product.id !== productId));
  };

  // Calculations
  const subtotal = cart.reduce((acc, item) => acc + item.product.sellPrice * item.quantity, 0);
  const total = Math.max(0, subtotal - discount);
  const itemsCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Handle sale completion
  const handleCheckout = async () => {
    if (cart.length === 0) {
      showMessage("السلة فارغة! الرجاء إضافة أدوية للبيع.", "error");
      return;
    }

    if (paymentType === "debt" && !selectedCustomerId) {
      showMessage("الرجاء اختيار العميل لتسجيل البيع بالدين!", "error");
      return;
    }

    try {
      // 1. Double check quantities and update stock in a transaction or sequential operations
      for (const item of cart) {
        const freshProduct = await IndexedDBService.getById<Product>("products", item.product.id);
        if (!freshProduct) {
          throw new Error(`الدواء ${item.product.commercialName} غير موجود!`);
        }
        if (freshProduct.quantity < item.quantity) {
          showMessage(`فشلت العملية! كمية ${freshProduct.commercialName} غير كافية في المخزن (المتوفر: ${freshProduct.quantity}).`, "error");
          return;
        }
      }

      // 2. Decrement stock
      for (const item of cart) {
        const freshProduct = (await IndexedDBService.getById<Product>("products", item.product.id))!;
        freshProduct.quantity -= item.quantity;
        await IndexedDBService.update("products", freshProduct);
      }

      // 3. Update customer debts if selling by debt
      if (paymentType === "debt" && selectedCustomerId) {
        const customer = (await IndexedDBService.getById<Customer>("customers", selectedCustomerId))!;
        customer.debts += total;
        await IndexedDBService.update("customers", customer);
      }

      // 4. Create invoice record
      const invoiceNumber = `INV-${new Date().toISOString().replace(/[-:T]/g, "").slice(0, 8)}-${Math.floor(100 + Math.random() * 900)}`;
      const invoiceItems: SaleInvoiceItem[] = cart.map((item) => ({
        productId: item.product.id,
        commercialName: item.product.commercialName,
        scientificName: item.product.scientificName,
        price: item.product.sellPrice,
        quantity: item.quantity,
        total: item.product.sellPrice * item.quantity,
      }));

      const newInvoice: SaleInvoice = {
        id: `sale-inv-${Date.now()}`,
        invoiceNumber,
        date: new Date().toISOString(),
        customerId: selectedCustomerId || null,
        items: invoiceItems,
        subtotal,
        discount,
        total,
        notes: invoiceNotes,
      };

      await IndexedDBService.add("sales", newInvoice);

      showMessage(`تم حفظ الفاتورة بنجاح برقم: ${invoiceNumber}`, "success");
      
      // Reset State
      setCart([]);
      setDiscount(0);
      setSelectedCustomerId("");
      setPaymentType("cash");
      setInvoiceNotes("");

      // Refresh product list in UI
      const result = await IndexedDBService.searchProducts(
        searchTerm,
        selectedCategory || undefined,
        undefined,
        false,
        40,
        0
      );
      setProductsList(result.items);
    } catch (err: any) {
      console.error(err);
      showMessage(err.message || "حدث خطأ غير متوقع أثناء معالجة الفاتورة", "error");
    }
  };

  const handleAddCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomerName.trim()) return;

    try {
      const newCust: Customer = {
        id: `cust-${Date.now()}`,
        name: newCustomerName,
        phone: newCustomerPhone,
        address: "غير محدد",
        debts: 0,
      };
      await IndexedDBService.add("customers", newCust);
      const updatedCusts = await IndexedDBService.getAll<Customer>("customers");
      setCustomers(updatedCusts);
      setSelectedCustomerId(newCust.id);
      setShowAddCustomerModal(false);
      setNewCustomerName("");
      setNewCustomerPhone("");
      showMessage("تمت إضافة العميل الجديد بنجاح", "success");
    } catch (err) {
      console.error(err);
      showMessage("فشل إضافة العميل", "error");
    }
  };

  return (
    <div className="flex flex-col xl:flex-row gap-6 h-full">
      {/* LEFT COLUMN: Product Catalog (60% width on massive screens) */}
      <div className="flex-1 flex flex-col gap-4">
        {/* Search & Categories Bar */}
        <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                id="pos-search"
                placeholder="ابحث بالاسم، التركيب، أو امسح الباركود..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pr-10 pl-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-emerald-500 font-sans text-sm text-right"
              />
              <Search className="absolute right-3.5 top-3.5 w-4 h-4 text-slate-400" />
            </div>
            <button
              type="button"
              onClick={() => setShowPOSScanner(true)}
              className="px-4 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:text-indigo-400 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 justify-center cursor-pointer transition-colors font-bold text-xs"
              title="بيع سريع بواسطة الباركود"
            >
              📷
              <span>القارئ الذكي</span>
            </button>
          </div>

          {/* Quick Categories list */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
            <button
              onClick={() => setSelectedCategory("")}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 cursor-pointer transition-colors ${
                selectedCategory === ""
                  ? "bg-emerald-600 text-white"
                  : "bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 text-slate-600 dark:text-slate-300"
              }`}
            >
              الكل
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 cursor-pointer transition-colors ${
                  selectedCategory === cat.id
                    ? "bg-emerald-600 text-white"
                    : "bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 text-slate-600 dark:text-slate-300"
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Product Catalog list/grid */}
        <div className="flex-1 min-h-[350px] bg-slate-50/50 dark:bg-slate-900/10 rounded-2xl border border-slate-200/60 dark:border-slate-800 p-4 overflow-y-auto max-h-[60vh] xl:max-h-[calc(100vh-250px)]">
          {loadingProducts && productsList.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-8 h-8 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : productsList.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <BadgeAlert className="w-12 h-12 text-slate-400 mb-2" />
              <p className="text-sm font-semibold text-slate-500">لم يتم العثور على أدوية مطابقة</p>
              <p className="text-xs text-slate-400 mt-1">تأكد من كتابة الاسم بشكل صحيح أو جرب فئة أخرى.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {productsList.map((prod) => {
                const isOutOfStock = prod.quantity <= 0;
                const isLowStock = prod.quantity <= prod.minStock;
                const inCartItem = cart.find((i) => i.product.id === prod.id);
                const quantityInCart = inCartItem?.quantity || 0;
                const displayQty = prod.quantity - quantityInCart;

                return (
                  <div
                    key={prod.id}
                    id={`pos-item-${prod.id}`}
                    className={`p-4 rounded-xl border bg-white dark:bg-slate-900 transition-all flex flex-col justify-between ${
                      isOutOfStock
                        ? "border-rose-100 dark:border-rose-950/20 opacity-60"
                        : quantityInCart > 0
                        ? "border-emerald-500 dark:border-emerald-500/50 shadow-xs ring-1 ring-emerald-500/10"
                        : "border-slate-200 dark:border-slate-800 hover:border-slate-300 hover:shadow-xs"
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-1.5 mb-1.5">
                        <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm leading-tight line-clamp-1" title={prod.commercialName}>
                          {prod.commercialName}
                        </h3>
                        <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 shrink-0">{prod.location}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 dark:text-slate-500 italic truncate mb-2 leading-none" title={prod.scientificName}>
                        {prod.scientificName}
                      </p>
                      <div className="flex items-center gap-1.5 mb-3">
                        <span className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2 py-0.5 rounded-md font-medium">
                          {prod.manufacturer}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-baseline justify-between">
                        <span className="text-xs text-slate-400">سعر البيع:</span>
                        <span className="text-sm font-bold text-slate-800 dark:text-slate-200 font-mono">
                          {prod.sellPrice.toLocaleString("ar-IQ")} {currency}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-400">المخزون المتاح:</span>
                        {isOutOfStock ? (
                          <span className="text-rose-600 dark:text-rose-400 font-semibold bg-rose-50 dark:bg-rose-950/30 px-1.5 py-0.5 rounded-md">
                            نفذ بالكامل
                          </span>
                        ) : isLowStock ? (
                          <span className="text-amber-600 dark:text-amber-400 font-semibold bg-amber-50 dark:bg-amber-950/30 px-1.5 py-0.5 rounded-md font-mono">
                            قليل ({displayQty})
                          </span>
                        ) : (
                          <span className="text-slate-600 dark:text-slate-300 font-medium font-mono">
                            {displayQty} علبة
                          </span>
                        )}
                      </div>

                      {isOutOfStock ? (
                        <button
                          disabled
                          className="w-full mt-2 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 text-xs font-semibold cursor-not-allowed"
                        >
                          غير متوفر
                        </button>
                      ) : (
                        <button
                          onClick={() => addToCart(prod)}
                          className="w-full mt-2 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>إضافة للسلة</span>
                          {quantityInCart > 0 && (
                            <span className="bg-white text-emerald-700 px-1.5 py-0.1 text-[10px] rounded-full ml-1 font-bold font-mono">
                              {quantityInCart}
                            </span>
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* RIGHT COLUMN: Active Cart Panel (40% width on massive screens) */}
      <div className="w-full xl:w-[420px] bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between shadow-xs h-full xl:min-h-[calc(100vh-140px)] sticky top-6">
        <div>
          {/* Cart Header */}
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5 text-emerald-500" />
              <h2 className="font-bold text-slate-800 dark:text-slate-100">سلة المبيعات</h2>
              <span className="bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 px-2 py-0.5 rounded-full text-xs font-bold font-mono">
                {itemsCount}
              </span>
            </div>
            {cart.length > 0 && (
              <button
                onClick={() => setCart([])}
                className="text-xs text-rose-500 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>إفراغ</span>
              </button>
            )}
          </div>

          {/* Cart List */}
          <div className="max-h-[250px] xl:max-h-[300px] overflow-y-auto space-y-3 mb-4 divide-y divide-slate-100 dark:divide-slate-800 pr-1">
            {cart.length === 0 ? (
              <div className="py-12 flex flex-col items-center justify-center text-center text-slate-400">
                <ShoppingCart className="w-10 h-10 mb-2 opacity-35" />
                <p className="text-xs font-semibold">سلة المبيعات فارغة</p>
                <p className="text-[11px] text-slate-400 mt-1">انقر على الأدوية في اليسار لإضافتها هنا</p>
              </div>
            ) : (
              cart.map((item) => (
                <div key={item.product.id} className="pt-3 flex items-start gap-2 justify-between text-sm">
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-slate-800 dark:text-slate-200 truncate leading-snug">{item.product.commercialName}</p>
                    <p className="text-xs text-slate-400 font-mono mt-0.5">
                      {item.product.sellPrice.toLocaleString("ar-IQ")} {currency}
                    </p>
                  </div>
                  
                  {/* Quantity Controls */}
                  <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 rounded-lg p-1 shrink-0">
                    <button
                      onClick={() => updateCartQty(item.product.id, -1)}
                      className="p-1 rounded-md hover:bg-white dark:hover:bg-slate-700 text-slate-500 dark:text-slate-300 transition-colors cursor-pointer"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-6 text-center font-bold text-xs font-mono text-slate-800 dark:text-slate-100">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateCartQty(item.product.id, 1)}
                      className="p-1 rounded-md hover:bg-white dark:hover:bg-slate-700 text-slate-500 dark:text-slate-300 transition-colors cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <div className="text-left font-semibold font-mono text-slate-800 dark:text-slate-100 shrink-0 min-w-[70px]">
                    {(item.product.sellPrice * item.quantity).toLocaleString("ar-IQ")}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Customer & Payment Setup */}
          <div className="border-t border-slate-150 dark:border-slate-800 pt-4 space-y-3.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-slate-400" />
                <span>الزبون</span>
              </label>
              <button
                onClick={() => setShowAddCustomerModal(true)}
                className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
              >
                + عميل جديد
              </button>
            </div>

            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-slate-700 dark:text-slate-200 focus:outline-none focus:border-emerald-500 font-sans"
            >
              <option value="">زبون نقدي سريع (عام)</option>
              {customers.map((cust) => (
                <option key={cust.id} value={cust.id}>
                  {cust.name} {cust.phone ? `(${cust.phone})` : ""} - ديون: {cust.debts.toLocaleString("ar-IQ")} د.ع
                </option>
              ))}
            </select>

            {/* Payment Method Switcher */}
            <div className="grid grid-cols-2 gap-2 bg-slate-50 dark:bg-slate-800 rounded-xl p-1 border border-slate-200/50 dark:border-slate-800">
              <button
                onClick={() => setPaymentType("cash")}
                className={`py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                  paymentType === "cash"
                    ? "bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 shadow-xs"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-800"
                }`}
              >
                بيع نقدي (كاش)
              </button>
              <button
                onClick={() => setPaymentType("debt")}
                className={`py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                  paymentType === "debt"
                    ? "bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-100 shadow-xs"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-800"
                }`}
              >
                بيع بالدين (آجل)
              </button>
            </div>

            {/* Discount input */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-400">الخصم (تخفيض في السعر):</label>
                {discount > 0 && (
                  <span className="text-[10px] text-emerald-600 font-bold">خصم مفعّل</span>
                )}
              </div>
              <div className="relative">
                <input
                  type="number"
                  placeholder="مبلغ الخصم بالدينار..."
                  value={discount === 0 ? "" : discount}
                  onChange={(e) => setDiscount(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full pr-3 pl-16 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-emerald-500 font-mono text-xs text-left"
                />
                <span className="absolute left-3 top-2.5 text-slate-400 text-[10px] font-sans">دينار عراقي</span>
              </div>
            </div>

            {/* Note input */}
            <input
              type="text"
              placeholder="ملاحظات على الفاتورة (اختياري)..."
              value={invoiceNotes}
              onChange={(e) => setInvoiceNotes(e.target.value)}
              className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-emerald-500 text-xs font-sans"
            />
          </div>
        </div>

        {/* Totals & Submit */}
        <div className="border-t border-slate-150 dark:border-slate-800 pt-4 space-y-3 mt-4">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>المجموع الفرعي:</span>
            <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
              {subtotal.toLocaleString("ar-IQ")} {currency}
            </span>
          </div>

          {discount > 0 && (
            <div className="flex items-center justify-between text-xs text-rose-500 font-semibold">
              <span>قيمة الخصم:</span>
              <span className="font-mono">
                -{discount.toLocaleString("ar-IQ")} {currency}
              </span>
            </div>
          )}

          <div className="flex items-baseline justify-between text-base font-bold text-slate-800 dark:text-slate-100 border-t border-dashed border-slate-100 dark:border-slate-800 pt-2.5">
            <span>الإجمالي النهائي:</span>
            <span className="text-xl text-emerald-600 dark:text-emerald-400 font-mono">
              {total.toLocaleString("ar-IQ")} {currency}
            </span>
          </div>

          <button
            onClick={handleCheckout}
            disabled={cart.length === 0}
            className={`w-full py-3.5 rounded-xl text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 ${
              cart.length === 0
                ? "bg-slate-300 dark:bg-slate-800 text-slate-500 dark:text-slate-500 cursor-not-allowed shadow-none"
                : "bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/10 active:scale-98 cursor-pointer"
            }`}
          >
            <CheckCircle className="w-5 h-5" />
            <span>تأكيد وحفظ الفاتورة</span>
          </button>
        </div>
      </div>

      {/* Message Popup/Toast */}
      <AnimatePresence>
        {message && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-6 right-6 z-50 px-5 py-3.5 rounded-2xl shadow-xl flex items-center gap-2.5 border text-sm max-w-sm font-sans ${
              message.type === "success"
                ? "bg-emerald-50 border-emerald-100 dark:bg-emerald-950/90 dark:border-emerald-900 text-emerald-800 dark:text-emerald-300"
                : "bg-rose-50 border-rose-100 dark:bg-rose-950/90 dark:border-rose-900 text-rose-800 dark:text-rose-300"
            }`}
          >
            {message.type === "success" ? (
              <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500" />
            ) : (
              <AlertCircle className="w-5 h-5 shrink-0 text-rose-500" />
            )}
            <span className="font-semibold leading-relaxed">{message.text}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- ADD CUSTOMER MODAL --- */}
      {showAddCustomerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-md shadow-2xl">
            <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base mb-4">إضافة زبون جديد في النظام</h3>
            
            <form onSubmit={handleAddCustomer} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">اسم الزبون الكلي:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: حسين علي جبار..."
                  value={newCustomerName}
                  onChange={(e) => setNewCustomerName(e.target.value)}
                  className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-emerald-500 text-sm font-sans"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">رقم الهاتف (العراق):</label>
                <input
                  type="text"
                  placeholder="مثال: 07701234567..."
                  value={newCustomerPhone}
                  onChange={(e) => setNewCustomerPhone(e.target.value)}
                  className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-emerald-500 font-mono text-sm"
                />
              </div>

              <div className="flex items-center gap-3 pt-2 justify-end">
                <button
                  type="button"
                  onClick={() => setShowAddCustomerModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 text-xs font-semibold cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                >
                  إلغاء الأمر
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-500 cursor-pointer transition-colors"
                >
                  حفظ العميل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- CAMERA BARCODE SCAN MODAL FOR POS --- */}
      <AnimatePresence>
        {showPOSScanner && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-md shadow-2xl text-right font-sans space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <button
                  type="button"
                  onClick={() => setShowPOSScanner(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
                <div className="text-right">
                  <h3 className="font-bold text-slate-850 dark:text-slate-100 text-sm">قارئ الباركود الذكي للمبيعات</h3>
                  <p className="text-[10px] text-slate-400">وجه الكاميرا نحو باركود علبة الدواء لإضافتها تلقائياً إلى السلة</p>
                </div>
              </div>

              {/* Viewport for camera scan */}
              <div className="relative w-full h-56 bg-slate-950 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 flex items-center justify-center">
                <div id="pos-scanner-viewport" className="absolute inset-0 w-full h-full"></div>
                
                {/* Visual scanning box overlay - Centered 280x160 region with shaded surround */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[280px] h-[160px] border-2 border-emerald-500 border-dashed rounded-xl flex items-center justify-center pointer-events-none z-10 shadow-[0_0_0_9999px_rgba(0,0,0,0.65)]">
                  {/* Glowing Laser line animation */}
                  <div className="absolute inset-x-0 h-[2px] bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)] animate-[bounce_2s_infinite]"></div>
                </div>
              </div>

              {/* Simulation fallback for testing/preview */}
              <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/20 text-indigo-700 dark:text-indigo-400 rounded-xl border border-indigo-100 dark:border-indigo-900/40 space-y-2">
                <p className="text-[10px] font-bold text-center">💡 مسح ومبيعات سريعة تجريبية (بدون كاميرا):</p>
                <p className="text-[9px] text-center text-slate-500 dark:text-slate-400 leading-relaxed">
                  بإمكانك تجربة المبيعات الفورية بنقرة واحدة لمحاكاة قراءة الباركود بنجاح:
                </p>
                <div className="grid grid-cols-3 gap-1.5 pt-1 text-right font-sans">
                  <button
                    type="button"
                    onClick={() => handleBarcodeScanned("3057640107481")}
                    className="py-1 px-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-[9px] text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-100 cursor-pointer truncate"
                  >
                    بندول إكسترا
                  </button>
                  <button
                    type="button"
                    onClick={() => handleBarcodeScanned("5012345678901")}
                    className="py-1 px-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-[9px] text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-100 cursor-pointer truncate"
                  >
                    أموكسيسيلين
                  </button>
                  <button
                    type="button"
                    onClick={() => handleBarcodeScanned("6291100342152")}
                    className="py-1 px-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-[9px] text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-100 cursor-pointer truncate"
                  >
                    بخاخ فنتولين
                  </button>
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  type="button"
                  onClick={() => setShowPOSScanner(false)}
                  className="w-full py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
                >
                  إغلاق قارئ الكاميرا
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
