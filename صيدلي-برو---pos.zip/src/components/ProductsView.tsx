/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Search,
  Plus,
  Pencil,
  Trash2,
  Calendar,
  AlertTriangle,
  FileText,
  DollarSign,
  Package,
  Layers,
  MapPin,
  X,
  Filter,
  CheckCircle,
  HelpCircle,
  Pill
} from "lucide-react";
import { IndexedDBService } from "../db/indexedDB";
import { Product, Category } from "../types";
import { Html5Qrcode, Html5QrcodeSupportedFormats } from "html5-qrcode";

interface ProductsViewProps {
  currency: string;
}

export default function ProductsView({ currency }: ProductsViewProps) {
  // DB States
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [totalCount, setTotalCount] = useState(0);

  // Pagination & Filters State
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [search, setSearch] = useState("");
  const [selectedCat, setSelectedCat] = useState("");
  const [selectedMan, setSelectedMan] = useState("");
  const [filterExpiredOnly, setFilterExpiredOnly] = useState(false);
  const [loading, setLoading] = useState(false);

  // Form / Modal State
  const [showFormModal, setShowFormModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState<Product | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Toast State
  const [toast, setToast] = useState<{ text: string; type: "success" | "error" } | null>(null);

  // Form Fields State
  const [commName, setCommName] = useState("");
  const [sciName, setSciName] = useState("");
  const [manufacturer, setManufacturer] = useState("");
  const [catId, setCatId] = useState("");
  const [batchNo, setBatchNo] = useState("");
  const [prodDate, setProdDate] = useState("");
  const [expDate, setExpDate] = useState("");
  const [buyPrice, setBuyPrice] = useState<number>(0);
  const [sellPrice, setSellPrice] = useState<number>(0);
  const [wholesalePrice, setWholesalePrice] = useState<number>(0);
  const [quantity, setQuantity] = useState<number>(0);
  const [minStock, setMinStock] = useState<number>(5);
  const [location, setLocation] = useState("");
  const [notes, setNotes] = useState("");
  const [dosageForm, setDosageForm] = useState("شريط");
  const [barcode, setBarcode] = useState("");

  // Scanner & Quick Category States
  const [showScanner, setShowScanner] = useState(false);
  const [showQuickCategoryModal, setShowQuickCategoryModal] = useState(false);
  const [newCatName, setNewCatName] = useState("");
  const [newCatDesc, setNewCatDesc] = useState("");

  const showToast = (text: string, type: "success" | "error" = "success") => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3000);
  };

  // Barcode Camera Scanner logic
  useEffect(() => {
    let html5QrCode: Html5Qrcode | null = null;

    if (showScanner) {
      const timer = setTimeout(() => {
        try {
          html5QrCode = new Html5Qrcode("barcode-scanner-viewport", {
            formatsToSupport: [
              Html5QrcodeSupportedFormats.EAN_13,
              Html5QrcodeSupportedFormats.EAN_8,
              Html5QrcodeSupportedFormats.CODE_128,
              Html5QrcodeSupportedFormats.UPC_A,
              Html5QrcodeSupportedFormats.UPC_E,
              Html5QrcodeSupportedFormats.CODE_39,
              Html5QrcodeSupportedFormats.QR_CODE
            ],
            verbose: false,
            experimentalFeatures: {
              useBarCodeDetectorIfSupported: true // Native hardware acceleration on mobile Chrome/Safari!
            },
            rememberLastUsedCamera: true
          } as any);
          html5QrCode.start(
            { facingMode: "environment" },
            {
              fps: 12, // Balanced frame rate to avoid thermal CPU throttling
              qrbox: { width: 280, height: 160 }, // Perfect centered scanning box dimension for standard/small retail barcodes
              videoConstraints: {
                facingMode: "environment",
                width: { ideal: 1920 },
                height: { ideal: 1080 }
              }
            },
            (decodedText) => {
              setBarcode(decodedText);
              // Sound beep feedback
              try {
                const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.connect(gain);
                gain.connect(audioCtx.destination);
                osc.type = "sine";
                osc.frequency.setValueAtTime(1200, audioCtx.currentTime);
                gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
                osc.start();
                osc.stop(audioCtx.currentTime + 0.15);
              } catch (e) {
                console.error("Audio Context Beep Error:", e);
              }
              showToast(`تم قراءة الباركود: ${decodedText}`);
              setShowScanner(false);
            },
            () => {} // Completely silent on scan failure frames to avoid slow rendering/console lag
          ).then(() => {
            // Camera successfully started! Now apply zoom and auto-focus fine-tuning if supported
            try {
              const track = (html5QrCode as any)?.getRunningTrack?.();
              if (track) {
                const capabilities = (track as any).getCapabilities?.() || {};
                const constraints: any = {};
                
                // Let's set focus mode if supported
                if (capabilities.focusMode && capabilities.focusMode.includes("continuous")) {
                  constraints.focusMode = "continuous";
                }
                
                // For small barcodes (medicines), let's set a slight zoom so users don't have to get too close
                if (capabilities.zoom) {
                  const minZoom = capabilities.zoom.min || 1;
                  const maxZoom = capabilities.zoom.max || 1;
                  if (maxZoom > minZoom) {
                    // Sane moderate zoom (e.g., zoom in slightly, e.g. 1.5x)
                    const targetZoom = Math.min(minZoom + 0.8, maxZoom); 
                    constraints.zoom = targetZoom;
                  }
                }
                
                if (Object.keys(constraints).length > 0) {
                  track.applyConstraints({ advanced: [constraints] }).catch((e) => {
                    console.warn("Failed to apply advanced constraints dynamically:", e);
                  });
                }
              }
            } catch (e) {
              console.warn("Error fine-tuning video track:", e);
            }
          }).catch((err) => {
            console.warn("Camera start with high constraints failed, retrying with simple constraints...", err);
            // Fallback starting attempt with simple environment facing mode to guarantee camera works on all devices
            html5QrCode?.start(
              { facingMode: "environment" },
              {
                fps: 12,
                qrbox: { width: 280, height: 160 }
              },
              (decodedText) => {
                setBarcode(decodedText);
                try {
                  const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
                  const osc = audioCtx.createOscillator();
                  const gain = audioCtx.createGain();
                  osc.connect(gain);
                  gain.connect(audioCtx.destination);
                  osc.type = "sine";
                  osc.frequency.setValueAtTime(1200, audioCtx.currentTime);
                  gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
                  osc.start();
                  osc.stop(audioCtx.currentTime + 0.15);
                } catch (e) {
                  console.error("Audio Context Beep Error:", e);
                }
                showToast(`تم قراءة الباركود: ${decodedText}`);
                setShowScanner(false);
              },
              () => {}
            ).catch((fallbackErr) => {
              console.error("Fallback camera start failed entirely:", fallbackErr);
            });
          });
        } catch (err) {
          console.error("Scanner setup failed:", err);
        }
      }, 400);

      return () => {
        clearTimeout(timer);
        if (html5QrCode) {
          if (html5QrCode.isScanning) {
            html5QrCode.stop()
              .then(() => {
                console.log("Scanner stopped successfully.");
              })
              .catch((e) => console.error("Error stopping scanner:", e));
          }
        }
      };
    }
  }, [showScanner]);

  const handleSaveQuickCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) {
      showToast("يرجى كتابة اسم الفئة الدوائية", "error");
      return;
    }

    try {
      const newId = `cat-${Date.now()}`;
      const newCat: Category = {
        id: newId,
        name: newCatName.trim(),
        description: newCatDesc.trim() || undefined
      };

      await IndexedDBService.add("categories", newCat);
      showToast(`تمت إضافة الفئة (${newCat.name}) بنجاح`);

      // Reload categories dropdown
      const cats = await IndexedDBService.getAll<Category>("categories");
      setCategories(cats);

      // Auto select the newly created category in the select dropdown
      setCatId(newId);

      // Reset fields & close quick modal
      setNewCatName("");
      setNewCatDesc("");
      setShowQuickCategoryModal(false);
    } catch (err) {
      console.error(err);
      showToast("فشلت عملية إضافة الفئة الجديدة", "error");
    }
  };

  // Load Categories & Products list
  const loadData = async () => {
    setLoading(true);
    try {
      const cats = await IndexedDBService.getAll<Category>("categories");
      setCategories(cats);

      // Search and Paginate
      const offset = (page - 1) * pageSize;
      const result = await IndexedDBService.searchProducts(
        search,
        selectedCat || undefined,
        selectedMan || undefined,
        filterExpiredOnly,
        pageSize,
        offset
      );

      setProducts(result.items);
      setTotalCount(result.total);
    } catch (err) {
      console.error(err);
      showToast("فشل تحميل البيانات من قاعدة البيانات", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [page, search, selectedCat, selectedMan, filterExpiredOnly]);

  const openAddModal = () => {
    setEditingProduct(null);
    setCommName("");
    setSciName("");
    setManufacturer("");
    setCatId(categories[0]?.id || "");
    setBatchNo("");
    
    const today = new Date().toISOString().split("T")[0];
    setProdDate(today);
    
    const nextYear = new Date();
    nextYear.setFullYear(nextYear.getFullYear() + 2);
    setExpDate(nextYear.toISOString().split("T")[0]);
    
    setBuyPrice(0);
    setSellPrice(0);
    setWholesalePrice(0);
    setQuantity(10);
    setMinStock(5);
    setLocation("");
    setNotes("");
    setDosageForm("شريط");
    setBarcode("");
    setShowFormModal(true);
  };

  const openEditModal = (prod: Product) => {
    setEditingProduct(prod);
    setCommName(prod.commercialName);
    setSciName(prod.scientificName);
    setManufacturer(prod.manufacturer);
    setCatId(prod.categoryId);
    setBatchNo(prod.batchNumber);
    setProdDate(prod.productionDate);
    setExpDate(prod.expirationDate);
    setBuyPrice(prod.buyPrice);
    setSellPrice(prod.sellPrice);
    setWholesalePrice(prod.wholesalePrice);
    setQuantity(prod.quantity);
    setMinStock(prod.minStock);
    setLocation(prod.location);
    setNotes(prod.notes || "");
    setDosageForm(prod.dosageForm || "شريط");
    setBarcode(prod.barcode || "");
    setShowFormModal(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commName.trim() || !sciName.trim() || !catId) {
      showToast("الرجاء ملء الحقول الإلزامية المطلوبة", "error");
      return;
    }

    try {
      const productData: Product = {
        id: editingProduct ? editingProduct.id : `prod-${Date.now()}`,
        commercialName: commName,
        scientificName: sciName,
        manufacturer,
        categoryId: catId,
        batchNumber: batchNo,
        productionDate: prodDate,
        expirationDate: expDate,
        buyPrice,
        sellPrice,
        wholesalePrice,
        quantity,
        minStock,
        location: location || "غير محدد",
        notes,
        dosageForm,
        barcode
      };

      if (editingProduct) {
        await IndexedDBService.update("products", productData);
        showToast("تم تعديل معلومات الدواء بنجاح");
      } else {
        await IndexedDBService.add("products", productData);
        showToast("تمت إضافة الدواء الجديد إلى الرفوف");
      }

      setShowFormModal(false);
      loadData();
    } catch (err) {
      console.error(err);
      showToast("فشلت عملية حفظ معلومات الدواء", "error");
    }
  };

  const handleDeleteProduct = async () => {
    if (!showDeleteModal) return;

    try {
      await IndexedDBService.delete("products", showDeleteModal.id);
      showToast(`تم حذف الدواء (${showDeleteModal.commercialName}) من النظام نهائياً`);
      setShowDeleteModal(null);
      
      // If we delete the last item on the page, go to previous page
      if (products.length === 1 && page > 1) {
        setPage(page - 1);
      } else {
        loadData();
      }
    } catch (err) {
      console.error(err);
      showToast("فشلت عملية الحذف", "error");
    }
  };

  const totalPages = Math.ceil(totalCount / pageSize) || 1;

  return (
    <div className="space-y-6">
      {/* Header and Quick stats */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">إدارة دليل الأدوية والمخازن</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 font-sans">تحديث وعرض جميع الأدوية المتاحة في صيدلية صيدلي برو.</p>
        </div>
        <button
          id="btn-add-product"
          onClick={openAddModal}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة دواء جديد</span>
        </button>
      </div>

      {/* Filter Options Panel */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-2.5">
          <Filter className="w-4 h-4 text-emerald-500" />
          <h2 className="text-xs font-bold text-slate-700 dark:text-slate-300">خيارات البحث والتصفية المتقدمة</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {/* Quick Search */}
          <div className="relative">
            <input
              type="text"
              placeholder="البحث بالاسم التجاري أو العلمي..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              className="w-full pr-9 pl-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
            />
            <Search className="absolute right-3 top-2.5 w-4 h-4 text-slate-400" />
          </div>

          {/* Filter Category */}
          <select
            value={selectedCat}
            onChange={(e) => {
              setSelectedCat(e.target.value);
              setPage(1);
            }}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:border-emerald-500"
          >
            <option value="">جميع فئات الأدوية</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.name}
              </option>
            ))}
          </select>

          {/* Manufacturer */}
          <input
            type="text"
            placeholder="الشركة المصنعة (تصفية)..."
            value={selectedMan}
            onChange={(e) => {
              setSelectedMan(e.target.value);
              setPage(1);
            }}
            className="w-full pr-3 pl-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
          />

          {/* Expired toggle filter */}
          <div className="flex items-center">
            <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-600 dark:text-slate-400 select-none">
              <input
                type="checkbox"
                checked={filterExpiredOnly}
                onChange={(e) => {
                  setFilterExpiredOnly(e.target.checked);
                  setPage(1);
                }}
                className="rounded-md border-slate-300 dark:border-slate-700 text-emerald-600 focus:ring-emerald-500"
              />
              <span>عرض الأدوية منتهية الصلاحية فقط</span>
            </label>
          </div>
        </div>
      </div>

      {/* Products Table/Grid */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-850 border-b border-slate-100 dark:border-slate-800 text-xs font-bold text-slate-500 dark:text-slate-400">
                <th className="p-4">الدواء والاسم العلمي</th>
                <th className="p-4">الفئة / المصنّع</th>
                <th className="p-4">سعر البيع (مفرد)</th>
                <th className="p-4">المخزون المتوفر</th>
                <th className="p-4">رقم التشغيلة / الانتهاء</th>
                <th className="p-4">الموقع</th>
                <th className="p-4 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {loading ? (
                <tr>
                  <td colSpan={7} className="p-10 text-center">
                    <div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                    <span>جاري جلب أدوية الصيدلية...</span>
                  </td>
                </tr>
              ) : products.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-12 text-center text-slate-400">
                    لا توجد أدوية مطابقة للبحث حالياً في المخزن.
                  </td>
                </tr>
              ) : (
                products.map((prod) => {
                  const categoryName = categories.find((c) => c.id === prod.categoryId)?.name || "غير محدد";
                  const isLow = prod.quantity <= prod.minStock;
                  const isExpired = prod.expirationDate <= new Date().toISOString().split("T")[0];

                  return (
                    <tr key={prod.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 flex items-center justify-center text-emerald-600 dark:text-emerald-400 font-sans font-bold text-xs">
                            {prod.dosageForm === "مستلزم طبي" ? "🩺" : 
                             prod.dosageForm === "شراب" ? "🧪" :
                             prod.dosageForm === "قطرات" ? "💧" :
                             prod.dosageForm === "أمبولة" ? "💉" :
                             prod.dosageForm === "بخاخ" ? "💨" : "💊"}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-slate-800 dark:text-slate-200">{prod.commercialName}</span>
                              <span className="px-1.5 py-0.5 rounded-sm bg-slate-100 dark:bg-slate-800 text-[9px] text-slate-600 dark:text-slate-400 font-medium">
                                {prod.dosageForm || "شريط"}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-400 dark:text-slate-500 italic mt-0.5 max-w-[200px] truncate" title={prod.scientificName}>
                              {prod.scientificName}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-slate-600 dark:text-slate-400">
                        <p>{categoryName}</p>
                        <span className="text-[10px] text-slate-400 mt-0.5 block">{prod.manufacturer}</span>
                      </td>
                      <td className="p-4 font-mono font-bold text-slate-800 dark:text-slate-200">
                        {prod.sellPrice.toLocaleString("ar-IQ")} {currency}
                      </td>
                      <td className="p-4">
                        {prod.quantity === 0 ? (
                          <span className="px-2 py-1 rounded-md bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 font-bold">
                            نفذ بالكامل
                          </span>
                        ) : isLow ? (
                          <div>
                            <span className="px-2 py-1 rounded-md bg-amber-50 dark:bg-amber-950/30 text-amber-600 dark:text-amber-400 font-bold font-mono">
                              {prod.quantity} علبة
                            </span>
                            <span className="text-[9px] text-amber-500 block mt-1">تنبيه النقص!</span>
                          </div>
                        ) : (
                          <span className="font-semibold text-slate-700 dark:text-slate-300 font-mono">
                            {prod.quantity} علبة
                          </span>
                        )}
                      </td>
                      <td className="p-4 text-right">
                        <p className="font-mono text-[11px] text-slate-500 dark:text-slate-400">رقم: {prod.batchNumber}</p>
                        {prod.barcode && (
                          <p className="font-mono text-[10px] text-slate-400 dark:text-slate-500 mt-0.5 select-all" title="الباركود">
                            🏷️ {prod.barcode}
                          </p>
                        )}
                        <div className="flex items-center gap-1 mt-1 justify-end">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] font-semibold font-mono ${
                              isExpired
                                ? "bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300"
                                : "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                            }`}
                          >
                            ينتهي: {prod.expirationDate}
                          </span>
                        </div>
                      </td>
                      <td className="p-4 font-mono text-slate-500 dark:text-slate-400 text-xs">
                        {prod.location}
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => openEditModal(prod)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 cursor-pointer"
                            title="تعديل معلومات الدواء"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setShowDeleteModal(prod)}
                            className="p-1.5 rounded-lg border border-rose-200 hover:bg-rose-50 text-rose-600 cursor-pointer"
                            title="حذف الدواء"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination bar */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span>
            يتم عرض {products.length} من أصل {totalCount} دواء مسجل
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page === 1}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-750 hover:bg-slate-50 text-slate-700 disabled:opacity-40 cursor-pointer"
            >
              السابق
            </button>
            <span className="font-semibold font-mono text-slate-800 dark:text-slate-200">
              الصفحة {page} من {totalPages}
            </span>
            <button
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page === totalPages}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-750 hover:bg-slate-50 text-slate-700 disabled:opacity-40 cursor-pointer"
            >
              التالي
            </button>
          </div>
        </div>
      </div>

      {/* --- ADD / EDIT FORM MODAL --- */}
      <AnimatePresence>
        {showFormModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-2xl shadow-2xl my-8 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3.5 mb-5">
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base">
                  {editingProduct ? `تعديل الدواء: ${editingProduct.commercialName}` : "إضافة دواء جديد إلى الصيدلية"}
                </h3>
                <button
                  onClick={() => setShowFormModal(false)}
                  className="p-1 rounded-lg hover:bg-slate-100 text-slate-500"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveProduct} className="space-y-4 text-xs font-sans">
                {/* 1. Names Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الاسم التجاري (مطلوب):</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: بندول إكسترا..."
                      value={commName}
                      onChange={(e) => setCommName(e.target.value)}
                      className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الاسم العلمي (مطلوب):</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: Paracetamol + Caffeine..."
                      value={sciName}
                      onChange={(e) => setSciName(e.target.value)}
                      className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                {/* 2. Category & Manufacturer */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الفئة الدوائية:</label>
                    <div className="flex gap-2">
                      <select
                        value={catId}
                        onChange={(e) => setCatId(e.target.value)}
                        className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2 text-slate-700 dark:text-slate-200 focus:outline-none focus:border-emerald-500 text-xs"
                      >
                        {categories.map((cat) => (
                          <option key={cat.id} value={cat.id}>
                            {cat.name}
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        onClick={() => setShowQuickCategoryModal(true)}
                        className="px-2.5 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-400 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center cursor-pointer transition-colors"
                        title="إضافة فئة جديدة"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الشركة المصنعة:</label>
                    <input
                      type="text"
                      placeholder="مثال: GSK, Novartis..."
                      value={manufacturer}
                      onChange={(e) => setManufacturer(e.target.value)}
                      className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                {/* 3. Dates & Batch */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">رقم التشغيلة (Batch):</label>
                    <input
                      type="text"
                      placeholder="مثال: BT-9092..."
                      value={batchNo}
                      onChange={(e) => setBatchNo(e.target.value)}
                      className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">تاريخ الإنتاج:</label>
                    <input
                      type="date"
                      value={prodDate}
                      onChange={(e) => setProdDate(e.target.value)}
                      className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">تاريخ الانتهاء:</label>
                    <input
                      type="date"
                      value={expDate}
                      onChange={(e) => setExpDate(e.target.value)}
                      className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-mono"
                    />
                  </div>
                </div>

                {/* 4. Financial Prices in IQD */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">سعر الشراء الكلي (بالدينار):</label>
                    <input
                      type="number"
                      value={buyPrice === 0 ? "" : buyPrice}
                      onChange={(e) => setBuyPrice(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-mono text-left"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">سعر البيع للمفرد (بالدينار):</label>
                    <input
                      type="number"
                      value={sellPrice === 0 ? "" : sellPrice}
                      onChange={(e) => setSellPrice(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-mono text-left"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">سعر البيع للجملة (بالدينار):</label>
                    <input
                      type="number"
                      value={wholesalePrice === 0 ? "" : wholesalePrice}
                      onChange={(e) => setWholesalePrice(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-mono text-left"
                    />
                  </div>
                </div>

                {/* 5. Inventory Stock & Placement */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الكمية المتوفرة (علبة):</label>
                    <input
                      type="number"
                      required
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-mono text-left"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الحد الأدنى للتنبيه:</label>
                    <input
                      type="number"
                      required
                      value={minStock}
                      onChange={(e) => setMinStock(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-mono text-left"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الموقع داخل الصيدلية (الرف):</label>
                    <input
                      type="text"
                      placeholder="مثال: الرف A-3..."
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                {/* 6. Medical Form (Dosage form) & Barcode Scanner */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الشكل الدوائي / العنوان الطبي (مطلوب):</label>
                    <select
                      value={dosageForm}
                      onChange={(e) => setDosageForm(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:border-emerald-500"
                    >
                      <option value="شريط">شريط (Strip)</option>
                      <option value="كبسول">كبسول (Capsules)</option>
                      <option value="أمبولة">أمبولة (Ampoule / حقنة)</option>
                      <option value="شراب">شراب (Syrup)</option>
                      <option value="بخاخ">بخاخ (Spray / استنشاق)</option>
                      <option value="قطرات">قطرات (Drops - عين/أذن/أنف)</option>
                      <option value="مرهم">مرهم (Ointment)</option>
                      <option value="كريم">كريم (Cream)</option>
                      <option value="أقراص / حبوب">أقراص / حبوب (Tablets)</option>
                      <option value="فوار">فوار (Effervescent)</option>
                      <option value="بودرة">بودرة (Powder)</option>
                      <option value="مستلزم طبي">مستلزم طبي (Medical Supply - شاش/سرنجة/كانيولا)</option>
                      <option value="أخرى">أخرى / غير محدد</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الباركود (Barcode):</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="أدخل الرمز أو امسح بالكاميرا..."
                        value={barcode}
                        onChange={(e) => setBarcode(e.target.value)}
                        className="flex-1 py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-mono text-left"
                      />
                      <button
                        type="button"
                        onClick={() => setShowScanner(true)}
                        className="px-3 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:text-indigo-400 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 justify-center cursor-pointer transition-colors font-bold text-xs"
                        title="فتح كاميرا قارئ الباركود"
                      >
                        📷
                        <span>مسح</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* 7. Notes */}
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">ملاحظات إضافية:</label>
                  <input
                    type="text"
                    placeholder="ملاحظات حول طريقة الاستخدام أو شروط التخزين..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Submit Panel */}
                <div className="flex items-center gap-3 justify-end border-t border-slate-100 dark:border-slate-800 pt-4 mt-6">
                  <button
                    type="button"
                    onClick={() => setShowFormModal(false)}
                    className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 font-bold cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    إلغاء الأمر
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold cursor-pointer transition-colors"
                  >
                    حفظ الدواء في النظام
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- DELETE CONFIRMATION MODAL --- */}
      <AnimatePresence>
        {showDeleteModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-sm shadow-2xl text-center font-sans"
            >
              <div className="w-12 h-12 rounded-full bg-rose-50 dark:bg-rose-950/40 flex items-center justify-center mx-auto text-rose-600 mb-4">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base mb-2">تأكيد حذف الدواء</h3>
              <p className="text-slate-500 dark:text-slate-400 text-xs mb-6">
                هل أنت متأكد من رغبتك في حذف الدواء <span className="font-bold text-slate-800 dark:text-slate-100">"{showDeleteModal.commercialName}"</span> من النظام؟ هذه العملية غير قابلة للتراجع!
              </p>
              
              <div className="flex items-center gap-3 justify-center">
                <button
                  onClick={() => setShowDeleteModal(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 text-xs font-semibold cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  تراجع
                </button>
                <button
                  id="confirm-delete-product"
                  onClick={handleDeleteProduct}
                  className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-semibold hover:bg-rose-500 cursor-pointer"
                >
                  نعم، احذف الدواء
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- QUICK CATEGORY ADD MODAL --- */}
      <AnimatePresence>
        {showQuickCategoryModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-sm shadow-2xl text-right font-sans space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <button
                  type="button"
                  onClick={() => setShowQuickCategoryModal(false)}
                  className="p-1 rounded-lg text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
                <h3 className="font-bold text-slate-850 dark:text-slate-100 text-sm">إضافة فئة دوائية جديدة</h3>
              </div>

              <form onSubmit={handleSaveQuickCategory} className="space-y-4">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 text-xs font-bold mb-1">اسم الفئة (مطلوب):</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: مسكنات، مضادات حيوية..."
                    value={newCatName}
                    onChange={(e) => setNewCatName(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 text-xs font-bold mb-1">وصف الفئة (اختياري):</label>
                  <textarea
                    rows={2}
                    placeholder="وصف مختصر لاستخدامات هذه الفئة..."
                    value={newCatDesc}
                    onChange={(e) => setNewCatDesc(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 text-xs"
                  />
                </div>

                <div className="flex items-center gap-2 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setShowQuickCategoryModal(false)}
                    className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 text-xs font-semibold hover:bg-slate-50"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
                  >
                    إضافة وحفظ
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- CAMERA BARCODE SCAN MODAL --- */}
      <AnimatePresence>
        {showScanner && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-md shadow-2xl text-right font-sans space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                <button
                  type="button"
                  onClick={() => setShowScanner(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
                <div className="text-right">
                  <h3 className="font-bold text-slate-850 dark:text-slate-100 text-sm">مسح الباركود بالكاميرا</h3>
                  <p className="text-[10px] text-slate-400">وجه كاميرا الهاتف الخلفية نحو الرمز لقراءته تلقائياً</p>
                </div>
              </div>

              {/* Viewport for camera scan */}
              <div className="relative w-full h-56 bg-slate-950 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 flex items-center justify-center">
                <div id="barcode-scanner-viewport" className="absolute inset-0 w-full h-full"></div>
                
                {/* Visual scanning box overlay - Centered 280x160 region with shaded surround */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[280px] h-[160px] border-2 border-emerald-500 border-dashed rounded-xl flex items-center justify-center pointer-events-none z-10 shadow-[0_0_0_9999px_rgba(0,0,0,0.65)]">
                  {/* Glowing Laser line animation */}
                  <div className="absolute inset-x-0 h-[2px] bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)] animate-[bounce_2s_infinite]"></div>
                </div>
              </div>

              {/* Simulation fallback for testing/preview */}
              <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/20 text-indigo-700 dark:text-indigo-400 rounded-xl border border-indigo-100 dark:border-indigo-900/40 space-y-2">
                <p className="text-[10px] font-bold text-center">💡 هل تقوم بالتجربة من الحاسوب بدون كاميرا؟</p>
                <p className="text-[9px] text-center text-slate-500 dark:text-slate-400 leading-relaxed">
                  بإمكانك تجربة الميزة وسرعتها الخارقة فوراً بمسح تجريبي لأدوية عراقية شائعة:
                </p>
                <div className="grid grid-cols-3 gap-1.5 pt-1 text-right">
                  <button
                    type="button"
                    onClick={() => {
                      setBarcode("3057640107481");
                      showToast("تمت محاكاة مسح بندول إكسترا بنجاح");
                      setShowScanner(false);
                    }}
                    className="py-1 px-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-[9px] text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-100 cursor-pointer truncate"
                  >
                    بندول إكسترا
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setBarcode("5012345678901");
                      showToast("تمت محاكاة مسح أموكسيسيلين بنجاح");
                      setShowScanner(false);
                    }}
                    className="py-1 px-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-[9px] text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-100 cursor-pointer truncate"
                  >
                    أموكسيسيلين
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setBarcode("6291100342152");
                      showToast("تمت محاكاة مسح بخاخ فنتولين بنجاح");
                      setShowScanner(false);
                    }}
                    className="py-1 px-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-[9px] text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-100 cursor-pointer truncate"
                  >
                    بخاخ فنتولين
                  </button>
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  type="button"
                  onClick={() => setShowScanner(false)}
                  className="w-full py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
                >
                  إغلاق نافذة الكاميرا
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Toast Alert */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-6 right-6 z-50 px-5 py-3.5 rounded-2xl shadow-xl flex items-center gap-2.5 border text-xs max-w-sm ${
              toast.type === "success"
                ? "bg-emerald-50 border-emerald-100 dark:bg-emerald-950/90 dark:border-emerald-900 text-emerald-800 dark:text-emerald-350"
                : "bg-rose-50 border-rose-100 dark:bg-rose-950/90 dark:border-rose-900 text-rose-800 dark:text-rose-350"
            }`}
          >
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500" />
            <span className="font-semibold leading-relaxed">{toast.text}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
