/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Category, Product, SaleInvoice, PurchaseInvoice, Customer, Supplier, PharmacySettings } from "../types";

const DB_NAME = "PharmacyPOSDB";
const DB_VERSION = 1;

export class IndexedDBService {
  private static db: IDBDatabase | null = null;

  static openDB(): Promise<IDBDatabase> {
    if (this.db) return Promise.resolve(this.db);

    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event: any) => {
        const db = event.target.result;

        // Create Categories store
        if (!db.objectStoreNames.contains("categories")) {
          db.createObjectStore("categories", { keyPath: "id" });
        }

        // Create Products store
        if (!db.objectStoreNames.contains("products")) {
          const productStore = db.createObjectStore("products", { keyPath: "id" });
          productStore.createIndex("commercialName", "commercialName", { unique: false });
          productStore.createIndex("scientificName", "scientificName", { unique: false });
          productStore.createIndex("categoryId", "categoryId", { unique: false });
          productStore.createIndex("manufacturer", "manufacturer", { unique: false });
          productStore.createIndex("expirationDate", "expirationDate", { unique: false });
        }

        // Create Sales store
        if (!db.objectStoreNames.contains("sales")) {
          const salesStore = db.createObjectStore("sales", { keyPath: "id" });
          salesStore.createIndex("date", "date", { unique: false });
        }

        // Create Purchases store
        if (!db.objectStoreNames.contains("purchases")) {
          const purchasesStore = db.createObjectStore("purchases", { keyPath: "id" });
          purchasesStore.createIndex("date", "date", { unique: false });
        }

        // Create Customers store
        if (!db.objectStoreNames.contains("customers")) {
          db.createObjectStore("customers", { keyPath: "id" });
        }

        // Create Suppliers store
        if (!db.objectStoreNames.contains("suppliers")) {
          db.createObjectStore("suppliers", { keyPath: "id" });
        }

        // Create Settings store
        if (!db.objectStoreNames.contains("settings")) {
          db.createObjectStore("settings", { keyPath: "key" });
        }
      };

      request.onsuccess = (event: any) => {
        this.db = event.target.result;
        resolve(event.target.result);
      };

      request.onerror = (event: any) => {
        reject(event.target.error);
      };
    });
  }

  // Generic Operations
  static getStore(storeName: string, mode: IDBTransactionMode = "readonly"): Promise<IDBObjectStore> {
    return this.openDB().then((db) => {
      const transaction = db.transaction(storeName, mode);
      return transaction.objectStore(storeName);
    });
  }

  static getAll<T>(storeName: string): Promise<T[]> {
    return new Promise((resolve, reject) => {
      this.getStore(storeName, "readonly")
        .then((store) => {
          const request = store.getAll();
          request.onsuccess = () => resolve(request.result);
          request.onerror = () => reject(request.error);
        })
        .catch(reject);
    });
  }

  static getById<T>(storeName: string, id: string): Promise<T | null> {
    return new Promise((resolve, reject) => {
      this.getStore(storeName, "readonly")
        .then((store) => {
          const request = store.get(id);
          request.onsuccess = () => resolve(request.result || null);
          request.onerror = () => reject(request.error);
        })
        .catch(reject);
    });
  }

  static add<T>(storeName: string, item: T): Promise<void> {
    return new Promise((resolve, reject) => {
      this.getStore(storeName, "readwrite")
        .then((store) => {
          const request = store.add(item);
          request.onsuccess = () => resolve();
          request.onerror = () => reject(request.error);
        })
        .catch(reject);
    });
  }

  static update<T>(storeName: string, item: T): Promise<void> {
    return new Promise((resolve, reject) => {
      this.getStore(storeName, "readwrite")
        .then((store) => {
          const request = store.put(item);
          request.onsuccess = () => resolve();
          request.onerror = () => reject(request.error);
        })
        .catch(reject);
    });
  }

  static delete(storeName: string, id: string): Promise<void> {
    return new Promise((resolve, reject) => {
      this.getStore(storeName, "readwrite")
        .then((store) => {
          const request = store.delete(id);
          request.onsuccess = () => resolve();
          request.onerror = () => reject(request.error);
        })
        .catch(reject);
    });
  }

  static clearStore(storeName: string): Promise<void> {
    return new Promise((resolve, reject) => {
      this.getStore(storeName, "readwrite")
        .then((store) => {
          const request = store.clear();
          request.onsuccess = () => resolve();
          request.onerror = () => reject(request.error);
        })
        .catch(reject);
    });
  }

  // Set stock quantity of all products to 0
  static async resetAllStockToZero(): Promise<void> {
    const products = await this.getAll<Product>("products");
    for (const prod of products) {
      prod.quantity = 0;
      await this.update("products", prod);
    }
  }

  // Delete all products
  static async deleteAllMedicines(): Promise<void> {
    await this.clearStore("products");
    await this.clearStore("categories");
    await this.clearStore("sales");
    await this.clearStore("purchases");
    localStorage.setItem("db_seeded", "true");
  }

  // Complete system wipe (Factory Reset)
  static async factoryResetSystem(): Promise<void> {
    await this.clearStore("products");
    await this.clearStore("categories");
    await this.clearStore("sales");
    await this.clearStore("purchases");
    await this.clearStore("customers");
    await this.clearStore("suppliers");
    localStorage.setItem("db_seeded", "true");
  }

  // Specialized search for Products store (supports high performance up to 50,000+ items)
  static searchProducts(
    searchQuery: string,
    categoryId?: string,
    manufacturer?: string,
    isExpiredSearch?: boolean, // Filter expired products
    limit: number = 100,
    offset: number = 0
  ): Promise<{ items: Product[]; total: number }> {
    return new Promise((resolve, reject) => {
      this.getStore("products", "readonly")
        .then((store) => {
          const products: Product[] = [];
          const query = searchQuery.trim().toLowerCase();
          const todayStr = new Date().toISOString().split("T")[0];

          const request = store.openCursor();
          let count = 0;
          let matchedCount = 0;

          request.onsuccess = (event: any) => {
            const cursor = event.target.result;
            if (cursor) {
              const product: Product = cursor.value;
              let isMatch = true;

              // Filter by category
              if (categoryId && product.categoryId !== categoryId) {
                isMatch = false;
              }

              // Filter by manufacturer
              if (manufacturer && !product.manufacturer.toLowerCase().includes(manufacturer.toLowerCase())) {
                isMatch = false;
              }

              // Filter by expired
              if (isExpiredSearch && product.expirationDate > todayStr) {
                isMatch = false;
              }

              // Filter by search query (commercial or scientific name or barcode)
              if (isMatch && query) {
                const commName = product.commercialName.toLowerCase();
                const sciName = product.scientificName.toLowerCase();
                const barcode = (product.barcode || "").toLowerCase();
                if (!commName.includes(query) && !sciName.includes(query) && !barcode.includes(query)) {
                  isMatch = false;
                }
              }

              if (isMatch) {
                if (matchedCount >= offset && products.length < limit) {
                  products.push(product);
                }
                matchedCount++;
              }

              count++;
              cursor.continue();
            } else {
              resolve({
                items: products,
                total: matchedCount,
              });
            }
          };

          request.onerror = () => reject(request.error);
        })
        .catch(reject);
    });
  }

  // Pre-populate data helper
  static async seedDatabaseIfEmpty(): Promise<void> {
    const isSeeded = localStorage.getItem("db_seeded") === "true";
    if (isSeeded) return; // Already seeded once and user might have cleared it!

    const categories = await this.getAll<Category>("categories");
    if (categories.length > 0) {
      localStorage.setItem("db_seeded", "true");
      return; // Already seeded
    }

    // 1. Seed Categories
    const initialCategories: Category[] = [
      { id: "cat-1", name: "مسكنات وخافضات حرارة", description: "أدوية تسكين الآلام وتخفيض درجات الحرارة" },
      { id: "cat-2", name: "مضادات حيوية", description: "مضادات الالتهابات والعدوى البكتيرية" },
      { id: "cat-3", name: "أدوية السكري", description: "منظمات السكر وخافضات الغلوكوز في الدم" },
      { id: "cat-4", name: "أدوية القلب والضغط", description: "أدوية علاج ضغط الدم وتنظيم ضربات القلب" },
      { id: "cat-5", name: "أدوية الجهاز الهضمي", description: "أدوية حماية المعدة والقولون ومضادات الحموضة" },
      { id: "cat-6", name: "فيتامينات ومكملات غذائية", description: "الفيتامينات والمقويات العامة" },
      { id: "cat-7", name: "المستلزمات الطبية والضماد", description: "سرنجات، كانيولات، أجهزة مغذي، قطن، لاصق وشاش طبي" }
    ];

    for (const cat of initialCategories) {
      await this.add("categories", cat);
    }

    // 2. Seed Suppliers
    const initialSuppliers: Supplier[] = [
      { id: "sup-1", name: "شركة أدوية سامراء (SDI)", phone: "07701234567", address: "صلاح الدين - سامراء", balance: 0 },
      { id: "sup-2", name: "مكتب بابل العلمي", phone: "07802345678", address: "بغداد - الحارثية", balance: 250000 },
      { id: "sup-3", name: "مجموعة النبع للأدوية والمستلزمات", phone: "07903456789", address: "البصرة - العشار", balance: 0 }
    ];

    for (const sup of initialSuppliers) {
      await this.add("suppliers", sup);
    }

    // 3. Seed Customers
    const initialCustomers: Customer[] = [
      { id: "cust-1", name: "أبو علي الكرخي", phone: "07709876543", address: "بغداد - الكرخ", debts: 15000 },
      { id: "cust-2", name: "أم أحمد العبيدي", phone: "07808765432", address: "بغداد - الأعظمية", debts: 0 },
      { id: "cust-3", name: "سجاد كريم الموسوي", phone: "07507654321", address: "النجف الأشرف", debts: 45000 }
    ];

    for (const cust of initialCustomers) {
      await this.add("customers", cust);
    }

    // 4. Seed Products
    // Set dates relative to today for alerts
    const today = new Date();
    const futureDate = (months: number) => {
      const d = new Date();
      d.setMonth(d.getMonth() + months);
      return d.toISOString().split("T")[0];
    };
    const pastDate = (months: number) => {
      const d = new Date();
      d.setMonth(d.getMonth() - months);
      return d.toISOString().split("T")[0];
    };

    const initialProducts: Product[] = [
      {
        id: "prod-1",
        commercialName: "بندول إكسترا",
        scientificName: "Paracetamol + Caffeine",
        manufacturer: "GlaxoSmithKline (GSK)",
        categoryId: "cat-1",
        batchNumber: "B1209",
        productionDate: pastDate(6),
        expirationDate: futureDate(18),
        buyPrice: 1500,
        sellPrice: 2500,
        wholesalePrice: 1750,
        quantity: 120,
        minStock: 15,
        location: "الرف A-3",
        dosageForm: "شريط",
        notes: "مخزن مكيف"
      },
      {
        id: "prod-2",
        commercialName: "أموكسيل 500 ملغ",
        scientificName: "Amoxicillin",
        manufacturer: "GSK",
        categoryId: "cat-2",
        batchNumber: "AMX501",
        productionDate: pastDate(3),
        expirationDate: futureDate(15),
        buyPrice: 3000,
        sellPrice: 4500,
        wholesalePrice: 3300,
        quantity: 80,
        minStock: 10,
        location: "الرف B-1",
        dosageForm: "كبسول",
        notes: "كبسول مضاد حيوي"
      },
      {
        id: "prod-3",
        commercialName: "بروفين 400 ملغ",
        scientificName: "Ibuprofen",
        manufacturer: "Abbott",
        categoryId: "cat-1",
        batchNumber: "BRF04",
        productionDate: pastDate(12),
        expirationDate: futureDate(2), // Near expiration!
        buyPrice: 1200,
        sellPrice: 2000,
        wholesalePrice: 1400,
        quantity: 150,
        minStock: 20,
        location: "الرف A-1",
        dosageForm: "شريط",
        notes: "يؤخذ بعد الطعام"
      },
      {
        id: "prod-4",
        commercialName: "جالفوس ميت 50/1000",
        scientificName: "Vildagliptin + Metformin",
        manufacturer: "Novartis",
        categoryId: "cat-3",
        batchNumber: "GV991",
        productionDate: pastDate(4),
        expirationDate: futureDate(20),
        buyPrice: 18000,
        sellPrice: 22000,
        wholesalePrice: 19500,
        quantity: 45,
        minStock: 5,
        location: "الرف C-4",
        dosageForm: "شريط",
        notes: "أدوية الأمراض المزمنة"
      },
      {
        id: "prod-5",
        commercialName: "كونكور 5 ملغ",
        scientificName: "Bisoprolol Fumarate",
        manufacturer: "Merck",
        categoryId: "cat-4",
        batchNumber: "CON80",
        productionDate: pastDate(5),
        expirationDate: futureDate(14),
        buyPrice: 6500,
        sellPrice: 8500,
        wholesalePrice: 7200,
        quantity: 3, // Low stock!
        minStock: 10,
        location: "الرف C-1",
        dosageForm: "شريط",
        notes: "أدوية الضغط والقلب"
      },
      {
        id: "prod-6",
        commercialName: "أوميز 20 ملغ",
        scientificName: "Omeprazole",
        manufacturer: "Dr. Reddy's",
        categoryId: "cat-5",
        batchNumber: "OMZ02",
        productionDate: pastDate(8),
        expirationDate: futureDate(10),
        buyPrice: 2500,
        sellPrice: 4000,
        wholesalePrice: 3000,
        quantity: 65,
        minStock: 12,
        location: "الرف D-2",
        dosageForm: "كبسول",
        notes: "مضاد حموضة وحماية معدة"
      },
      {
        id: "prod-7",
        commercialName: "فيتامين د3 ديفارول",
        scientificName: "Cholecalciferol (Vitamin D3)",
        manufacturer: "Memphis",
        categoryId: "cat-6",
        batchNumber: "DVR-3",
        productionDate: pastDate(18),
        expirationDate: pastDate(1), // Already expired!
        buyPrice: 2000,
        sellPrice: 3500,
        wholesalePrice: 2400,
        quantity: 25,
        minStock: 5,
        location: "الرف F-1",
        dosageForm: "أمبولة",
        notes: "حقن فيتامين د"
      },
      {
        id: "prod-8",
        commercialName: "شراب بنتولين",
        scientificName: "Salbutamol",
        manufacturer: "GSK",
        categoryId: "cat-4",
        batchNumber: "VT012",
        productionDate: pastDate(2),
        expirationDate: futureDate(24),
        buyPrice: 1500,
        sellPrice: 2500,
        wholesalePrice: 1700,
        quantity: 0, // Out of stock!
        minStock: 8,
        location: "الرف B-4",
        dosageForm: "شراب",
        notes: "شراب موسع قصبات"
      },
      {
        id: "prod-9",
        commercialName: "سرنجة طبية 3 مل العصرية",
        scientificName: "Surgical Syringe 3ml",
        manufacturer: "مصنع الكفيل العراقي",
        categoryId: "cat-7",
        batchNumber: "SYR-03",
        productionDate: pastDate(1),
        expirationDate: futureDate(36),
        buyPrice: 80,
        sellPrice: 250,
        wholesalePrice: 120,
        quantity: 350,
        minStock: 50,
        location: "درج المستلزمات A",
        dosageForm: "مستلزم طبي",
        notes: "سرنجات معقمة استخدام مرة واحدة"
      },
      {
        id: "prod-10",
        commercialName: "كانيولا زرقاء 22G",
        scientificName: "IV Cannula 22G Blue",
        manufacturer: "مكتب بابل للمستلزمات",
        categoryId: "cat-7",
        batchNumber: "CAN-B22",
        productionDate: pastDate(2),
        expirationDate: futureDate(24),
        buyPrice: 300,
        sellPrice: 750,
        wholesalePrice: 450,
        quantity: 120,
        minStock: 20,
        location: "درج المستلزمات B",
        dosageForm: "مستلزم طبي",
        notes: "كانيولا زرقاء للمغذي والزرق الوريدي"
      },
      {
        id: "prod-11",
        commercialName: "بخاخ فنتولين للربو",
        scientificName: "Ventolin Inhaler 100mcg",
        manufacturer: "GlaxoSmithKline (GSK)",
        categoryId: "cat-4",
        batchNumber: "VEN-H9",
        productionDate: pastDate(4),
        expirationDate: futureDate(16),
        buyPrice: 4200,
        sellPrice: 6000,
        wholesalePrice: 4900,
        quantity: 45,
        minStock: 8,
        location: "الرف B-2",
        dosageForm: "بخاخ",
        notes: "بخاخ طوارئ للربو"
      },
      {
        id: "prod-12",
        commercialName: "قطرة عين ريفريش تيرز",
        scientificName: "Refresh Tears Lubricant Eye Drops",
        manufacturer: "Allergan",
        categoryId: "cat-1",
        batchNumber: "REF-08",
        productionDate: pastDate(3),
        expirationDate: futureDate(15),
        buyPrice: 5500,
        sellPrice: 7500,
        wholesalePrice: 6200,
        quantity: 55,
        minStock: 6,
        location: "الرف A-4",
        dosageForm: "قطرات",
        notes: "قطرة ترطيب العين معقمة"
      },
      {
        id: "prod-13",
        commercialName: "بلاستر طبي لاصق حريري",
        scientificName: "Silk Adhesive Plaster Tape 5cm",
        manufacturer: "مكتب دجلة العلمي",
        categoryId: "cat-7",
        batchNumber: "BLA-88",
        productionDate: pastDate(5),
        expirationDate: futureDate(40),
        buyPrice: 850,
        sellPrice: 1500,
        wholesalePrice: 1100,
        quantity: 90,
        minStock: 15,
        location: "درج المستلزمات A",
        dosageForm: "مستلزم طبي",
        notes: "شريط لاصق طبي حريري جودة عالية"
      }
    ];

    for (const prod of initialProducts) {
      await this.add("products", prod);
    }

    // 5. Seed Settings
    const defaultSettings: PharmacySettings & { key: string } = {
      key: "pharmacy_settings",
      pharmacyName: "صيدلية الرافدين النموذجية",
      address: "بغداد - شارع فلسطين - قرب ساحة بيروت",
      phone: "07700000000",
      currency: "د.ع"
    };
    await this.add("settings", defaultSettings);

    // 6. Seed Sale Invoices (to have reports history)
    const initialSales: SaleInvoice[] = [
      {
        id: "sale-1",
        invoiceNumber: "INV-20260630-001",
        date: new Date(today.getTime() - 24 * 60 * 60 * 1000).toISOString(), // Yesterday
        customerId: "cust-1",
        items: [
          { productId: "prod-1", commercialName: "بندول إكسترا", scientificName: "Paracetamol + Caffeine", price: 2500, quantity: 2, total: 5000 },
          { productId: "prod-3", commercialName: "بروفين 400 ملغ", scientificName: "Ibuprofen", price: 2000, quantity: 1, total: 2000 }
        ],
        subtotal: 7000,
        discount: 500,
        total: 6500,
        notes: "دفع نقدي جزئي"
      },
      {
        id: "sale-2",
        invoiceNumber: "INV-20260630-002",
        date: today.toISOString(), // Today
        customerId: null,
        items: [
          { productId: "prod-4", commercialName: "جالفوس ميت 50/1000", scientificName: "Vildagliptin + Metformin", price: 22000, quantity: 1, total: 22000 },
          { productId: "prod-6", commercialName: "أوميز 20 ملغ", scientificName: "Omeprazole", price: 4000, quantity: 2, total: 8000 }
        ],
        subtotal: 30000,
        discount: 0,
        total: 30000,
        notes: "زبون خارجي"
      }
    ];

    for (const sale of initialSales) {
      await this.add("sales", sale);
    }

    // 7. Seed Purchase Invoices
    const initialPurchases: PurchaseInvoice[] = [
      {
        id: "pur-1",
        invoiceNumber: "PUR-20260629-001",
        date: new Date(today.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        supplierId: "sup-2",
        items: [
          { productId: "prod-4", commercialName: "جالفوس ميت 50/1000", buyPrice: 18000, quantity: 10, total: 180000 },
          { productId: "prod-6", commercialName: "أوميز 20 ملغ", buyPrice: 2500, quantity: 20, total: 50000 }
        ],
        subtotal: 230000,
        total: 230000,
        notes: "تم استلام الفاتورة وتحديث المخزن"
      }
    ];

    for (const pur of initialPurchases) {
      await this.add("purchases", pur);
    }
    localStorage.setItem("db_seeded", "true");
  }

  // Generate 10,000+ random products for stress testing / demonstration!
  static async generateMassiveDemoProducts(count: number = 10000, progressCallback?: (progress: number) => void): Promise<void> {
    const categories = await this.getAll<Category>("categories");
    if (categories.length === 0) return;

    const manufacturers = ["GlaxoSmithKline", "Novartis", "Abbott", "Pfizer", "Merck", "AstraZeneca", "Sanofi", "SDI Iraq", "Bayer", "Roche"];
    const drugTypes = [
      { comm: "أوجمانتين", sci: "Amoxicillin + Clavulanic Acid" },
      { comm: "بروفين شراب", sci: "Ibuprofen Suspension" },
      { comm: "كلافوران أمبول", sci: "Cefotaxime" },
      { comm: "كابوتن 25 ملغ", sci: "Captopril" },
      { comm: "أملور 5 ملغ", sci: "Amlodipine" },
      { comm: "داونيل 5 ملغ", sci: "Glibenclamide" },
      { comm: "زانتاك 150 ملغ", sci: "Ranitidine" },
      { comm: "بلافيكس 75 ملغ", sci: "Clopidogrel" },
      { comm: "نيكسيوم 40 ملغ", sci: "Esomeprazole" },
      { comm: "فلاجيل 500", sci: "Metronidazole" },
      { comm: "كلاسيد 250 ملغ", sci: "Clarithromycin" },
      { comm: "فنتولين بخاخ", sci: "Salbutamol Inhaler" },
      { comm: "أسبيرين 81 ملغ", sci: "Aspirin low dose" },
      { comm: "ليبيتور 20 ملغ", sci: "Atorvastatin" },
      { comm: "سينجولير 10 ملغ", sci: "Montelukast" }
    ];

    const today = new Date();
    const batchSize = 500;
    let created = 0;

    // We do bulk adding in chunks/transactions for highest performance
    const db = await this.openDB();

    for (let i = 0; i < count; i += batchSize) {
      const currentBatchLimit = Math.min(count, i + batchSize);
      
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction("products", "readwrite");
        const store = tx.objectStore("products");

        tx.oncomplete = () => {
          created += (currentBatchLimit - i);
          if (progressCallback) {
            progressCallback(Math.round((created / count) * 100));
          }
          resolve();
        };

        tx.onerror = () => {
          reject(tx.error);
        };

        for (let j = i; j < currentBatchLimit; j++) {
          const drug = drugTypes[j % drugTypes.length];
          const cat = categories[j % categories.length];
          const man = manufacturers[j % manufacturers.length];
          const indexNum = j + 1;
          
          const buyPrice = Math.round((Math.random() * 20000 + 500) / 250) * 250; // increments of 250 IQD
          const sellPrice = buyPrice + Math.round((Math.random() * 5000 + 500) / 250) * 250;
          const wholesalePrice = buyPrice + Math.round((Math.random() * 1500) / 250) * 250;
          
          const expYear = today.getFullYear() + Math.floor(Math.random() * 3) + 1;
          const expMonth = String(Math.floor(Math.random() * 12) + 1).padStart(2, "0");
          const expDay = String(Math.floor(Math.random() * 28) + 1).padStart(2, "0");
          
          const qty = Math.floor(Math.random() * 200) + 5;
          const minS = Math.floor(Math.random() * 15) + 5;

          const product: Product = {
            id: `massive-prod-${indexNum}`,
            commercialName: `${drug.comm} #${indexNum}`,
            scientificName: `${drug.sci}`,
            manufacturer: man,
            categoryId: cat.id,
            batchNumber: `BT-${10000 + indexNum}`,
            productionDate: `${today.getFullYear() - 1}-01-01`,
            expirationDate: `${expYear}-${expMonth}-${expDay}`,
            buyPrice,
            sellPrice,
            wholesalePrice,
            quantity: qty,
            minStock: minS,
            location: `الرف ${String.fromCharCode(65 + (j % 6))}-${(j % 10) + 1}`,
            notes: `دواء مولد آلياً رقم ${indexNum}`
          };

          store.add(product);
        }
      });
    }
  }

  // Initialize Database wrapper
  static async initDB(): Promise<void> {
    await this.openDB();
    await this.seedDatabaseIfEmpty();
  }

  // Settings Management
  static async getSettings(): Promise<PharmacySettings | null> {
    const raw = await this.getById<any>("settings", "pharmacy_settings");
    if (!raw) return null;
    return {
      pharmacyName: raw.pharmacyName || raw.name || "صيدلية الياسمين التخصصية",
      address: raw.address || "",
      phone: raw.phone || "",
      currency: raw.currency || "د.ع"
    };
  }

  static async saveSettings(settings: PharmacySettings): Promise<void> {
    const dataToSave = {
      key: "pharmacy_settings",
      pharmacyName: settings.pharmacyName,
      address: settings.address,
      phone: settings.phone,
      currency: settings.currency
    };
    await this.update("settings", dataToSave);
  }

  // Restore DB from Backup
  static async bulkRestore(backupData: any): Promise<void> {
    const stores = ["categories", "products", "sales", "purchases", "customers", "suppliers", "settings"];
    for (const storeName of stores) {
      await this.clearStore(storeName);
      if (backupData[storeName] && Array.isArray(backupData[storeName])) {
        for (const item of backupData[storeName]) {
          await this.add(storeName, item);
        }
      }
    }
  }

  // Add bulk products directly for stress testing
  static async bulkAddProducts(productsList: Product[]): Promise<void> {
    const db = await this.openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction("products", "readwrite");
      const store = tx.objectStore("products");
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      for (const prod of productsList) {
        store.put(prod);
      }
    });
  }
}
